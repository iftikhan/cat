import React from 'react';
import PropTypes from 'prop-types';

import { useHistory } from 'react-router';

import { Card, Button } from 'reactstrap';

const ResourceCard = ({
  id, name, resourceType, status, description, infraId,
}) => {
  const history = useHistory();

  return (
    <Card>
      <Card.Header>{resourceType}</Card.Header>
      <Card.Body>
        <Card.Subtitle className="mb-2 text-muted">{name}</Card.Subtitle>
        <Card.Text title={description}>
          {status}
        </Card.Text>
      </Card.Body>
      <Card.Footer>
        <Button
          className={'float-right'}
          onClick={() => history.push(`/gxp-infra/${infraId}/resources/${id}`)}>Edit</Button>
      </Card.Footer>
    </Card>
  )
};

ResourceCard.propTypes = {
  id: PropTypes.number.isRequired,
  name: PropTypes.string.isRequired,
  resourceType: PropTypes.string.isRequired,
  status: PropTypes.string.isRequired,
  description: PropTypes.string,
  infraId: PropTypes.string.isRequired,
}

export default ResourceCard;
