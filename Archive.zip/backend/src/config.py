import os
import json
import boto3
from dotenv import load_dotenv
import sentry_sdk
from sentry_sdk.integrations.aws_lambda import AwsLambdaIntegration


base_dir = os.path.dirname(__file__)
project_dir = os.path.dirname(base_dir)
env_filename = os.environ.get('ENV_FILENAME', '.env')

if os.path.isfile(os.path.join(project_dir, env_filename)):
    load_dotenv(os.path.join(project_dir, env_filename))


class __Config:
    ENV_NAME = os.environ.get('ENV_NAME')
    DEBUG = bool(os.environ.get('DEBUG'))
    IS_LOCAL = bool(os.environ.get('IS_LOCAL'))
    PROJECT_NAME = f'gxpvalidator-{ENV_NAME}'

    BASE_DIR = base_dir
    TEMPLATES_DIR = os.path.join(BASE_DIR, 'templates')

    DATABASE_USERNAME = os.environ.get('DATABASE_USERNAME', 'postgres')
    DATABASE_PASSWORD = os.environ.get('DATABASE_PASSWORD', 'postgres')
    DATABASE_HOST = os.environ.get('DATABASE_HOST', 'localhost')
    DATABASE_DBNAME = os.environ.get('DATABASE_DBNAME', 'gxp')

    STORAGE_BUCKET = os.environ.get('STORAGE_BUCKET', 'gxp-dataset-dev')
    VALIDATE_FUNCTION_NAME = os.environ.get('VALIDATE_FUNCTION_NAME')
    INIT_JOB_FUNCTION_NAME = os.environ.get('INIT_JOB_FUNCTION_NAME')
    GENERATE_REPORT_FUNCTION_NAME = os.environ.get('GENERATE_REPORT_FUNCTION_NAME')
    EXECUTE_TOOL_FUNCTION_NAME = os.environ.get('EXECUTE_TOOL_FUNCTION_NAME')

    COGNITO_USER_POOL_ID = os.environ.get('LOCAL_COGNITO_USER_POOL_ID')\
        if IS_LOCAL else os.environ.get('COGNITO_USER_POOL_ID')

    LOCAL_HARDCODED_USERNAME = os.environ.get('LOCAL_HARDCODED_USERNAME')

    SES_SENDER_EMAIL = os.environ.get(
        'SES_SENDER_EMAIL', 'csv.support@customer.com')
    ERROR_REPORTING_RECIPIENTS = (os.environ.get(
        'ERROR_REPORTING_RECIPIENTS') or 'ecmascript.guru@gmail.com').split(';')

    def __init__(self) -> None:
        if not self.IS_LOCAL:
            sentry_sdk.init(
                dsn="https://246ff50fc8194a618d04653ea467dae1@o917954.ingest.sentry.io/5905991",
                integrations=[AwsLambdaIntegration(timeout_warning=True)],
                environment=self.ENV_NAME
            )
            self.__read_db_credentials()

    def __read_db_credentials(self):
        secret_name = os.environ.get('DB_SECRET_NAME')
        if not secret_name:
            raise Exception('DB_SECRET_NAME is required.')

        client = boto3.client('secretsmanager')

        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            raise Exception('Base64 is not permitted')

        credentials = json.loads(secret)

        self.DATABASE_USERNAME = credentials["username"]
        self.DATABASE_PASSWORD = credentials["password"]
        self.DATABASE_HOST = credentials["host"]
        self.DATABASE_DBNAME = credentials["dbname"]


settings = __Config()
