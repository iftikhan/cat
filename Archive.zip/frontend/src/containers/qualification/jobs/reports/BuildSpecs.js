import React from "react";
import PropTypes from 'prop-types';

import BuildBlock from "./BuildSpecBlock";

const BuildSpecs = ({
  buildSpecWindows,
  buildSpecLinux,
}) => {
  return (
    <>
      {buildSpecWindows.length > 0 && (
        <BuildBlock title='Windows EC2 Instances' items={buildSpecWindows} />
      )}
      {buildSpecLinux.length > 0 && (
        <BuildBlock title='Linux EC2 Instances' items={buildSpecLinux} />
      )}
    </>
  )
};

BuildSpecs.propTypes = {
  buildSpecWindows: PropTypes.arrayOf(PropTypes.shape({
    ResourceName: PropTypes.string.isRequired,
    ResourceOS: PropTypes.string.isRequired,
    ResourceType: PropTypes.string.isRequired,
    Spec: PropTypes.arrayOf(PropTypes.shape({
      ActualValue: PropTypes.string.isRequired,
      Drift: PropTypes.bool.isRequired,
      ExpectedValue: PropTypes.string.isRequired,
      Parameter: PropTypes.string.isRequired,
    })).isRequired,
  })),
  buildSpecLinux: PropTypes.arrayOf(PropTypes.shape({
    ResourceName: PropTypes.string.isRequired,
    ResourceOS: PropTypes.string.isRequired,
    ResourceType: PropTypes.string.isRequired,
    Spec: PropTypes.arrayOf(PropTypes.shape({
      ActualValue: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
      Drift: PropTypes.bool.isRequired,
      ExpectedValue: PropTypes.string.isRequired,
      Parameter: PropTypes.string.isRequired,
    })).isRequired,
  })),
}
export default BuildSpecs;
