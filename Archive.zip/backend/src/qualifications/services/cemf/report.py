from src.qualifications.services.core import ReportBase


class CemfReport(ReportBase):

    template_category = 'cemf'
