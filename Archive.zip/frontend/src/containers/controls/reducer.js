import createReducer from 'redux/helpers/createReducer';

import {
  namespace,
} from './actions';

const defaultState = {
}

const reducer = createReducer(namespace, defaultState, {
  // [fetchLzAccountsRequest.Type]: (state, action) => ({
  //   ...state,
  //   fetchingInfras: true,
  //   infras: [],
  // }),
});

export default reducer;
export { namespace };
