from enum import Enum


DATETIME_FORMAT = '%d %b %Y %H:%M:%S'
DRAFT_FILE_PATTERN = r'^public\/(\d+)\/(.*)\/drafts\/(.*)$'

class RULE_LEVEL:
    file_ = 'file'
    column = 'column'
    row = 'row'


class RULE_SEVERITY:
    reject = 'Reject'
    error = 'Error'
    warning = 'Warning'
    note = 'Note'


class RULE_TYPE:
    auto = 'Automatic'
    manual = 'Manual'


class JOB_STATUS:
    running = 'Running'
    success = 'Success'
    failure = 'Failure'
    error = 'Errors'


class PROJECT_STATUS:
    default = 'active'


class RUN_METHOD:
    api = 'API'
    excel = 'Excel'


class USER_ROLE:
    superadmin = 'superadmin'
    admin = 'admin'
    user = 'user'


class QUALIFICATION_TYPE:
    cemf = 1
    landing_zone = 2
    sap = 3


class InfraStatus(Enum):
    pending = 'pending'


class InfraResourceType(Enum):
    s3 = 's3'
    ec2 = 'ec2'


class InfraResourceStatus(Enum):
    initiated = 'initiated'
    provisioning = 'provisioning'
    success = 'success'
    failed = 'failed'
    deleting = 'deleting'


class CloudformationType(Enum):
    s3 = 'AWS::S3::Bucket'


class CloudProvider(Enum):
    aws = 'aws'
    gcp = 'gcp'
    azure = 'azure'
