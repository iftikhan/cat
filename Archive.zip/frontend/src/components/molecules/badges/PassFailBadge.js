import React from 'react';

import PropTypes from 'prop-types';

import { Badge } from 'reactstrap';

const PassFailBadge = ({
  status,
}) => {
  const statusText = status.toLowerCase() === 'pass' ? 'success' : 'danger';

  return (
    <Badge className="badge-dot mr-4" color="">
      <i className={`bg-${statusText}`} />
      <span className={`status text-${statusText}`}>{status}</span>
    </Badge>
  )
}

PassFailBadge.propTypes = {
  status: PropTypes.string.isRequired,
}

export default PassFailBadge;
