from __future__ import annotations

from datetime import datetime
from operator import and_
from typing import Counter, Dict, Optional, List, OrderedDict
from sqlalchemy.sql.expression import bindparam

from src.utils.constants import RULE_SEVERITY
from src.utils.pgsql import PgsqlManager, PG_DB_TABLE, Connection


class ReportSummaryEntry:
    id: int
    job_id: int
    rule_id: str
    status: str
    found: int
    publisher_id: Optional[str]
    message: Optional[str]
    comment: Optional[str]
    severity: Optional[str]
    started_at: Optional[datetime]
    ended_at: Optional[datetime]

    def __init__(
        self, id: int, job_id: int, rule_id: str, status: str,
        message: Optional[str] = None, found: int = 0,
        comment: str = None, publisher_id: Optional[str] = None,
        started_at: Optional[datetime] = None, severity: Optional[str] = None,
        ended_at: Optional[datetime] = None
    ) -> None:
        self.id = id
        self.job_id = job_id
        self.rule_id = rule_id
        self.status = status
        self.found = found
        self.comment = comment
        self.started_at = started_at
        self.ended_at = ended_at
        self.publisher_id = publisher_id
        self.message = message
        self.severity = severity

    @property
    def duration(self) -> str:
        if all(isinstance(x, datetime) for x in [self.started_at, self.ended_at]):
            return str(self.ended_at - self.started_at)
        else:
            return '-'

    def to_response(self) -> dict:
        return {
            'id': self.id,
            'job_id': self.job_id,
            'rule_id': self.rule_id,
            'publisher_id': self.publisher_id,
            'message': self.message,
            'severity': self.severity,
            'found': self.found,
            'comment': self.comment,
            'started_at': self.started_at,
            'duration': self.duration,
        }


class ReportSummaryComparision(ReportSummaryEntry):
    difference: int = 0

    def __init__(self, *args, **kwargs) -> None:
        difference = kwargs.pop('difference', None)
        super().__init__(*args, **kwargs)

        self.difference = self.found if difference is None else difference

    def to_response(self) -> dict:
        return {
            'difference': self.difference,
            **super().to_response()
        }

    def __sub__(self, other: ReportSummaryComparision) -> ReportSummaryComparision:
        self.difference = self.found - other.found
        if self.found > 0:
            self.comment = self.comment if self.comment else other.comment
        return self


class ReportSummaryModel:
    __connection: Optional[Connection] = None

    def __init__(self, db_manager: Optional[PgsqlManager] = None) -> None:
        if isinstance(db_manager, PgsqlManager):
            self.__db_manager = db_manager
        else:
            self.__db_manager = PgsqlManager()

    @property
    def connection(self) -> Connection:
        if not isinstance(self.__connection, Connection):
            self.__connection = self.__db_manager.get_db_connection()

        return self.__connection

    def create(self, job_id: int, rule_ids: List[str]) -> List[ReportSummaryEntry]:
        _table = PG_DB_TABLE.report_summary
        stmt = _table.insert().values([
            {
                'job_id': job_id,
                'rule_id': rule_id
            } for rule_id in rule_ids
        ]).returning(
            _table.c.id, _table.c.rule_id, _table.c.status, _table.c.found,
            _table.c.comment, _table.c.started_at, _table.c.ended_at
        )

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            rows = self.connection.execute(stmt).fetchall()
            return [
                ReportSummaryEntry(
                    job_id=job_id,
                    **row
                ) for row in rows
            ]

        return __transaction()

    def get_report_summary(self, job_id: int) -> List[ReportSummaryEntry]:
        query = f"""
            SELECT
                rs.id, rs.rule_id, rs."found", rs."comment", rs.status,
                r.message, r.severity, r.publisher_id
            FROM report_summaries rs join rules r on rs.rule_id = r.rule_id
            WHERE rs.job_id = {job_id}
            ORDER BY rs.rule_id;"""
        rows = self.connection.execute(query).fetchall()
        return [ReportSummaryEntry(job_id=job_id, **row) for row in rows]

    def get_comparison(self, job_id: int) -> List[ReportSummaryComparision]:
        query = f"""
            select
                rs.id, rs.job_id, rs.rule_id,
                r.publisher_id, r.message, r.severity,
                rs."found", rs.status, rs.comment
            from report_summaries rs join (
                select j.id
                from jobs j join (
                    select id, dataset_id, started_at
                    from jobs
                    where id = {job_id}
                ) as main_jobs on j.dataset_id = main_jobs.dataset_id
                where
                    j.started_at <= main_jobs.started_at and
                    j.id <= main_jobs.id
                order by j.started_at desc
                limit 2
            ) as recent_jobs on rs.job_id = recent_jobs.id
            join rules r on rs.rule_id = r.rule_id
            order by recent_jobs.id, rs.rule_id;"""

        rows = self.connection.execute(query).fetchall()
        summaries = [ReportSummaryComparision(**row) for row in rows]
        buffer: Dict[str, ReportSummaryComparision] = OrderedDict()

        for summary in summaries:
            if summary.rule_id not in buffer:
                buffer[summary.rule_id] = summary
            else:
                buffer[summary.rule_id] = summary - buffer[summary.rule_id]

        return buffer.values()

    def get_insight(self, job_id: str) -> dict:
        query = f"""
            select r.severity, count(*) as num, sum(rs."found") as "found"
            from report_summaries rs join rules r on rs.rule_id = r.rule_id
            where job_id = {job_id}
            group by r.severity;"""

        mapping = {
            RULE_SEVERITY.error: 'Total Errors',
            RULE_SEVERITY.reject: 'Total Rejects',
            RULE_SEVERITY.warning: 'Total Warnings',
        }
        rows = self.connection.execute(query).fetchall()
        insight = Counter()
        total = 0
        for row in rows:
            total += row.num

            if row.found > 0:
                insight[row.severity] += row.num

        result = {
            'Total Checks': total,
        }

        for severity, caption in mapping.items():
            result[caption] = insight[severity]

        result['Compliance Score'] = '%.2f' % (
            (total - (insight[RULE_SEVERITY.reject] + insight[RULE_SEVERITY.error])) / total * 100
        ) + '%'

        return result

    def update(self, job_id: int, summary_id: int, **kwargs) -> bool:
        if not kwargs:
            return False

        permitted_columns = ['comment']
        update_params = dict([
            (attr, value)
            for attr, value in kwargs.items()
            if attr in permitted_columns
        ])
        _table = PG_DB_TABLE.report_summary
        stmt = _table.update().where(and_(
            _table.c.job_id == job_id, _table.c.id == summary_id
        )).values(**update_params)

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)
            return response.rowcount > 0

        return __transaction()

    def mark_as_ended(self, summaries: List[ReportSummaryEntry]):
        params = [{
            'id_': summary.id,
            'found_': summary.found,
            'ended_at_': datetime.now(),
            'status_': summary.status
        } for summary in summaries]
        _table = PG_DB_TABLE.report_summary
        stmt = _table.update().where(
            _table.c.id == bindparam('id_')
        ).values(
            found=bindparam('found_'),
            ended_at=bindparam('ended_at_'),
            status=bindparam('status_'),
        )

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt, params)
            return response.rowcount > 0

        return __transaction()
