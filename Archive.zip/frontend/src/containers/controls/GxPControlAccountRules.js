import React, { useEffect, useState, useCallback } from 'react';
import { connect } from 'react-redux';
import {
  // useHistory,
  useParams
} from 'react-router';

import {
  Button, Card, CardHeader, CardBody
} from 'reactstrap';

import API from 'helpers/api';
import LoadingModal from 'components/modals/Loading';
import { fetchLzAccountsRequest } from 'containers/infrastructure/actions';
import SearchTable from 'components/tables/SearchTable';
import ConfirmModal from 'components/modals/ConfirmModal';
import CardFooter from '../../../node_modules/reactstrap/es/CardFooter';

const GxPControlAccountRules = ({
  infras, fetchingInfras, fetchLzAccountsRequest,
}) => {
  const {landingZoneId, accountId } = useParams();
  const [accountRules, setAccountRules] = useState([]);
  const [accountDetails, setAccountDetails] = useState(null);
  const [isChanged, setIsChanged] = useState(false);

  const [selectedRules, setSelectedRules] = useState([]);

  const [showConfirmModal, setShowConfirmModal] = useState(false);

  // const history = useHistory();

  const retrieveAccountRules = useCallback(() => {
    API.controls.getRulesByAccount(accountId)
    .then(({status, account_rules: rules}) => {
      if (status) {
        setAccountRules(rules)
      }
    }).catch(err => {
      console.error(err);
    })
  }, [setAccountRules, accountId]);

  const onSelectRule = useCallback((ruleId: Number, selected: Boolean) => {
    if (selected) {
      setSelectedRules([
        ...selectedRules,
        ruleId,
      ])
    } else {
      setSelectedRules(selectedRules.filter(item => item !== ruleId))
    }

    setIsChanged(true);
  }, [
    selectedRules,
  ])

  const onSelectAllRule = useCallback((checked) => {
    if (checked) {
      setSelectedRules(accountRules.map(({id}) => id));
    } else {
      setSelectedRules([]);
    }

    setIsChanged(true);
  }, [setSelectedRules, accountRules])

  const onUpdateAccountRules = () => {
    API.controls.updateRulesByAccount(accountId, selectedRules)
    .then(({status}) => {
      if (status) {
        setSelectedRules([]);
        retrieveAccountRules();
        setShowConfirmModal(false);
      }
    }).catch(err => {
      console.error(err);
    })
  }

  const managedRuleColumns = [
    {
      dataField: 'select',
      text: '',
      headerFormatter: (col, colIndex, components) => {
        return (
          <div className="custom-control custom-checkbox">
            <input
              className="custom-control-input"
              id={`managed-rule-table-check-all`}
              onClick={(event) => {onSelectAllRule(event.target.checked)}}
              defaultChecked={managedRuleColumns.length === selectedRules.length}
              type="checkbox"
            />
            <label
              className="custom-control-label"
              htmlFor={`managed-rule-table-check-all`}
            />
          </div>
        )
      },
    }, {
      dataField: 'name',
      text: 'Managed Rule Name',
      sort: true,
    }, {
      dataField: 'description',
      text: 'Description',
    }
  ]

  const renderAccountDetails = () => {
    const {
      account_id: accountId,
      name: accountName,
      organization_unit: orgUnit,
      cross_account_role_name: roleName,
    } = accountDetails;

    return (
      <Card>
        <CardHeader>Account Information</CardHeader>
        <CardBody>
          <table className='table align-items-center react-bootstrap-table'>
            <tbody>
              <tr>
                <td>Organization Unit</td>
                <td>{orgUnit}</td>
              </tr>
              <tr>
                <td>Account Name</td>
                <td>{accountName}</td>
              </tr>
              <tr>
                <td>Account ID</td>
                <td>{accountId}</td>
              </tr>
              <tr>
                <td>Cross Account Role Name</td>
                <td>{roleName}</td>
              </tr>
            </tbody>
          </table>
        </CardBody>
      </Card>
    )
  }

  useEffect(() => {
    retrieveAccountRules()
  }, [retrieveAccountRules]);

  useEffect(() => {
    API.retrieveLandingZoneAccount(landingZoneId, accountId)
    .then(({status, account}) => {
      setAccountDetails(account);
    }).catch(err => {
      console.error(err);
    })
  }, [landingZoneId, accountId]);

  useEffect(() => {
    setSelectedRules(accountRules.filter(({is_applied_to_account: isApplied}) => isApplied).map(({id}) => id));
  }, [accountRules, setSelectedRules]);

  return (
    <>
      {!!accountDetails && renderAccountDetails()}
      <Card className='mt-3'>
        <CardHeader>Managed Rules</CardHeader>
        <CardBody>
          <SearchTable
            columns={managedRuleColumns} keyField='id'
            data={accountRules.map((rule, idx) => ({
              ...rule,
              select: (
                <div className="custom-control custom-checkbox" key={idx}>
                  <input
                    className="custom-control-input"
                    id={`managed-rule-table-check-${rule.id}`}
                    onChange={(event) => {onSelectRule(rule.id, event.target.checked)}}
                    checked={selectedRules.indexOf(rule.id) >= 0}
                    type="checkbox"
                  />
                  <label
                    className="custom-control-label"
                    htmlFor={`managed-rule-table-check-${rule.id}`}
                  />
              </div>)
            }))}
            entryNamePlural='rules'
            noDataIndication={'No managed rule'}
            />
        </CardBody>
        <CardFooter>
          <Button
            color="primary" className='float-right'
            disabled={!isChanged}
            onClick={() => {setShowConfirmModal(true)}}>
            Apply
          </Button>
        </CardFooter>
      </Card>
      <ConfirmModal
        title='Confirm!'
        description={`Are you sure to apply ${selectedRules.length} rules?`}
        onCancel={() => setShowConfirmModal(false)}
        show={showConfirmModal}
        onOkay={onUpdateAccountRules}
        />
      <LoadingModal show={false} />
    </>
  )
}

const mapStateToProps = (state) => ({
});

const mapDispatchToProps = (dispatch) => ({
  fetchLzAccountsRequest: () => dispatch(fetchLzAccountsRequest()),
})

export default connect(mapStateToProps, mapDispatchToProps)(GxPControlAccountRules);
