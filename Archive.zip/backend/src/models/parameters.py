from __future__ import annotations
from src.models.infra.entries import LandingZoneEntry
from src.models.infra.infra_model import InfraModel
from src.utils.pgsql import PG_DB_TABLE

from typing import List, Tuple

from src.utils.model import ModelBase


class ParameterEntry:
    id: int
    resource_type: str
    expected_variable: str
    expected_value: str
    include: bool
    section: str
    section_description: str

    def __init__(
        self,
        id: int,
        resource_type: str,
        expected_variable: str,
        expected_value: str,
        include: bool,
        section: str,
        section_description: str
    ) -> None:
        self.id = id
        self.resource_type = resource_type
        self.expected_variable = expected_variable
        self.expected_value = expected_value
        self.include = include
        self.section = section
        self.section_description = section_description

    def to_response(self) -> dict:
        return {
            'id': self.id,
            'resource_type': self.resource_type,
            'expected_variable': self.expected_variable,
            'expected_value': self.expected_value,
            'include': self.include,
            'section': self.section,
            'section_description': self.section_description,
        }

    def __repr__(self) -> str:
        return f'<Parameter({self.resource_type}): {self.expected_variable}={self.expected_value}>'

    def __str__(self) -> str:
        return f'{self.resource_type}__{self.expected_variable}={self.expected_value}'


class SettingEntry:
    id: int
    name: str
    description: str

    def __init__(self, id: int, name: str, description: str) -> None:
        self.id = id
        self.name = name
        self.description = description

    def to_response(self) -> dict:
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
        }

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f'<Setting({self.id}): {self.name})>'


class QualificationTypeEntry:
    id: int
    name: str
    description: str
    details: dict

    settings: List[SettingEntry]
    # parameters: List[ParameterEntry]

    def __init__(
        self, id: int, name: str, description: str, details: dict,
        settings: List[SettingEntry],
        # parameters: List[ParameterEntry]
    ) -> None:
        self.id = id
        self.name = name
        self.description = description
        self.details = details

        if 'settings' in self.details and self.details['settings']:
            if self.details['settings'].get('only'):
                self.settings = [
                    item for item in settings
                    if item.name in self.details['settings'].get('only')]
            elif self.details['settings'].get('exclude'):
                self.settings = [
                    item for item in settings
                    if item.name not in self.details['settings'].get('exclude')]
            else:
                self.settings = []
        else:
            self.settings = settings
        # self.parameters = parameters

    def to_response(self) -> dict:
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            # 'details': self.details,

            'settings': [item.to_response() for item in self.settings],
            # 'parameters': [item.to_response() for item in self.parameters],
        }

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return f'<QualificationType({self.id}): {self.name}>'


class ParameterModel(ModelBase):
    def list_parameters(self) -> List[ParameterEntry]:
        table = PG_DB_TABLE.parameters_meta
        stmt = table.select()
        rows = self.connection.execute(stmt)
        return [ParameterEntry(**row) for row in rows]

    def list_settings(self) -> List[SettingEntry]:
        table = PG_DB_TABLE.settings_meta
        stmt = table.select()
        rows = self.connection.execute(stmt)
        return [SettingEntry(**row) for row in rows]

    def list_landing_zones(self) -> List[LandingZoneEntry]:
        infra_model = InfraModel()
        return infra_model.list_landing_zones()

    def get_all_options(
        self
    ) -> Tuple[List[QualificationTypeEntry], List[ParameterEntry], List[LandingZoneEntry]]:
        parameters = self.list_parameters()
        settings = self.list_settings()

        table = PG_DB_TABLE.qualification_types
        stmt = table.select()
        rows = self.connection.execute(stmt)
        return [
            QualificationTypeEntry(
                settings=settings,
                # parameters=parameters,
                **row
            ) for row in rows
        ], parameters, self.list_landing_zones()
