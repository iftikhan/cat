from datetime import datetime
from typing import Dict, List, Union

from src.utils.aws.common import CrossAccountClientBase
from src.utils.aws.ec2 import AwsRegion

class AwsAccount:
    account_id: str
    arn: str
    email: str
    name: str
    status: str
    joined_method: str
    joined_at: datetime

    regions: List[AwsRegion]

    def __init__(
        self, account_id: str, arn: str, email: str, name: str, status: str, joined_method: str, joined_at: datetime
    ) -> None:
        self.account_id = account_id
        self.arn = arn
        self.email = email
        self.name = name
        self.status = status
        self.joined_method = joined_method
        self.joined_at = joined_at

        self.regions = []

    def __repr__(self) -> str:
        return f'<AwsAccount({self.account_id}): {self.name}({self.email})>'

    @property
    def metadata(self) -> dict:
        account_metadata = {
            'ResourceName': self.account_id,
            'Id': self.account_id,
            'Arn': self.arn,
            'Name': self.name,
            'Email': self.email,
            'Status': self.status,
            'AvailableRegions': [region.name for region in self.regions],
        }

        for region in self.regions:
            account_metadata[f"Resources in {region.name}"] = {
                'AvailabilityZones': [zone.name for zone in region.zones],
                'VPCs': [vpc.vpc_id for vpc in region.vpcs],
                'Subnets': [subnet.subnet_id for subnet in region.subnets],
                'RouteTables': [item.route_table_id for item in region.route_tables],
                'NACLs': [item.nacl_id for item in region.nacls],
                'SecurityGroups': [item.group_id for item in region.security_groups],
                'InternetGateways': [item.id for item in region.internet_gateways],
            }

        return account_metadata

    def get_resource_metadata(self, sort_num: int, idx: int):
        metadata = self.metadata
        metadata.pop('ResourceName', None)

        return {
            'Sort': sort_num,
            'SubSort': idx,
            'ResourceName': f'{self.name}({self.account_id})',
            'ResourceType': 'Account',
            'Metadata': metadata,
        }


class AwsOrganizationalUnit:
    id: str
    arn: str
    name: str

    __accounts: List[AwsAccount]

    def __init__(
        self, id: str, arn: str, name: str
    ) -> None:
        self.id = id
        self.arn = arn
        self.name = name

    @property
    def accounts(self) -> List[AwsAccount]:
        return self.__accounts

    @accounts.setter
    def accounts(self, items: List[Union[Dict, AwsAccount]]):
        if all(isinstance(x, dict) for x in items):
            self.__accounts = [
                AwsAccount(
                    item['Id'], item['Arn'], item['Email'], item['Name'],
                    item['Status'], item['JoinedMethod'], item['JoinedTimestamp']
                ) for item in items
            ]
        elif all(isinstance(x, AwsAccount) for x in items):
            self.__accounts = items

    def add_account(self, account: AwsAccount):
        self.__accounts.append(account)

    def __repr__(self) -> str:
        return f'<OrganizationUnit({self.id}): {self.name}>'

    @property
    def metadata(self) -> dict:
        return {
            'ResourceName': self.name,
            'Id': self.id,
            'Arn': self.arn,
            'Name': self.name,
            'Account Name (AccountId)': ', '.join([
                f'{acc.name}({acc.account_id})' for acc in self.accounts
            ])
        }

    def get_resource_metadata(self, org_unit_sort_number: int, idx: int) -> dict:
        meta = self.metadata
        meta.pop('ResourceName', None)

        return {
            'Sort': org_unit_sort_number,
            'SubSort': idx,
            'ResourceName': self.name,
            'ResourceType': "Organization Unit",
            'Metadata': meta,
        }


class PolicyType:
    type: str
    status: str

    def __init__(self, type: str, status: str) -> None:
        self.type = type
        self.status = status

    def __repr__(self) -> str:
        return f'<PolicyType({self.type}): {self.status})>'


class AwsRoot:
    id: str
    arn: str
    name: str

    __account: AwsAccount = None
    __policy_types: List[PolicyType]
    __organizational_units: List[AwsOrganizationalUnit]

    def __init__(self, id: str, arn: str, name: str) -> None:
        self.id = id
        self.arn = arn
        self.name = name

        self.__policy_types = []
        self.__organizational_units = []

    @property
    def policy_types(self) -> List[PolicyType]:
        return self.__policy_types

    def add_policy_type(self, type: str, status: str):
        self.__policy_types.append(PolicyType(type, status))

    @property
    def organizational_units(self) -> List[AwsOrganizationalUnit]:
        return self.__organizational_units

    @organizational_units.setter
    def organizational_units(self, values: List[AwsOrganizationalUnit]):
        if all(isinstance(item, AwsOrganizationalUnit) for item in values):
            self.__organizational_units = values

    @property
    def account(self) -> AwsAccount:
        return self.__account

    @account.setter
    def account(self, value: AwsAccount):
        if isinstance(value, AwsAccount):
            self.__account = value

    def __repr__(self) -> str:
        return f'<Root({self.id}): {self.name}>'

    @property
    def metadata(self) -> dict:
        response = {
            'ResourceName': self.id,
            'RootId': self.id,
            'RootArn': self.arn,
            'RootAccountId': self.account.account_id,
            'RootAccountArn': self.account.arn,
            'RootAccountEmail': self.account.email,
            'RootAccountName': self.account.name,
            'RootAccountStatus': self.account.status,
            'Organization Units': ', '.join([org.name for org in self.organizational_units])
        }

        for policy_type in self.policy_types:
            response[policy_type.type] = policy_type.status

        return response

    @property
    def resource_metadata(self) -> dict:
        metadata = self.metadata
        metadata.pop('ResourceName')

        return {
            'Sort': 0,
            'SubSort': 0,
            'ResourceName': f'{self.id}@{self.account.account_id}',
            'ResourceType': 'Root Account',
            'Metadata': metadata,
        }


class Organization(CrossAccountClientBase):
    client_name = 'organizations'

    def __parse_root(self, data: dict) -> AwsRoot:
        root = AwsRoot(data['Id'], data['Arn'], data['Name'])
        for policy in data.get('PolicyTypes', []):
            root.add_policy_type(policy['Type'], policy['Status'])

        return root

    def __parse_account(self, data: dict) -> AwsAccount:
        return AwsAccount(
            data['Id'], data['Arn'], data['Email'], data['Name'],
            data['Status'], data['JoinedMethod'], data['JoinedTimestamp']
        )

    def __parse_organization_unit(self, data: dict) -> AwsOrganizationalUnit:
        return AwsOrganizationalUnit(data['Id'], data['Arn'], data['Name'])

    def get_all_provisions(
        self, account_id: str, cross_account_role: str, region_name: str = None,
        expected_org_units: List[str] = [],
        expected_accounts: List[str] = [],
    ) -> AwsRoot:
        self.refresh_client(account_id, cross_account_role, region_name)

        try:
            roots = [self.__parse_root(item) for item in self.client.list_roots()['Roots']]
        except Exception as e:
            self.log_exception(e)
            return []

        for root in roots[:1]:
            root.account = self.__parse_account(
                self.client.describe_account(AccountId=str(account_id))['Account'])
            org_units = [
                self.__parse_organization_unit(item) for item in
                self.client.list_organizational_units_for_parent(ParentId=str(root.id))['OrganizationalUnits']]
            root.organizational_units = [item for item in org_units if item.name in expected_org_units]

            for org_unit in root.organizational_units:
                self.log_info(
                    f"NOTE: Retrieving Account Metatada for OU: {org_unit.name}")
                accounts = [
                    self.__parse_account(item) for item in
                    self.client.list_accounts_for_parent(ParentId=org_unit.id)['Accounts']]
                org_unit.accounts = [acc for acc in accounts]  # if acc.account_id in expected_accounts]

        return roots[0]
