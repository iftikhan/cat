import React from 'react';
import PropTypes from 'prop-types';

import { Card, CardHeader, CardBody } from 'reactstrap';

// Object.entries(value).map(([subKey, subValue], subIdx) => (<><span key={subIdx}>{`${subKey}: ${subValue}`}</span></>))
const ResourceDetails = ({
  title, records,
}) => {
  const simpleTypes = [
    'string', 'number', 'boolean'
  ]
  const renderObject = (values) => {
    if (!values) {
      return null;
    } else if (values.constructor === Array) {
      return values.map((item, idx) => (
        <React.Fragment key={idx}><div>&nbsp;{simpleTypes.indexOf(typeof item) > -1  ? item : renderObject(item)}</div></React.Fragment>
      ))
    } else if (typeof values === 'object') {
      return Object.entries(values).map(([key, value], subIdx) => (
          <div key={subIdx}><div key={subIdx}><strong>{key}</strong>: {simpleTypes.indexOf(typeof value) > -1 ? value : <>{renderObject(value)}</>}</div></div>
        ))
    }
    return values.map((item, idx) => {
      if (typeof item === 'object') {
        return renderObject(item)
      } else {
        return <div key={idx}>{
          Object.entries(item).map(([key, value], subIdx) => (
            <div key={subIdx}><div key={subIdx}>{key}: {value}</div></div>
          ))
        }</div>
      }
    })
  }
  return (
    <Card>
      <CardHeader>{title}</CardHeader>
      <CardBody className='react-bootstrap-table'>
        <table className='table'>
          <thead className='thead-dark'>
            <tr>
              <th>S.N</th>
              <th>Resource</th>
              <th style={{maxWidth: '70%'}}>Resource Details</th>
            </tr>
          </thead>
          <tbody>
            {records.length > 0 && records.map(({
              ResourceName: resourceName, ResourceType: resourceType, Metadata: meta
            }, idx) => (
              <tr key={idx}>
                <td>{idx + 1}</td>
                <td>{`${resourceType} ${resourceName}`}</td>
                <td className='col-md-6'>{
                  Object.entries(meta).map(
                    ([key, value], idx) => (
                      <div key={idx}>
                        <strong>{key}</strong>: {typeof value === 'object' ? (<>{renderObject(value)}</>) : value}
                      </div>))}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </CardBody>
    </Card>
  )
}

ResourceDetails.propTypes = {
  title: PropTypes.string.isRequired,
  records: PropTypes.arrayOf(PropTypes.shape({

  }))
}

export default ResourceDetails;
