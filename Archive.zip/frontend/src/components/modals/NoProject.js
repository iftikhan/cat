import React from 'react';
import { useHistory } from 'react-router-dom';
import PropTypes from 'prop-types';

import {
  Modal, ModalHeader, ModalBody, ModalFooter, Button, FormGroup,
} from 'reactstrap';

const NoProjectModal = ({
  show,
}) => {
  const history = useHistory();
  return (
    <Modal show={show} onHide={() => {}}>
      <ModalHeader closeButton>
        <h5>Alert!</h5>
      </ModalHeader>
      <ModalBody>
        <FormGroup>
          <p>No project yet. Please create a new project before getting started!</p>
        </FormGroup>
      </ModalBody>
      <ModalFooter>
        <Button color="primary" onClick={() => {history.push('/gxp-qualification/admin/new')}}>
          Okay, create now
        </Button>
      </ModalFooter>
    </Modal>
  )
}

NoProjectModal.propTypes = {
  show: PropTypes.bool.isRequired,
}

export default NoProjectModal;
