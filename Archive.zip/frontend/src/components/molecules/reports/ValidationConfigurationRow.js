import React from 'react';
import PropTypes from 'prop-types';

import {
  Row, Col,
} from 'reactstrap';

const ValidationConfigurationRow = ({
  title, value
}) => {
  return (
    <li>
      <Row>
        <Col xs={3} sm={2}>
          {title}: 
        </Col>
        <Col>
          <strong>{value}</strong>
        </Col>
      </Row>
    </li>
  )
}

ValidationConfigurationRow.propTypes = {
  title: PropTypes.string.isRequired,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
}

export default ValidationConfigurationRow;
