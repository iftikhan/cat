import React from 'react';

import PropTypes from 'prop-types';

const SubTitle = ({
  title
}) => {
  return (
    <>
      <br />
      <h6 className={'sub-title'}>{title}</h6>
      <br />
    </>
  )
}

SubTitle.propTypes = {
  title: PropTypes.string.isRequired,
}

export default SubTitle;
