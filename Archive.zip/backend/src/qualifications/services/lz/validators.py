import io
import re
import json
from typing import Tuple

import boto3
import pandas as pd

from src.config import settings
from src.utils.logger import Logger
from src.utils.constants import DRAFT_FILE_PATTERN
from src.utils.validators import FileValidatorInterface


class LandingZoneExcelValidator(FileValidatorInterface):
    mandatory_column_list = [
        "ACCOUNTNUMBER", "ROLENAME", "REGION", "APPID", "RESOURCETYPE",
        "RESOURCEID", "EXPECTEDVARIABLE", "EXPECTEDVALUE"]
    non_missing_column_list = [
        "ACCOUNTNUMBER", "ROLENAME", "RESOURCETYPE", "EXPECTEDVARIABLE", "EXPECTEDVALUE"]

    def __init__(self) -> None:
        self.__logger = Logger()
        self.__s3_client = boto3.client('s3')

    def run(self, project_id: int, key_path: str, run_method: str) -> Tuple[bool, str]:
        match = re.search(DRAFT_FILE_PATTERN, key_path)

        project_id, user_id, input_filename = match.groups()
        output_filename = '.'.join(input_filename.split('.')[:-1] + ['json'])
        output_key_path = f'public/{project_id}/{user_id}/input/{output_filename}'

        try:
            object = self.__s3_client.get_object(Bucket=settings.STORAGE_BUCKET, Key=key_path)
            dataframe: pd.DataFrame = pd.read_excel(
                io.BytesIO(object['Body'].read()),
                sheet_name="ExpectedValues", engine='openpyxl')
        except Exception as e:
            self.__logger.log_exception(e)
            return False, None

        dataframe = dataframe.dropna(how='all')
        dataframe = dataframe.fillna('')
        dataframe.columns = [x.upper() for x in dataframe.columns]

        self.__logger.log_info(
            f"NOTE: s3://{settings.STORAGE_BUCKET}/{key_path} has been imported successfully")

        is_valid = self.validate_input_xlsx(dataframe)
        if not is_valid:
            return False, None

        # Write to JSON and store in S3
        records = dataframe.to_dict('records')

        landing_zone_input_json = {}
        landing_zone_input_json["Source"] = "LZ_EXCEL"
        landing_zone_input_json["LZ_EXCEL_S3_Name"] = settings.STORAGE_BUCKET
        landing_zone_input_json["LZ_EXCEL_S3_Key"] = key_path
        landing_zone_input_json["LZ_EXCEL_FileName"] = input_filename
        landing_zone_input_json["LZ_JSON_S3_Name"] = settings.STORAGE_BUCKET
        landing_zone_input_json["LZ_JSON_S3_Key"] = output_key_path
        landing_zone_input_json["LZ_JSON_S3_FileName"] = output_filename
        landing_zone_input_json["LZ_JSON_FileDetails"] = records

        try:
            self.__s3_client.put_object(
                Body=str(json.dumps(landing_zone_input_json, indent=4)),
                Bucket=settings.STORAGE_BUCKET, Key=output_key_path)
        except Exception as e:
            self.__logger.log_exception(e)
            return False, None

        self.__logger.log_info(
            f"NOTE: JSON output has been written to s3://{settings.STORAGE_BUCKET}/{output_key_path}")

        # Return XLSX JSON
        return True, output_key_path

    def check_mandatory_columns(self, input_pd_data: pd.DataFrame):
        self.__logger.log_info('Checking mandatory columns...')
        valid = True
        for col in self.mandatory_column_list:
            if col.lower() not in input_pd_data.columns.str.lower():
                self.__logger.log_info(f"ERROR: {col} Column Not found in Input Excel File")
                valid = False
        return valid

    def check_non_missing_columns(self, input_pd_data: pd.DataFrame):
        self.__logger.log_info('Checking missing columns...')
        valid = True
        for col in self.non_missing_column_list:
            if (input_pd_data[col] == "").any():
                self.__logger.log_info(f"ERROR: {col} column have missing values")
                valid = False
        return valid

    def validate_input_xlsx(self, input_pd_data: pd.DataFrame):
        self.__logger.log_info("NOTE: Validating input excel file...")
        check_mandatory_col = self.check_mandatory_columns(input_pd_data)
        check_non_missing_col = self.check_non_missing_columns(input_pd_data)
        return check_mandatory_col and check_non_missing_col
