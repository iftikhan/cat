import createReducer from 'redux/helpers/createReducer';

import {
  namespace,
  fetchParameterRequest, fetchParameterSuccess, fetchParameterFailure,
  fetchJobsRequest, fetchJobsSuccess, fetchJobsFailure,
  fetchJobDetailsRequest, fetchJobDetailsSuccess, fetchJobDetailsFailure,
  uploadGxPRequest, uploadGxPSuccess, uploadGxPFailure, setUploadProgress,

  setProjectDraft,
  fetchProjectsRequest, fetchProjectsSuccess, fetchProjectsFailure,
} from './actions';

const defaultState = {
  fetchingProjects: false,
  fetchingProjectsFinished: false,
  projects: [],
  parameters: [],
  qualificationTypes: [],
  projectDraft: {},
  fetchingParameter: false,
  fetchingRules: false,
  rules: [],
  uploadingGxP: false,
  uploadProgress: 0,
  jobs: [],
  fetchingJobs: false,
  job: null,
  fetchingJobDetails: false,
  comparedSummaries: [],
  landingZones: [],
}

const reducer = createReducer(namespace, defaultState, {
  [fetchProjectsRequest.Type]: (state, action) => ({
    ...state,
    fetchingProjects: true,
    fetchingProjectsFinished: false,
  }),
  [fetchProjectsSuccess.Type]: (state, action: { payload: { projects: Array<Object> }}) => ({
    ...state,
    fetchingProjects: false,
    fetchingProjectsFinished: true,
    projects: action.payload.projects,
  }),
  [fetchProjectsFailure.Type]: (state, action) => ({
    ...state,
    fetchingProjects: false,
    fetchingProjectsFinished: true,
  }),
  [setProjectDraft.Type]: (state, { payload }) => ({
    ...state,
    projectDraft: payload,
  }),
  [fetchParameterRequest.Type]: (state, action) => ({
    ...state,
    fetchingParameter: true,
  }),
  [fetchParameterSuccess.Type]: (state, action: {
    payload: {
      parameters: Array<Object>,
      qualificationTypes: Array<Object>,
      landingZones: Array<Object>,
    }
  }) => ({
    ...state,
    fetchingParameter: false,
    parameters: action.payload.parameters,
    qualificationTypes: action.payload.qualificationTypes,
    landingZones: action.payload.landingZones,
  }),
  [fetchParameterFailure.Type]: (state, action) => ({
    ...state,
    fetchingParameter: false,
  }),
  [uploadGxPRequest.Type]: (state, action) => ({
    ...state,
    uploadingGxP: true,
    uploadProgress: 0,
  }),
  [uploadGxPSuccess.Type]: (state, action) => ({
    ...state,
    uploadingGxP: false,
    uploadProgress: 0,
  }),
  [uploadGxPFailure.Type]: (state, action) => ({
    ...state,
    uploadingGxP: false,
    uploadProgress: 0,
  }),
  [setUploadProgress.Type]: (state, action) => ({
    ...state,
    uploadProgress: action.payload.progress,
  }),
  [fetchJobsRequest.Type]: (state, action) => ({
    ...state,
    fetchingJobs: true,
  }),
  [fetchJobsSuccess.Type]: (state, action: { payload: { jobs: Array<Object> } }) => ({
    ...state,
    fetchingJobs: false,
    jobs: action.payload.jobs,
  }),
  [fetchJobsFailure.Type]: (state, action) => ({
    ...state,
    fetchingJobs: false,
  }),
  [fetchJobDetailsRequest.Type]: (state, action) => ({
    ...state,
    fetchingJobDetails: true,
  }),
  [fetchJobDetailsSuccess.Type]: (state, action: { payload: { job: Object } }) => ({
    ...state,
    job: action.payload.job,
    fetchingJobDetails: false,
  }),
  [fetchJobDetailsFailure.Type]: (state, action) => ({
    ...state,
    fetchingJobDetails: false,
  }),
});

export default reducer;
export { namespace };
