from datetime import datetime
from typing import List
from src.utils.constants import CloudProvider

class ManagedConfigRule:
    id: int
    name: str
    provider: CloudProvider
    description: str
    services: List[str]
    standards: List[str]
    tags: List[str]
    is_applied_to_account: bool = False
    number_of_accounts_applied: int = 0

    def __init__(
        self, id: int, name: str, provider: CloudProvider, description: str,
        services: List[str], standards: List[str], tags: List[str],
        is_applied_to_account: bool = False,
        number_of_accounts_applied: int = 0,
    ) -> None:
        self.id = id
        self.provider = provider
        self.name = name
        self.description = description
        self.services = services
        self.standards = standards
        self.tags = tags
        self.is_applied_to_account = is_applied_to_account
        self.number_of_accounts_applied = number_of_accounts_applied

    def to_dict(self) -> str:
        return {
            'id': self.id,
            'name': self.name,
            'provider': self.provider,
            'description': self.description,
            'services': self.services,
            'standards': self.standards,
            'tags': self.tags,
            'is_applied_to_account': self.is_applied_to_account,
            'number_of_accounts_applied': self.number_of_accounts_applied,
        }

    def __repr__(self) -> str:
        return f'<ManagedConfigRule({self.id}): {self.name}>'

    def __str__(self) -> str:
        return self.name


class AccountConfigRule:
    id: int
    managed_rule: ManagedConfigRule
    landing_zone_account_id: int
    applied_by: str
    arn: str
    created_at: datetime
    updated_at: datetime

    def __init__(
        self, landing_zone_account_id: int, applied_by: str, managed_rule_id: int,
        id: int = None, created_at: datetime = None, updated_at: datetime = None,
        arn: str = None, **managed_rule_properties,
    ) -> None:
        self.id = id
        self.landing_zone_account_id = landing_zone_account_id
        self.applied_by = applied_by
        self.arn = arn
        self.created_at = created_at
        self.updated_at = updated_at
        self.managed_rule = ManagedConfigRule(
            id=managed_rule_id,
            **managed_rule_properties
        )

    def __repr__(self) -> str:
        return f'<AccountRule({self.managed_rule.id}@{self.landing_zone_account_id}): {self.managed_rule.name}>'

    def __str__(self) -> str:
        return f'{self.managed_rule}@{self.landing_zone_account_id}'

    def to_dict(self) -> dict:
        response = {
            'landing_zone_account_id': self.landing_zone_account_id,
            'arn': self.arn,
            'applied_by': self.applied_by,
            'created_at': self.created_at,
            'updated_at': self.updated_at,
            'managed_rule': self.managed_rule.to_dict(),
        }

        if self.id:
            response.update({
                'id': self.id,
                'created_at': self.created_at,
            })

        return response
