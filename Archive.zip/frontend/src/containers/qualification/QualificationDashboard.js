import React, { useEffect, useState } from 'react';
import classnames from 'classnames';
import { Button } from 'reactstrap';
import { AiFillFilePdf } from 'react-icons/ai';

import { Chart } from 'react-google-charts';
import { Col } from 'reactstrap';

import API from 'helpers/api';
import LoadingModal from 'components/modals/Loading';

import SearchTable from 'components/tables/SearchTable';

const QualificationDashboard = () => {
  const [jobs, setJobs] = useState(null);
  const [runNumbers, setRunNumbers] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setIsLoading(true);
    API.getJobsDashboard().then(({jobs, run_per_account: runReport}) => {
      setJobs(jobs);
      setRunNumbers(runReport);
    }).catch(err => {
      console.error(err);
    }).finally(() => {
      setIsLoading(false);
    });
  }, [setJobs, setRunNumbers]);

  const onDownloadClicked = (jobId: Number, url: String) => {
    setIsLoading(true)
    API.downloadReport(jobId, url).then(() => {
      setIsLoading(false);
    }).catch(() => {
      setIsLoading(false);
    })
  };

  const columns = [
    {
      dataField: 'id',
      text: 'Job ID',
    },
    {
      dataField: 'created_by',
      text: 'Created By',
    },
    {
      dataField: 'created_at',
      text: 'Created Date',
    },
    {
      dataField: 'qualification_type',
      text: 'Qualification Type',
    },
    {
      dataField: 'account_id',
      text: 'Account ID',
    },
    {
      text: '',
      dataField: 'total_test',
      formatter: (cel, row, index) => {
        const { test_summary: testSummary = {} } = row;
        return (
          <>{testSummary.passed}/{testSummary.failed}</>
        )
      },
      headerFormatter: (col, colIndex, components) => {
        return (
          <>Total<br/>Test<br/>Passed/Failed</>
        )
      },
      headerStyle: {textAlign: 'center'},
      style: {textAlign: 'center'},
    },
    {
      text: '',
      dataField: 'compliance_score',
      headerFormatter: (col, colIndex, components) => {
        return <>Compliance<br/>Score</>
      },
      headerStyle: {textAlign: 'center'},
      style: {textAlign: 'center'},
      formatter: (cel, row, rowIndex) => {
        const { test_summary: testSummary = {} } = row;
        return (
        <>
          {
            testSummary.total > 0
            ? `${(testSummary.passed / testSummary.total * 100).toFixed(2)} %`
            : null
          }
        </>)
      }
    },
    {
      text: '',
      dataField: 'action',
      formatter: (cel, row, rowIndex) => {
        const { url, id: jobId } = row;
        return (
          <>
            {url && (
              <Button
                title='Download PDF Report'
                className={classnames('btn-sm')}
                onClick={() => onDownloadClicked(jobId, url)}><AiFillFilePdf /></Button>)
            }
          </>
        )
      }
    }
  ]

  return (
    <>
      <br />
      {runNumbers && (
        <Col>
          <Chart
            // width={'500px'}
            height={'300px'}
            chartType="Bar"
            loader={<div>Loading Chart Data...</div>}
            data={[
              ['Account ID', 'Number of Run'],
              ...runNumbers]}
            options={{
              // Material design options
              chart: {
                title: 'Report',
                subtitle: 'Number of Jobs run per account',
              },
            }}
            // For tests
            rootProps={{ 'data-testid': '2' }}
          />
        </Col>)
      }
      {jobs && <SearchTable
        columns={columns}
        data={jobs} keyField='id'
      />}
      <LoadingModal show={isLoading} />
    </>
  )
}

export default QualificationDashboard;
