import re
import json
from typing import Any

from src.config import settings
from src.utils.response import build_response
from src.utils.auth import get_authenticated_user
from src.utils.aws import LambdaFunction
from src.qualifications.services.jobs import JobsLibrary
from src.models.jobs import JobsModel


def manage_jobs(event, context):
    model = JobsModel()
    user_id = get_authenticated_user(event)
    http_method = event['requestContext']['httpMethod']
    query_params = event.get('queryStringParameters') or {}
    http_path = event['path']
    path_params = event.get('pathParameters', {})
    service = JobsLibrary()

    if http_path == '/qua/jobs':
        if http_method == 'GET':
            created_by = query_params.get('created_by')
            jobs = model.list_jobs_by_user(created_by)
            return build_response({
                'jobs': [job.to_response() for job in jobs],
            })
        elif http_method == 'POST':
            params = json.loads(event['body'] or '{}')
            required_params = ['project_id', 'key_path', 'run_method']
            for attr in required_params:
                if attr not in params or not params.get(attr):
                    return build_response({
                        'msg': f'{attr} is required',
                    }, 400)

            key_path = f"public/{params['key_path']}"
            project_id = params['project_id']
            run_method = params['run_method']
            validate_result = service.validate(project_id, key_path, run_method)

            if any(not x for x in validate_result.values()):
                return build_response(validate_result, 400)

            output_key_path = validate_result.pop('output_key_path')
            job_id = model.create(user_id, project_id, run_method, key_path=output_key_path)
            LambdaFunction.invoke_lambda(settings.INIT_JOB_FUNCTION_NAME, {'job_id': job_id})
            return build_response(validate_result, 201)
    elif http_path == '/qua/jobs/status':
        params = json.loads(event['body'] or '{}')
        if not params.get('job_ids'):
            return build_response({
                'msg': 'job_ids is required.'
            })
        return build_response({
            'job_status': model.get_status(params['job_ids'])
        })
    elif http_path == '/qua/jobs/dashboard':
        return build_response(model.get_jobs_dashboard())
    elif 'job_id' in path_params:
        job_id = path_params['job_id']
        if http_method == 'GET':
            if re.search(rf'^\/qua\/jobs\/{job_id}\/?$', http_path):
                instance = model.get_job(job_id)

                if instance is None:
                    return build_response({}, 404)

                return build_response({
                    'job': instance.to_response(with_report_details=True),
                })


def init_job(event, context: Any = None):
    job_id = event['job_id']
    service = JobsLibrary()
    service.init_job(job_id)


def validate(event, context: Any = None):
    job_id = event['job_id']
    key_path = event['key_path']
    level = event['level']
    rule_ids = event['rules']

    service = JobsLibrary()
    service.validate(job_id, key_path, level, rule_ids)


__all__ = ('manage_jobs', 'init_job', 'validate', )
