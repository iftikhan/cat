import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import API from 'helpers/api';

import {
  fetchAccountsRequest, fetchUsersRequest,
} from 'containers/admin/actions';

import AccountsTable from './AccountsTable';
import UsersTable from './UsersTable';

const Admin = ({
  accounts, fetchAccountsRequest, fetchingAccounts,
  users, fetchUsersRequest, fetchingUsers,
}) => {

  useEffect(() => {
    fetchAccountsRequest();
    fetchUsersRequest();
  }, [
    fetchAccountsRequest,
    fetchUsersRequest,
  ])

  const createNewAccount = (
    accountName, accountID, awsAccessKeyID, awsSecretAccessKey,
  ) => {
    return API.createAccount(accountName, accountID, awsAccessKeyID, awsSecretAccessKey).then(() => {
      fetchAccountsRequest();
    }).catch(() => {
      alert('Something went wrong');
    })
  }

  const updateAccount = (id: String) => (
    accountName, accountID, awsAccessKeyID, awsSecretAccessKey,
  ) => {
    return API.updateAccount(id, accountName, accountID, awsAccessKeyID, awsSecretAccessKey).then(() => {
      fetchAccountsRequest();
    }).catch(() => {
      alert('Something went wrong');
    })
  }

  const onInviteUser = (payload: {email: String, role: String}) => {
    return API.inviteUser(payload.email, payload.role).then(() => {
      fetchUsersRequest();
    }).catch(() => {
      alert('Something went wrong.')
    })
  }

  const onUpdateUser = (userId: String) => (payload: {role: String}) => {
    return API.updateUserRole(userId, payload.role).then(() => {
      fetchUsersRequest();
    }).catch(() => {
      alert('Something went wrong');
    })
  }

  return (
    <>
      <AccountsTable
        accounts={accounts}
        isLoading={fetchingAccounts}
        onNewAccount={createNewAccount}
        onUpdateAccount={updateAccount}
        />
      <UsersTable
        users={users}
        isLoading={fetchingUsers}
        onInviteUser={onInviteUser}
        onUpdateUser={onUpdateUser}
        />
    </>
  )
}

const mapStateToProps = state => ({
  fetchingAccounts: state.admin.fetchingAccounts,
  accounts: state.admin.accounts,
  fetchingUsers: state.admin.fetchingUsers,
  users: state.admin.users,
});

const mapDispatchToProps = dispatch => ({
  fetchAccountsRequest: () => dispatch(fetchAccountsRequest()),
  fetchUsersRequest: () => dispatch(fetchUsersRequest()),
});

Admin.propTypes = {
  fetchingAccounts: PropTypes.bool.isRequired,
  accounts: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.string.isRequired,
  })),
  fetchAccountsRequest: PropTypes.func.isRequired,
  fetchUsersRequest: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(Admin);
