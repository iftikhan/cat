from typing import Dict

from urllib.parse import unquote_plus

from src.config import settings
from src.utils.logger import Logger
from src.utils.aws.s3 import S3Util
from src.models.jobs import JobEntry
from src.models.admin.projects import ProjectModel
from src.qualifications.services.core import ServiceInterface
from src.qualifications.services.lz.entires import LandingZoneEntry
from .validators import LandingZoneExcelValidator
from .resources import LandingZoneResourceCollector
from .report import LandingZoneReport


class LandingZoneService(ServiceInterface):
    def __init__(self) -> None:
        self.__s3_util = S3Util()

        self.__logger = Logger()

    def validate(self, project_id: int, key_path: str, run_method: str) -> Dict[str, bool]:
        key_path = unquote_plus(key_path)
        validator = LandingZoneExcelValidator()
        is_valid, output_key_path = validator.run(project_id, key_path, run_method)
        if is_valid:
            return {
                'excel': True,
                'assume_role': True,
                'ec2': True,
                'iam': True,
                'output_key_path': output_key_path,
            }
        else:
            return {
                'excel': False,
                'assume_role': True,
                'ec2': True,
                'iam': True,
                'output_key_path': output_key_path,
            }

    def generate_report(self, job_entry: JobEntry, key_path: str) -> str:
        report_util = LandingZoneReport()
        return report_util.generate_report(job_entry, key_path)

    def collect_resource(self, job_entry: JobEntry):
        self.__logger.log_info('Collecting resource for Landing zone...')

        project_model = ProjectModel()
        resource_collector = LandingZoneResourceCollector()

        project = project_model.get_detail(job_entry.project_id)
        expected_file_content = self.__s3_util.read_json_file(settings.STORAGE_BUCKET, job_entry.s3_input_url)

        output_folder_name = f'public/{job_entry.project_id}/{job_entry.user_id}/{job_entry.id}/resource-collector'

        expected_val_input_json = expected_file_content["LZ_JSON_FileDetails"]
        expected_build_source = expected_file_content["LZ_EXCEL_S3_Key"]
        supported_resources = ["ec2", "ebs", "vpc", "root", "ou", "account"]
        master_account_number = project.setting.get('master_account_number')

        entries = [LandingZoneEntry(
            row['ACCOUNTNUMBER'], row['REGION'], row['APPID'], row['RESOURCETYPE'],
            row['RESOURCEID'], row['EXPECTEDVARIABLE'], row['EXPECTEDVALUE'],
            role_name=row['ROLENAME']
        ) for row in expected_val_input_json]

        # Call Resource Collector Function
        return resource_collector.run_resource_collector(
            job_entry, entries, project.parameters, expected_build_source,
            output_folder_name, supported_resources, master_account_number)
