import React, { useCallback, useEffect, useState } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
// import { useHistory } from 'react-router-dom';

import {
  Row, Col, FormGroup, Button, Input,
  Modal, ModalHeader, ModalBody, ModalFooter,
  Card, CardHeader, CardBody,
} from 'reactstrap';
import BootstrapTable from 'react-bootstrap-table-next';
// import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';
import cellEditFactory from 'react-bootstrap-table2-editor';

import API from 'helpers/api';

import {
  fetchParameterRequest,
} from 'containers/qualification/actions';

import NewAccountForm from 'components/molecules/infra/NewAccountForm';

const LandingZoneAdmin = ({
  fetchingProjects, fetchingProjectsFinished,
  fetchParameterRequest, parameters, qualificationTypes,
}) => {
  const fetchingParameter = false;
  const [curLandingZone, setCurLandingZone] = useState(null);
  const [accounts, setAccounts] = useState([])

  const [showNewLandingZoneModal, setShowNewLandingZoneModal] = useState(false);
  const [newLandingZoneName, setNewLandingZoneName] = useState('');

  const [landingZoneName, setLandingZoneName] = useState('');

  // const history = useHistory();

  const [landingZones, setLandingZones] = useState([]);

  const getLandingZones = useCallback(() => {
    API.infrastructure.getLandingZones().then(({landing_zones: items}) => {
      setLandingZones(items);
      if (items.length === 0) {
        setShowNewLandingZoneModal(true);
      } else {
        const [first] = items;
        setCurLandingZone(first);
      }
    }).catch(err => {
      console.error(err);
      alert('Failed to fetch landing zones')
    }).finally(() => {
      console.log('Done: Fetching landing zones')
    })
  }, [setLandingZones, setCurLandingZone, setShowNewLandingZoneModal])

  useEffect(() => {
    getLandingZones()
  }, [getLandingZones])

  const onCreateNewLandingZone = () => {
    API.infrastructure.createLandingZone(newLandingZoneName).then(({status, msg}) => {
      if (status) {
        setShowNewLandingZoneModal(false)
        getLandingZones()
      } else {
        alert(msg)
      }
    }).catch(err => {
      console.error(err);
      alert('Failed to create a new landing zone');
    })
  }

  useEffect(() => {
    if (landingZones.length > 0) {
      const [first] = landingZones;
      setCurLandingZone(first)
    }
  }, [landingZones])

  const fetchLandingZoneAccounts = useCallback(() => {
    const { id: landingZoneId } = curLandingZone;
    API.fetchLandingZoneAccounts(landingZoneId).then((response: {
      accounts: Array<Object>
    }) => {
      console.log(response.accounts)
      setAccounts(response.accounts)
    }).catch(() => {
      alert('something went wrong!');
    })
  }, [setAccounts, curLandingZone])

  useEffect(() => {
    if (curLandingZone) {
      const { name } = curLandingZone;
      setLandingZoneName(name);

      fetchLandingZoneAccounts()
    }
  }, [
    curLandingZone, setLandingZoneName, fetchLandingZoneAccounts,
  ]);

  const onProjectSelect = (projectId: Number) => {
    const [cur] = landingZones.filter(project => project.id === parseInt(projectId));
    if (cur) {
      setCurLandingZone(cur);
    }
  }

  const onChangeAccountAttribute = (landingZoneId: Number, accountId: Number, attr: String, value: any) => {
    API.updateLandingZoneAccountPartial(landingZoneId, accountId, attr, value).then(() => {
      setAccounts(
        accounts.map(item => item.id === accountId ? {...item, [attr]: value} : item)
      );
    }).catch(() => {alert('failed to update project paramter.')})
  }

  const columns = [
    {
      dataField: 'organization_unit',
      text: 'OU',
      // filter: textFilter(),
      // headerStyle: {width: '140px'},
      editable: true,
    }, {
      dataField: 'name',
      text: 'Account Name',
      // filter: textFilter(),
      // headerStyle: {width: '160px'},
      editable: true,
    }, {
      dataField: 'account_id',
      text: 'Account Number',
      // filter: textFilter(),
      // headerStyle: {width: '120px'},
      editable: true,
    }, {
      dataField: 'cross_account_role_name',
      text: 'Assume Role Name',
      // filter: textFilter(),
      // headerStyle: {width: '120px'},
      editable: true,
    }, {
      dataField: '',
      text: '',
      // filter: textFilter(),
      headerStyle: {width: '120px'},
      editable: false,
    },
  ];

  const afterSaveCell = (oldValue, newValue, row, column) => {
    const { landing_zone_id: landingZoneId, id: accountId } = row;
    const { dataField: attr } = column;
    onChangeAccountAttribute(landingZoneId, accountId, attr, newValue);
  }

  const onCreateAccount = (
    organizationUnit: String, accountId: String, accountName: String, roleName: String, description: String = ''
  ) => {
    const { id: landingZoneId } = curLandingZone;
    return API.createLandingZoneAccount(
      landingZoneId, organizationUnit, accountName,
      accountId, roleName, description
    ).then(({status}) => {
      console.log(status);
      fetchLandingZoneAccounts()
    }).catch(err => {
      alert(err?.response?.data?.msg || 'Failed to create the account.')
    }).finally(() => {
      console.log('Do something here.')
    })
  }

  const onUpdateLandingZone = () => {
    const { id: landingZoneId } = curLandingZone;
    API.infrastructure.updateLandingZone(landingZoneId, landingZoneName).then(() => {
      console.log('Saved successfully');
      getLandingZones();
    }).catch(() => {
      alert('failed to save project.')
    })
  }

  return (
    <>
      <FormGroup className="mb-3" disabled={fetchingParameter}>
        <Row>
          <Col sm={3}>
            <label className='mt-2' htmlFor='landing-zone-admin-landing-zone-dropdown'>Select Landing Zone</label>
          </Col>
          <Col sm={4}>
            <Input
              type="select" value={curLandingZone?.id}
              onChange={(event) => {onProjectSelect(event.target.value)}}>
              {landingZones.map(({id, name}, idx) => (
                <option key={id} value={id}>{name}</option>
              ))}
            </Input>
          </Col>
          <Col >
            <Button onClick={onUpdateLandingZone} color='primary'>Save</Button>
            &nbsp;&nbsp;&nbsp;OR&nbsp;&nbsp;&nbsp;
            <Button color='danger' onClick={() => {setShowNewLandingZoneModal(true)}}>Create</Button>
          </Col>
        </Row>
      </FormGroup>
      <hr />
      <FormGroup className="" disabled={fetchingParameter}>
        <Row>
          <Col sm="3">
            <label className='mt-2' htmlFor='landing-zone-admin-landing-zone-name'>Landing Zone Name</label>
          </Col>
          <Col sm="5">
            <Input
              type='text'
              value={landingZoneName}
              onChange={e => setLandingZoneName(e.target.value)} />
          </Col>
        </Row>
      </FormGroup>
      <NewAccountForm onSubmit={onCreateAccount} />
      <Card>
        <CardHeader>Landing Zone Accounts</CardHeader>
        <CardBody>
          {accounts.length > 0 && (
          <BootstrapTable
            keyField='id' data={accounts} columns={columns}
            classes='align-items-center'
            // filter={filterFactory()} //rowClasses={rowClasses}
            noDataIndication={'No parameter? Weird.'}
            cellEdit={ cellEditFactory({ mode: 'click', afterSaveCell }) }
            headerClasses='thead-dark'
            />
          )}
        </CardBody>
      </Card>

      <Modal isOpen={showNewLandingZoneModal} toggle={() => setShowNewLandingZoneModal(landingZones.length === 0)}>
        <ModalHeader>
          Create New Landing Zone
        </ModalHeader>
        <ModalBody>
          <FormGroup>
            <h5>Please enter the name of landing zone you want to create</h5>
          </FormGroup>
          <FormGroup className="mb-3" disabled={fetchingParameter}>
            <Row>
              <Col sm={5} xs={6}>
                <label className='mt-2'>Landing Zone Name</label>
              </Col>
              <Col sm={7} xs={6}>
                <Input
                  type='text'
                  value={newLandingZoneName}
                  onChange={e => setNewLandingZoneName(e.target.value)} />
              </Col>
            </Row>
          </FormGroup>
        </ModalBody>
        <ModalFooter>
          <Button
            disabled={newLandingZoneName.trim().length === 0} color="primary"
            onClick={onCreateNewLandingZone}>
            Okay, create now
          </Button>
        </ModalFooter>
      </Modal>
    </>
  )
};

LandingZoneAdmin.propTypes = {
  fetchingProjects: PropTypes.bool.isRequired,
  fetchingProjectsFinished: PropTypes.bool.isRequired,
  fetchingParameter: PropTypes.bool.isRequired,

  fetchParameterRequest: PropTypes.func.isRequired,
}

const mapStateToProps = state => ({
  fetchingProjects: state.qualifications.fetchingProjects,
  fetchingProjectsFinished: state.qualifications.fetchingProjectsFinished,
  fetchingParameter: state.qualifications.fetchingParameter,
  parameters: state.qualifications.parameters,
  qualificationTypes: state.qualifications.qualificationTypes,
});

const mapDispatchToProps = dispatch => ({
  fetchParameterRequest: () => dispatch(fetchParameterRequest()),
})

export default connect(mapStateToProps, mapDispatchToProps)(LandingZoneAdmin);
