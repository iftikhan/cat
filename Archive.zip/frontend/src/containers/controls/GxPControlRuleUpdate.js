import React, { useEffect, useState } from 'react';

import { useParams, useHistory } from 'react-router';

import {
  Card, CardHeader, CardBody, CardFooter,
  Row, Col, Input, Button,
} from 'reactstrap';

import API from 'helpers/api';

import TagsInput from "components/TagsInput/TagsInput.js";

import CloudProviderSelect from 'components/molecules/controls/CloudProviderSelect';
import CloudServicesSelect from 'components/molecules/controls/CloudServicesSelect';
import CloudComplianceStandarSelect from 'components/molecules/controls/CloudComplianceStandarSelect';
import ConfirmModal from 'components/modals/ConfirmModal';

const GxPControlRuleUpdate = () => {
  const { ruleId } = useParams();
  const [rule, setRule] = useState({});
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const history = useHistory();

  const {
    name = '',
    description = '',
    provider = '',
    services = [],
    standards = [],
    tags = [],
  } = rule;

  const onChange = (attr: String) => (value) => {
    setRule({
      ...rule,
      [attr]: value,
    })
  }

  const onSubmitUpdate = () => {
    API.controls.updateManagedRule(ruleId, {
      name, description, provider, services, standards, tags,
    }).then(({status}) => {
      console.log('SUCCESS');
    }).catch(err => {
      console.error(err);
    }).finally(() => {
      setShowConfirmModal(false);
    });
  }

  useEffect(() => {
    API.controls.retrieveManagedRule(ruleId)
    .then(({status, rule: details}) => {
      if (status) {
        setRule(details);
      }
    }).catch(err => {
      console.error(err);
    })
  }, [setRule, ruleId,]);

  return (
    <Card>
      <CardHeader>Update Control Rule</CardHeader>
      <CardBody>
        <Row>
          <Col sm={3} lg={2}>
            <label className='mt-2' htmlFor='rule-update-form-name'>Rule Name</label>
          </Col>
          <Col sm={4} md={5} lg={6}>
            <Input
              value={name} className='form-control' id='rule-update-form-name'
              onChange={e => {onChange('name')(e.target.value)}} />
          </Col>
          <Col>
            <CloudProviderSelect
              value={provider} className='form-control' renderEmpty={false}
              onChange={(value) => {onChange('provider')(value)}}
              />
          </Col>
        </Row>
        <Row>
          <Col className='mt-3' sm={3} lg={2}>
            <label className='mt-2' htmlFor='rule-update-form-services'>Services</label>
          </Col>
          <Col className='mt-3' sm={9} lg={4}>
            <CloudServicesSelect
              value={services} className='form-control' multiple provider={provider}
              onChange={(selected) => {onChange('services')(selected)}} />
          </Col>
          <Col className='mt-3' sm={3} lg={2}>
            <label className='mt-2' htmlFor='rule-update-form-services'>Standards</label>
          </Col>
          <Col className='mt-3' sm={9} lg={4}>
            <CloudComplianceStandarSelect
              value={standards} className='form-control' multiple
              onChange={(selected) => {onChange('standards')(selected)}} />
          </Col>
        </Row>
        <Row className='mt-3'>
          <Col sm={3} lg={2}>
            <label htmlFor='rule-update-form-description'>Description</label>
          </Col>
          <Col>
            <Input
              type='textarea' id='rule-update-form-description' className='form-control' rows={5}
              value={description} onChange={e => {onChange('description')(e.target.value)}}
              />
          </Col>
        </Row>
        <Row className='mt-3'>
          <Col sm={3} lg={2}>
            <label htmlFor='rule-update-form-tags'>Tags</label>
          </Col>
          <Col>
            <TagsInput
              onlyUnique
              id='rule-update-form-tags'
              className="bootstrap-tagsinput"
              onChange={(value) => onChange('tags')(value)}
              value={tags}
              tagProps={{ className: "tag badge badge-sm mr-1" }}
              inputProps={{
                className: "form-control",
                placeholder: "Type here to set tags",
              }}
            />
          </Col>
        </Row>
      </CardBody>
      <CardFooter>
        <Row>
          <Col>
            <Button
              color='secondary'
              onClick={() => history.push('/gxp-control/manage')}>Cancel</Button>
          </Col>
          <Col>
            <Button
              color='primary' className='float-right'
              onClick={() => {setShowConfirmModal(true)}}>Save</Button>
          </Col>
        </Row>
      </CardFooter>
      <ConfirmModal
        show={showConfirmModal} title='Confirm!'
        onOkay={onSubmitUpdate}
        description={`Are you sure to update this rule?`}
        onCancel={() => {setShowConfirmModal(false)}} />
    </Card>
  )
};

export default GxPControlRuleUpdate;
