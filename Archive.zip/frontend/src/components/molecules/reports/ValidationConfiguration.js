import React from 'react';
import PropTypes from 'prop-types';

import ValidationConfigurationRow from './ValidationConfigurationRow';


const ValidationConfiguration = ({
  title, data,
}) => {
  const {
    project, study, version, dataset, status, endedAt, author,
  } = data;

  return (
    <>
      <h6>{title}</h6>
      <br />
      <ul>
        <ValidationConfigurationRow title='Project'
          value={project} />
        <ValidationConfigurationRow title='Study'
          value={study} />
        <ValidationConfigurationRow title='Version'
          value={version} />
        <ValidationConfigurationRow title='Dataset'
          value={dataset} />
        <ValidationConfigurationRow title='Created By'
          value={author} />
        <ValidationConfigurationRow title='Job Status'
          value={status === 'Run Successful' ? `Successfully completed on ${endedAt}` : status} />
      </ul>
    </>
  )
}

ValidationConfiguration.propTypes = {
  title: PropTypes.string.isRequired,
  data: PropTypes.shape({
    project: PropTypes.any.isRequired,
    study: PropTypes.string.isRequired,
    version: PropTypes.string.isRequired,
    dataset: PropTypes.string.isRequired,
    status: PropTypes.string.isRequired,
    endedAt: PropTypes.string.isRequired,
    author: PropTypes.string.isRequired,
  })
}

export default ValidationConfiguration;
