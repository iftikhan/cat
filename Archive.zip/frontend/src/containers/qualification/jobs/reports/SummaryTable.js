import React from "react";
import PropTypes from 'prop-types';
import classnames from "classnames";

import {
  Card, CardHeader, CardBody,
} from 'reactstrap';

import BootstrapTable from 'react-bootstrap-table-next';

const SummaryTable = ({
  testSummary,
}) => {
  const { build_summary: buildSummary, post_build_summary: postBuildSummary } = testSummary;

  const summaryColumns = [
    {
      dataField: 'identifier',
      text: 'IQ/OQ',
      style: {textAlign: 'center'},
      headerStyle: {textAlign: 'center'},
    }, {
      dataField: 'total_test_cases',
      text: 'Number of Tests',
      style: {textAlign: 'center'},
      headerStyle: {textAlign: 'center'},
    }, {
      dataField: 'total_passed_cases',
      style: {textAlign: 'center'},
      headerStyle: {textAlign: 'center'},
      text: 'Passed'
    }, {
      dataField: 'total_failed_cases',
      style: {textAlign: 'center'},
      headerStyle: {textAlign: 'center'},
      text: 'Failed'
    },
  ]

  const summaryData = Object.entries(testSummary || {}).map(([key, value]) => ({
    ...value,
    identifier: key === 'build_summary' ? 'IQ' : 'OQ'
  }));
  const totalSummary = Object.keys(buildSummary).map((key) => {
    const buildSummaryValue = buildSummary[key];
    const postBuildSummaryValue = postBuildSummary[key]
    return [key, buildSummaryValue + postBuildSummaryValue]
  }).reduce((acc, [key, value]) => ({
    ...acc,
    [key]: value
  }), {})

  return (
    <Card>
      <CardHeader>Test Summary</CardHeader>
      <CardBody>
        <div className={classnames('test-summary')}>
          <BootstrapTable
            keyField='identifier' headerClasses='thead-dark'
            data={[...summaryData, {identifier: 'Total', ...totalSummary}]}
            bordered={false} columns={summaryColumns} />
        </div>
      </CardBody>
    </Card>
  )
}

SummaryTable.propTypes = {
  testSummary: PropTypes.shape({
  }).isRequired,
}

export default SummaryTable;
