# Code to Find Key if exists
def find_key(element, *keys):
    for key in keys:
        try:
            element = element[key]
        except KeyError:
            element = ""
            break
    return element
