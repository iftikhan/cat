import traceback
from datetime import datetime
from src.config import settings
from .exceptions import ArgumentTypeException
from .mailer import MailerAbstract, MailMessage, SesMailer


class Message(object):
    def __init__(self, description: str) -> None:
        self.__description = description
        self.__logged_at = datetime.now()

    @property
    def description(self) -> str:
        return self.__description

    @property
    def logged_at(self) -> datetime:
        return self.__logged_at


class WriterInterface:
    def write(self, message: Message):
        raise NotImplementedError()


class LoggerInterface:
    def log_info(self, description: str):
        raise NotImplementedError()

    def log_exception(self, ex: BaseException):
        raise NotImplementedError()


class PrintWriter(WriterInterface):
    def write(self, message: Message):
        if settings.IS_LOCAL:
            print('[{}] : {}'.format(message.logged_at, message.description))
        else:
            print(message.description)


class Logger(LoggerInterface):
    MIN_LENGTH_FOR_SECRET = 6

    __writer: WriterInterface = PrintWriter()
    __mailer: MailerAbstract = SesMailer()

    def log_info(self, description: str, secret: bool = False):
        if description and secret:
            if len(description) < self.MIN_LENGTH_FOR_SECRET:
                description = '*' * len(description)
            else:
                description = '{pref}{hidden}{suf}'.format(
                    pref=description[:3],
                    hidden='*' * (len(description) - 6),
                    suf=description[-3:]
                )
        self.__writer.write(Message(description))

    def log_exception(self, ex: BaseException, print_traceback: bool = True):
        if not isinstance(ex, BaseException):
            raise ArgumentTypeException(self.log_exception, 'ex', ex)

        # Attention!
        # This method is used everywhere. It is important to do this action
        # silently, because we may call it in places,
        # where we do not expect errors.
        try:
            if print_traceback:
                message = Message('{} - {}'.format(ex, traceback.format_exc()))
            else:
                message = Message(str(ex))
            mail_message = MailMessage(
                settings.ERROR_REPORTING_RECIPIENTS,
                f'EtherealRisk-Trasnform-{settings.ENV_NAME} Internal Server Error',
                message.description
            )
            if not settings.IS_LOCAL:
                self.__mailer.send(mail_message)
            self.__writer.write(message)
        except BaseException as logger_error:
            print(''.join([
                'ALARM! LOGGER DOES NOT WORK!\r\n',
                'ORIGINAL ERROR: {}\r\n'.format(ex),
                'LOGGER ERROR: {}\r\n'.format(logger_error),
                'TRACEBACK: {}\r\n'.format(traceback.format_exc()),
            ]))
