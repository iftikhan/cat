import React from "react";
import PropTypes from 'prop-types';

import BuildSpecs from "./BuildSpecs";
import PostBuildSpecs from "./PostBuildSpecs";

const ReportDetailsCEMF = ({
  details, onDownload,
  isDownloading, isLoading,
}) => {
  const {
    build_spec_windows: buildSpecWindows,
    build_spec_linux: buildSpecLinux,
    post_build_spec_windows: postBuildSpecWindows,
    post_build_spec_linux: postBuildSpecLinux,
  } = details;

  return (
    <>
      {buildSpecWindows &&
        <BuildSpecs buildSpecWindows={buildSpecWindows} buildSpecLinux={buildSpecLinux} />}      
      {postBuildSpecWindows &&
        <PostBuildSpecs
          postBuildSpecWindows={postBuildSpecWindows}
          postBuildSpecLinux={postBuildSpecLinux} />}
    </>
  )
}

ReportDetailsCEMF.propTypes = {
  details: PropTypes.shape({
    test_summary: PropTypes.shape({
      build_summary: PropTypes.shape({
        total_test_cases: PropTypes.number.isRequired,
        total_passed_cases: PropTypes.number.isRequired,
        total_failed_cases: PropTypes.number.isRequired,
      }).isRequired,
      post_build_summary: PropTypes.shape({
        total_test_cases: PropTypes.number.isRequired,
        total_passed_cases: PropTypes.number.isRequired,
        total_failed_cases: PropTypes.number.isRequired,
      }).isRequired,
    }).isRequired,
  }).isRequired,
  onDownload: PropTypes.func.isRequired,
  isDownloading: PropTypes.bool.isRequired,
  isLoading: PropTypes.bool.isRequired,
}

export default ReportDetailsCEMF;
