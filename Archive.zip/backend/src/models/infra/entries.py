from datetime import datetime
from typing import List, Optional

from src.utils.constants import InfraResourceStatus, InfraStatus, InfraResourceType
from src.models.infra.cloudformations import get_cf_class, CloudFormationBase


class LandingZoneEntry:
    id: int
    name: str
    description: str
    url: str
    created_at: datetime
    updated_at: datetime

    def __init__(
        self, name: str, description: str = None, url: str = None, id: int = None,
        created_at: datetime = None, updated_at: datetime = None
    ) -> None:
        self.id = id
        self.name = name
        self.description = description
        self.url = url
        self.created_at = created_at
        self.updated_at = updated_at

    def __str__(self) -> str:
        return f'{self.name}({self.id})'

    def __repr__(self) -> str:
        return f'<LZ({self.id}): {self.name}>'

    def to_dict(self) -> dict:
        response = {
            'name': self.name,
            'description': self.description,
            'url': self.url,
        }

        if self.id:
            response.update({
                'id': self.id,
                'created_at': self.created_at,
                'updated_at': self.updated_at,
            })

        return response


class InfraResourceEntry:
    account_id: int
    id: int
    stack_id: Optional[str]
    resource_type: InfraResourceType
    name: str
    status: InfraResourceStatus
    properties: CloudFormationBase
    description: str = None
    created_by: str
    created_at: datetime
    updated_at: datetime

    cloudformation_class: CloudFormationBase.__class__
    cloudformation: CloudFormationBase

    def __init__(
        self, account_id: int, resource_type: str, name: str, properties: dict, created_by: str,
        status: str = InfraResourceStatus.initiated.value,
        id: int = None, description: str = None,
        created_at: Optional[datetime] = None,
        updated_at: datetime = None, stack_id: Optional[str] = None,
    ) -> None:
        self.account_id = account_id
        self.id = id
        self.resource_type = InfraResourceType(resource_type)
        self.name = name
        self.status = InfraResourceStatus(status)
        self.description = description
        self.created_by = created_by
        self.properties = properties
        self.created_at = created_at
        self.updated_at = updated_at
        self.stack_id = stack_id

        self.cloudformation_class = get_cf_class(self.resource_type)
        self.cloudformation = self.cloudformation_class(self.name, description=self.description, **self.properties)

    def __repr__(self) -> str:
        return f'<Resource({self.resource_type}): {self.name}>'

    def __str__(self) -> str:
        return f'{self.name}({self.resource_type})'

    def to_dict(self) -> dict:
        result = {
            'account_id': self.account_id,
            'resource_type': self.resource_type.value,
            'name': self.name,
            'status': self.status.value,
            'properties': self.properties,
            'description': self.description,
            'created_by': self.created_by,
            'stack_id': self.stack_id,
        }

        if self.id:
            result.update({
                'id': self.id,
            })

        return result


class LandingZoneAccountEntry:
    landing_zone_id: int
    organization_unit: int
    id: int
    name: str
    account_id: str
    description: str
    cross_account_role_name: str
    created_by: str
    created_at: datetime
    updated_at: datetime
    status: InfraStatus
    __number_of_resources: int
    __number_of_rules: int

    resources: List[InfraResourceEntry]

    def __init__(
        self, landing_zone_id: int, organization_unit: str, name: str, account_id: str,
        cross_account_role_name: str, created_by: str,
        description: Optional[str] = None, id: Optional[int] = None,
        created_at: Optional[datetime] = None, updated_at: Optional[datetime] = None,
        status: InfraStatus = InfraStatus.pending.value, number_of_resources: int = None,
        number_of_rules: int = None, is_applied: bool = False,
    ) -> None:
        self.landing_zone_id = landing_zone_id
        self.organization_unit = organization_unit
        self.id = id
        self.name = name
        self.account_id = account_id
        self.description = description
        self.cross_account_role_name = cross_account_role_name
        self.created_by = created_by
        self.created_at = created_at
        self.updated_at = updated_at
        self.status = InfraStatus(status)

        self.resources = []
        self.__number_of_resources = int(number_of_resources or 0)
        self.__number_of_rules = int(number_of_rules or 0)
        self.is_applied = is_applied

    def __repr__(self) -> str:
        return f'<LandingZoneAccountEntry({self.id}): {self.name} at {self.account_id}>'

    def __str__(self) -> str:
        return f'{self.name}({self.account_id})'

    def add_resource(self, resource: InfraResourceEntry):
        self.resources.append(resource)

    def to_response(self) -> dict:
        initial = self.to_dict()
        initial.update({
            'is_applied': self.is_applied,
        })

        return initial

    @property
    def number_of_resources(self) -> int:
        if self.resources:
            return len(self.resources)
        else:
            return self.__number_of_resources

    @property
    def number_of_rules(self) -> int:
        return self.__number_of_rules

    def to_dict(self) -> dict:
        result = {
            'landing_zone_id': self.landing_zone_id,
            'organization_unit': self.organization_unit,
            'name': self.name,
            'account_id': self.account_id,
            'cross_account_role_name': self.cross_account_role_name,
            'description': self.description,
            'status': self.status.value,
            'created_by': self.created_by,
            'resources': [rs.to_dict() for rs in self.resources],
            'number_of_resources': self.number_of_resources,
            'number_of_rules': self.number_of_rules,
        }

        if self.id:
            result.update({
                'id': self.id,
                'created_at': self.created_at,
                'updated_at': self.updated_at,
            })

        return result
