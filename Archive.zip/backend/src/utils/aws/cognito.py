import boto3

from src.config import settings


class CognitoIdentity:
    def __init__(self) -> None:
        self.__client = boto3.client('cognito-idp')

    def retrieve_user(self, user_id: str):
        response = self.__client.admin_get_user(
            UserPoolId=settings.COGNITO_USER_POOL_ID,
            Username=user_id
        )
        return response

    def invite_user(self, email: str) -> str:
        response = self.__client.admin_create_user(
            UserPoolId=settings.COGNITO_USER_POOL_ID,
            Username=email,
            UserAttributes=[
                {
                    'Name': 'email',
                    'Value': email,
                },
            ],
            DesiredDeliveryMediums=['EMAIL'],
        )
        return response['User']['Username']

    def add_user_to_group(self, user_id: str, group: str):
        return self.__client.admin_add_user_to_group(
            UserPoolId=settings.COGNITO_USER_POOL_ID,
            Username=user_id,
            GroupName=group
        )

    def remove_user_from_group(self, user_id: str, group: str):
        return self.__client.admin_remove_user_from_group(
            UserPoolId=settings.COGNITO_USER_POOL_ID,
            Username=user_id,
            GroupName=group
        )

    def check_if_admin(self, user_id: str) -> bool:
        pass
