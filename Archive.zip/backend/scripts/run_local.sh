export AWS_PROFILE=nif-dev
export STAGE=dev
export TARGET_ACCOUNT_ID=561789658853
export DATASET_BUCKET=gxpvalidator-dataset-dev
export DB_SECRET_NAME=gpx-rds

sls offline --package serverless-package --stage dev \
    --useWorkerThreads \
    --targetAccountId $TARGET_ACCOUNT_ID --cfnRoleArn $CF_EXECUTION_ROLE \
    --dbSecretName $DB_SECRET_NAME --datasetBucket $DATASET_BUCKET \
    --httpPort 8000
