import React, { useState } from 'react';
import PropTypes from 'prop-types';

import {
  Modal, Button, Col, Input,
  Form,
} from 'reactstrap';

import TagsInput from "components/TagsInput/TagsInput.js";

import CloudProviderSelect from './CloudProviderSelect';
import CloudServicesSelect from './CloudServicesSelect';

import CloudComplianceStandarSelect from './CloudComplianceStandarSelect';

const ManagedRuleModal = ({
  rule, isOpen, toggle, onSubmit,
}) => {
  const {
    name: originalName = '',
    description: originalDescription,
    provider: originalProvider,
    services: originalServices = [],
    standards: originalStandards = [],
    tags: originalTags = []
  } = rule;

  const [name, setName] = useState(originalName);
  const [description, setDescription] = useState(originalDescription);
  const [provider, setProvider] = useState(originalProvider);
  const [services, setServices] = useState(originalServices);
  const [standards, setStandards] = useState(originalStandards);
  const [tags, setTags] = useState(originalTags);

  const onClickSave = () => {
    onSubmit(name, provider, services, standards, tags, description)
  }

  return (
    <Modal
      className="modal-dialog-centered"
      isOpen={isOpen}
      toggle={toggle}
    >
      <div className="modal-header">
        <h6 className="modal-title" id="modal-title-default">
          Create a new Config Rule
        </h6>
        <button
          aria-label="Close"
          className="close"
          data-dismiss="modal"
          type="button"
          onClick={toggle}
        >
          <span aria-hidden={true}>×</span>
        </button>
      </div>
      <div className="modal-body">
        <Form className="needs-validation" noValidate>
          <div className='form-row'>
            <Col className="mb-3" md="4">
              <label
                className="form-control-label"
                htmlFor="validationCustomUsername"
              >
                Cloud Provider
              </label>
              <CloudProviderSelect value={provider} onChange={setProvider} />
              {provider.length === 0 && <div className="invalid-feedback">
                Please choose a provider.
              </div>}
            </Col>
            <Col className="lg-3" md="8">
              <label
                className="form-control-label"
                htmlFor="new-rule-form-name"
              >
                Rule Name
              </label>
              <Input
                defaultValue={name}
                id="new-rule-form-name"
                placeholder="Rule Name"
                type="text"
                className='form-control-sm'
                valid={name.length > 0}
                invalid={name.length === 0}
                onChange={(e) => {
                  setName(e.target.value);
                }}
              />
              <div className="valid-feedback">Looks good!</div>
            </Col>
          </div>
          <div className="form-row">
            <Col className="mb-3">
              <label
                className="form-control-label"
                htmlFor="new-rule-form-description"
              >
                Description
              </label>
              <Input
                defaultValue={description}
                id="new-rule-form-description"
                placeholder="Description"
                type="textarea"
                className='form-control-sm'
                onChange={(e) => {
                  setDescription(e.target.value);
                }}
              />
              <div className="valid-feedback">Looks good!</div>
            </Col>
          </div>
          <div className="form-row">
            <Col className="mb-3">
              <label
                className="form-control-label"
                htmlFor="new-rule-form-standards"
              >
                Compliance Standards
              </label>
              <CloudComplianceStandarSelect
                value={standards}
                multiple
                id='new-rule-form-standards'
                onChange={setStandards}
              />
            </Col>
          </div>
          <div className="form-row">
            <Col className="mb-3">
              <label
                className="form-control-label"
                htmlFor="new-rule-form-services"
              >
                Services
              </label>
              <CloudServicesSelect
                value={services}
                multiple
                id='new-rule-form-services'
                provider={provider}
                onChange={setServices}
              />
            </Col>
          </div>
          <div className="form-row">
            <Col className="">
              <label
                className="form-control-label"
                htmlFor="new-rule-form-tags"
              >
                Tags
              </label>
            </Col>
          </div>
          <div className="form-row">
            <Col className="mb-3">
              <TagsInput
                onlyUnique
                id='new-rule-form-tags'
                className="bootstrap-tagsinput"
                onChange={(value) => setTags(value)}
                value={tags}
                tagProps={{ className: "tag badge badge-sm mr-1" }}
                inputProps={{
                  className: "form-control-sm",
                  placeholder: "Type here",
                }}
              />
            </Col>
          </div>
        </Form>
      </div>
      <div className="modal-footer">
        <Button color="primary" type="button" onClick={onClickSave}>
          Save changes
        </Button>
        <Button
          className="ml-auto"
          color="link"
          data-dismiss="modal"
          type="button"
          onClick={toggle}
        >
          Close
        </Button>
      </div>
    </Modal>
  )
};

ManagedRuleModal.propTypes = {
  rule: PropTypes.shape({
    name: PropTypes.string.isRequired,
    description: PropTypes.string,
    provider: PropTypes.string.isRequired,
    services: PropTypes.arrayOf(PropTypes.string).isRequired,
    standards: PropTypes.arrayOf(PropTypes.string).isRequired,
    tags: PropTypes.arrayOf(PropTypes.string).isRequired,
  }),
  isOpen: PropTypes.bool.isRequired,
  toggle: PropTypes.func.isRequired,
  onSubmit: PropTypes.func.isRequired,
};

ManagedRuleModal.defaultProps = {
  rule: {
    name: '',
    description: '',
    provider: 'aws',
    services: [],
    standards: [],
    tags: [],
  },
};

export default ManagedRuleModal;
