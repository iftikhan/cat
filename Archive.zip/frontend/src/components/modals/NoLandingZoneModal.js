import React from 'react';
import { useHistory } from 'react-router-dom';
import PropTypes from 'prop-types';

import {
  Modal, Button, Form,
} from 'reactstrap';

const NoLandingZoneModal = ({
  show,
}) => {
  const history = useHistory();
  return (
    <Modal show={show} onHide={() => {}}>
      <Modal.Header closeButton>
        <Modal.Title>Alert!</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form.Group>
          <Form.Text>No landing zone yet. Please create a new landing zone before getting started!</Form.Text>
        </Form.Group>
      </Modal.Body>
      <Modal.Footer>
        <Button color="primary" onClick={() => {history.push('/gxp-infra/admin/new')}}>
          Okay, create now
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

NoLandingZoneModal.propTypes = {
  show: PropTypes.bool.isRequired,
}

export default NoLandingZoneModal;
