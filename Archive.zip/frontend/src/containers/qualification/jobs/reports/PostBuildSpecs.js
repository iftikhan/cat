import React from "react";
import PropTypes from 'prop-types';

import PostBuildSpecBlock from "./PostBuildSpecBlock";

const PostBuildSpecs = ({
  postBuildSpecWindows,
  postBuildSpecLinux,
}) => {
  return (
    <>
      {postBuildSpecWindows.length > 0 && (
        <PostBuildSpecBlock title='Windows Post Migration Report' items={postBuildSpecWindows} />
      )}
      {postBuildSpecLinux.length > 0 && (
        <PostBuildSpecBlock title='Linux Post Migration Report' items={postBuildSpecLinux} />
      )}
    </>
  )
};

PostBuildSpecs.propTypes = {
  postBuildSpecWindows: PropTypes.arrayOf(PropTypes.shape({
    ResourceName: PropTypes.string.isRequired,
    ResourceOS: PropTypes.string.isRequired,
    ResourceType: PropTypes.string.isRequired,
    Spec: PropTypes.arrayOf(PropTypes.shape({
      ActualValue: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.bool
      ]),
      Drift: PropTypes.bool.isRequired,
      ExpectedValue: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.bool
      ]).isRequired,
      Parameter: PropTypes.string.isRequired,
      SectionDescription: PropTypes.string.isRequired,
    })).isRequired,
  })),
  postBuildSpecLinux: PropTypes.arrayOf(PropTypes.shape({
    ResourceName: PropTypes.string.isRequired,
    ResourceOS: PropTypes.string.isRequired,
    ResourceType: PropTypes.string.isRequired,
    Spec: PropTypes.arrayOf(PropTypes.shape({
      ActualValue: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.bool,
      ]),
      Drift: PropTypes.bool.isRequired,
      ExpectedValue: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.bool
      ]).isRequired,
      Parameter: PropTypes.string.isRequired,
      SectionDescription: PropTypes.string.isRequired,
    })).isRequired,
  })),
}
export default PostBuildSpecs;
