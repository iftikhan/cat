from datetime import datetime
from typing import Dict, List, Optional

from src.utils.pgsql import PgsqlManager, PG_DB_TABLE, Connection
from src.utils.aws.secret_manager import SecretManager


class AccountEntry:
    id: str
    account_name: str
    account_id: str
    credentials: Dict[str, str] = {}

    def __init__(
        self, account_name: str, account_id: str, id: str = None,
        aws_access_key_id: str = None, aws_secret_access_key: str = None,
        created_at: datetime = None, updated_at: datetime = None
    ) -> None:
        self.id = id
        self.account_id = account_id
        self.account_name = account_name
        self.created_at = created_at
        self.updated_at = updated_at

        if aws_access_key_id and aws_secret_access_key:
            self.credentials = {
                'aws_access_key_id': aws_access_key_id,
                'aws_secret_access_key': aws_secret_access_key,
            }

    @property
    def secret_name(self) -> str:
        if not self.id:
            raise ValueError('Instance was not created in DB yet.')

        return f'accounts/{self.id}'

    def to_dict(self) -> dict:
        response = {
            'account_name': self.account_name,
            'account_id': self.account_id,
        }
        if self.id:
            response['id'] = str(self.id)

        return response


class AccountModel:
    __connection: Connection = None

    def __init__(self, db_manager: Optional[PgsqlManager] = None) -> None:
        if isinstance(db_manager, PgsqlManager):
            self.__db_manager = db_manager
        else:
            self.__db_manager = PgsqlManager()

        self.__secret_manager = SecretManager()

    @property
    def connection(self) -> Connection:
        if not self.__connection:
            self.__connection = self.__db_manager.get_db_connection()

        return self.__connection

    def list_accounts(self, page: int = 1, size: int = 30) -> List[AccountEntry]:
        stmt = PG_DB_TABLE.accounts.select().offset(size * (page - 1)).limit(size)
        rows = self.connection.execute(stmt).fetchall()
        return [AccountEntry(**row) for row in rows]

    def create_account(
        self, account_name: str, account_id: str,
        aws_access_key_id: str, aws_secret_access_key: str
    ):
        entry = AccountEntry(
            account_name, account_id,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key
        )
        stmt = PG_DB_TABLE.accounts.insert().values(**entry.to_dict()).returning(
            PG_DB_TABLE.accounts.c.id
        )

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            row = self.connection.execute(stmt).fetchone()
            entry.id = row.id
            self.__secret_manager.create_secret(
                entry.secret_name, entry.credentials,
                description=f'Account credentials of AWS Account {entry.account_id}'
            )

        return __transaction()

    def update_account(
        self, id: str, account_name: str, account_id: str,
        aws_access_key_id: str, aws_secret_access_key: str
    ):
        entry = AccountEntry(
            account_name, account_id, id=id,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key
        )
        stmt = PG_DB_TABLE.accounts.update().values(
            account_name=entry.account_name,
            account_id=entry.account_id,
        ).where(
            PG_DB_TABLE.accounts.c.id == entry.id
        )

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)

            if entry.credentials:
                self.__secret_manager.update_secret_value(
                    entry.secret_name, entry.credentials,
                    description=f'Account credentials of AWS Account {entry.account_id}'
                )
            return response.rowcount > 0

        return __transaction()
