from .http import HttpRequest
from src.utils.aws import LambdaFunction


class Client:
    def __init__(self) -> None:
        self.http = HttpRequest()
        self.lambda_function = LambdaFunction
