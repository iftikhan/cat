import React, { useEffect, useState, useCallback } from 'react';
import { connect } from 'react-redux';
import {
  // useHistory,
  useParams
} from 'react-router';

import {
  Button, Card, CardHeader, CardBody,
  Row, Col, CardText, CardFooter,
} from 'reactstrap';

import API from 'helpers/api';
import LoadingModal from 'components/modals/Loading';
import { fetchLzAccountsRequest } from 'containers/infrastructure/actions';
import SearchTable from 'components/tables/SearchTable';
import ConfirmModal from 'components/modals/ConfirmModal';
import TagsInput from 'components/TagsInput/TagsInput';

const GxPControlRuleAccounts = ({
  infras, fetchingInfras, fetchLzAccountsRequest,
}) => {
  const { landingZoneId, ruleId } = useParams();
  const [accounts, setAccounts] = useState([]);
  const [ruleDetails, setRuleDetails] = useState(null);
  const [isChanged, setIsChanged] = useState(false);

  const [selectedAccounts, setSelectedAccounts] = useState([]);

  const [showConfirmModal, setShowConfirmModal] = useState(false);

  // const history = useHistory();

  const retrieveRuleAccounts = useCallback(() => {
    API.controls.getAccountsByRule(ruleId, landingZoneId)
    .then(({status, accounts}) => {
      if (status) {
        setAccounts(accounts)
      }
    }).catch(err => {
      console.error(err);
    })
  }, [setAccounts, ruleId, landingZoneId]);

  const onSelectAccount = useCallback((accountId: Number, selected: Boolean) => {
    if (selected) {
      setSelectedAccounts([
        ...selectedAccounts,
        accountId,
      ])
    } else {
      setSelectedAccounts(selectedAccounts.filter(item => item !== accountId))
    }

    setIsChanged(true);
  }, [
    selectedAccounts,
  ])

  const onSelectAllAccounts = useCallback((checked) => {
    if (checked) {
      setSelectedAccounts(accounts.map(({id}) => id));
    } else {
      setSelectedAccounts([]);
    }

    setIsChanged(true);
  }, [setSelectedAccounts, accounts])

  const onApply = () => {
    API.controls.updateAccountsByRule(ruleId, selectedAccounts)
    .then(({status}) => {
      if (status) {
        setSelectedAccounts([]);
        retrieveRuleAccounts();
        setShowConfirmModal(false);
      }
    }).catch(err => {
      console.error(err);
    })
  }

  const onTagChange = () => {}

  const accountColumns = [
    {
      dataField: 'select',
      text: '',
      headerFormatter: (col, colIndex, components) => {
        return (
          <div className="custom-control custom-checkbox">
            <input
              className="custom-control-input"
              id={`account-table-check-all`}
              onClick={(event) => {onSelectAllAccounts(event.target.checked)}}
              defaultChecked={accountColumns.length === selectedAccounts.length}
              type="checkbox"
            />
            <label
              className="custom-control-label"
              htmlFor={`account-table-check-all`}
            />
          </div>
        )
      },
    }, {
      dataField: 'organization_unit',
      text: 'Organization Unit',
      sort: true,
    }, {
      dataField: 'name',
      text: 'Account Name',
      sort: true,
    }, {
      dataField: 'account_id',
      text: 'Account ID',
    }
  ]

  const renderRuleDetails = () => {
    const {
      name,
      description,
      provider,
      tags,
    } = ruleDetails;

    return (
      <Card>
        <CardHeader>{name}</CardHeader>
        <CardBody>
          <Row>
            <Col>
              <CardText>{provider}</CardText>
            </Col>
          </Row>
          <Row>
            <Col>
              <TagsInput
                  onlyUnique
                  className="bootstrap-tagsinput readonly"
                  onChange={(value) => onTagChange(value)}
                  value={tags}
                  tagProps={{ className: "tag badge mr-1" }}
                  disabled={true}
                  inputProps={{
                    className: "",
                    placeholder: "",
                  }}
                />
            </Col>
          </Row>
          <Row>
            <Col>
              <CardText>{description}</CardText>
            </Col>
          </Row>
        </CardBody>
      </Card>
    )
  }

  useEffect(() => {
    retrieveRuleAccounts()
  }, [retrieveRuleAccounts]);

  useEffect(() => {
    API.controls.retrieveManagedRule(ruleId)
    .then(({status, rule}) => {
      setRuleDetails(rule);
    }).catch(err => {
      console.error(err);
    })
  }, [ruleId]);

  useEffect(() => {
    setSelectedAccounts(accounts.filter(({is_applied: isApplied}) => isApplied).map(({id}) => id));
  }, [accounts, setSelectedAccounts]);

  return (
    <>
      {!!ruleDetails && renderRuleDetails()}
      <Card className='mt-3'>
        <CardHeader>Accounts</CardHeader>
        <CardBody>
          <SearchTable
            columns={accountColumns} keyField='id'
            data={accounts.map((rule, idx) => ({
              ...rule,
              select: (
                <div className="custom-control custom-checkbox" key={idx}>
                  <input
                    className="custom-control-input"
                    id={`account-table-check-${rule.id}`}
                    onChange={(event) => {onSelectAccount(rule.id, event.target.checked)}}
                    checked={selectedAccounts.indexOf(rule.id) >= 0}
                    type="checkbox"
                  />
                  <label
                    className="custom-control-label"
                    htmlFor={`account-table-check-${rule.id}`}
                  />
              </div>)
            }))}
            entryNamePlural='rules'
            noDataIndication={'No managed rule'}
            />
        </CardBody>
        <CardFooter>
          <Button
            color="primary" className='float-right'
            disabled={!isChanged}
            onClick={() => {setShowConfirmModal(true)}}>
            Apply
          </Button>
        </CardFooter>
      </Card>
      <ConfirmModal
        title='Confirm!'
        description={`Are you sure to apply ${selectedAccounts.length} rules?`}
        onCancel={() => setShowConfirmModal(false)}
        show={showConfirmModal}
        onOkay={onApply}
        />
      <LoadingModal show={false} />
    </>
  )
}

const mapStateToProps = (state) => ({
});

const mapDispatchToProps = (dispatch) => ({
  fetchLzAccountsRequest: () => dispatch(fetchLzAccountsRequest()),
})

export default connect(mapStateToProps, mapDispatchToProps)(GxPControlRuleAccounts);
