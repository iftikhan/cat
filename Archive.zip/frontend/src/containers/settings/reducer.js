import createReducer from 'redux/helpers/createReducer';

import {
    namespace,
} from './actions';

const defaultState = {

}

const reducer = createReducer(namespace, defaultState, {
});

export default reducer;
export { namespace };
