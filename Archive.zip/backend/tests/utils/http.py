import re
import json
from tests.utils.response import ClientResponse
from tests.utils.exceptions import PathNotFoundException
from typing import Any, Callable, Dict, Tuple

from src.utils.modules import get_class_by_name


class HttpRequest:
    __path_mappings: Dict[str, Dict[str, str]] = {
        'get': {
            '/qua/options': 'handlers.get_parameters',
            '/qua/admin/projects': 'handlers.admin_manage_projects',
            '/qua/admin/projects/{id}': 'handlers.admin_manage_projects',
            '/qua/jobs': 'handlers.manage_jobs',
            '/qua/jobs/dashboard': 'handlers.manage_jobs',
            '/infra/lz': 'handlers.manage_infra',
            '/infra/lz/{landing_zone_id}/accounts': 'handlers.manage_infra',
            '/infra/lz/{landing_zone_id}/accounts/{account_id}': 'handlers.manage_infra',
            '/controls/managed_rules': 'handlers.manage_control_rules',
            '/controls/accounts/{account_id}/rules': 'handler_controls.manage_account_rules',
        },
        'post': {
            '/qua/admin/projects': 'handlers.admin_manage_projects',
            '/qua/jobs': 'handlers.manage_jobs',
            '/infra/lz': 'handlers.manage_infra',
            '/infra/lz/{landing_zone_id}/accounts/{account_id}/resources': 'handlers.manage_infra',
            '/controls/apply': 'handlers.apply_control_rules',
            '/controls/managed_rules': 'handlers.manage_control_rules',
        },
        'put': {
            '/infra/lz/{landing_zone_id}/accounts/{account_id}/resources/{resource_id}': 'handlers.manage_infra',
            '/controls/accounts/{account_id}/rules': 'handler_controls.manage_account_rules',
        },
        'delete': {
            '/infra/lz/{landing_zone_id}/accounts/{account_id}/resources/{resource_id}': 'handlers.manage_infra',
        }
    }

    def __get_handler(self, method: str, path: str) -> Tuple[Callable, Dict[str, Any], Dict[str, Any]]:
        mappings = self.__path_mappings.get(method, {})
        path, query_param_string, *_ = path.split('?') + ['']
        query_param_segs = [item for item in query_param_string.split('&') if item]
        query_params = dict(seg.split('=') for seg in query_param_segs)
        given_path_segs = [seg for seg in path.split('/') if seg]
        path_params = {}
        path_param_pattern = r'^\{([a-z\_]+)\}$'

        def __equals(given: str, pattern: str) -> bool:
            if given == pattern:
                return True

            if re.search(path_param_pattern, pattern):
                group, *_ = re.search(path_param_pattern, pattern).groups()
                path_params[group] = given
                return True
            else:
                return False

        for pattern_str, module in mappings.items():
            pattern_segs = [seg for seg in pattern_str.split('/') if seg]
            if len(given_path_segs) != len(pattern_segs):
                continue

            if all(__equals(given, pattern) for given, pattern in zip(given_path_segs, pattern_segs)):
                return get_class_by_name(module), path_params, query_params

        raise PathNotFoundException()

    def __send_request(self, method: str, path: str, headers: Dict[str, str] = {}, body: dict = {}):
        try:
            handler, path_params, query_params = self.__get_handler(method, path)
        except PathNotFoundException as e:
            return ClientResponse(404, msg=str(e))

        try:
            event = {
                'requestContext': {
                    'httpMethod': method.upper(),
                },
                'queryStringParameters': query_params,
                'pathParameters': path_params,
                'path': path,
            }

            if method != 'get':
                event['body'] = json.dumps(body)

            response = handler(event, {})
            return ClientResponse(
                response['statusCode'],
                json_body=json.loads(response['body'])
            )
        except ValueError as e:
            return ClientResponse(400, msg=str(e))
        # except Exception as e:
        #     return ClientResponse(500, msg=str(e))

    def get(self, path: str, headers: Dict[str, str] = {}) -> ClientResponse:
        return self.__send_request('get', path, headers)

    def post(self, path: str, headers: dict = {}, body: dict = {}) -> ClientResponse:
        return self.__send_request('post', path, headers=headers, body=body)

    def put(self, path: str, headers: dict = {}, body: dict = {}) -> ClientResponse:
        return self.__send_request('put', path, headers=headers, body=body)

    def delete(self, path: str, headers: dict = {}, body: dict = {}) -> ClientResponse:
        return self.__send_request('delete', path, headers=headers, body=body)
