import { call, put, takeEvery } from 'redux-saga/effects';

import API from 'helpers/api';
import {
  fetchLzAccountsRequest, fetchLzAccountsSuccess, fetchLzAccountsFailure,
  retrieveLzAccountRequest, retrieveLzAccountSuccess, retrieveLzAccountFailure,
} from './actions';

function* fetchLandingZoneAccounts() {
  try {
    const { infras } = yield call(API.fetchLandingZoneAccounts);
    yield put(fetchLzAccountsSuccess({ infras }));
  } catch (e) {
    yield put(fetchLzAccountsFailure());
  }
}

function* retrieveLandingZoneAccount({ payload }) {
  try {
    const { landingZoneId, accountId: accId } = payload;
    const { account: {
      id, name, account_id: accountId, resources,
      cross_account_role_name: roleName,
      organization_unit: organizationUnitName,
    } } = yield call(API.retrieveLandingZoneAccount, landingZoneId, accId);
    yield put(retrieveLzAccountSuccess({ accountDetails: {
      id, name, accountId, roleName, resources,
      organizationUnitName,
    } }));
  } catch (e) {
    yield put(retrieveLzAccountFailure());
  }
}

export const infraSagas = [
  takeEvery(fetchLzAccountsRequest.Type, fetchLandingZoneAccounts),
  takeEvery(retrieveLzAccountRequest.Type, retrieveLandingZoneAccount),
];
