from sqlalchemy.engine.base import Connection
from src.utils.constants import USER_ROLE
from typing import List, Optional
from datetime import datetime

from src.utils.pgsql import PgsqlManager, PG_DB_TABLE
from src.utils.aws.cognito import CognitoIdentity


class UserEntry:
    id: str
    email: str
    role: str
    created_at: Optional[datetime] = None

    def __init__(self, id: str, email: str, role: str, created_at: Optional[datetime] = None) -> None:
        self.id = id
        self.email = email
        self.role = role
        self.created_at = created_at

    @property
    def is_admin(self) -> bool:
        return self.role in [USER_ROLE.superadmin, USER_ROLE.admin]

    def to_dict(self) -> dict:
        result = {
            'id': str(self.id),
            'email': self.email,
            'role': self.role,
        }

        if self.created_at:
            result['created_at'] = self.created_at

        return result


class UserModel:
    __connection: Connection = None

    def __init__(self, db_manager: Optional[PgsqlManager] = None) -> None:
        if isinstance(db_manager, PgsqlManager):
            self.__db_manager = db_manager
        else:
            self.__db_manager = PgsqlManager()

        self.__cognitor_helper = CognitoIdentity()

    @property
    def connection(self) -> Connection:
        if not isinstance(self.__connection, Connection):
            self.__connection = self.__db_manager.get_db_connection()

        return self.__connection

    def create(self, user_id: str, email: str, role: str = USER_ROLE.admin):
        user = UserEntry(user_id, email, role=role)
        _user_table = PG_DB_TABLE.users
        stmt = _user_table.insert().values(**user.to_dict())

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)
            return response.rowcount > 0

        return __transaction()

    def invite_user(self, email: str, role: str = USER_ROLE.user):
        username = self.__cognitor_helper.invite_user(email)
        return self.create(username, email, role)

    def retrieve_user(self, user_id: str) -> Optional[UserEntry]:
        stmt = PG_DB_TABLE.users.select().where(
            PG_DB_TABLE.users.c.id == user_id
        )
        row = self.connection.execute(stmt).fetchone()
        return UserEntry(**row) if row else None

    def list_users(self, page: int = 1, size: int = 30) -> List[UserEntry]:
        stmt = PG_DB_TABLE.users.select().offset(size * (page - 1)).limit(size)
        rows = self.connection.execute(stmt).fetchall()
        return [UserEntry(**row) for row in rows]

    def update_user_role(self, user_id: str, role: str):
        stmt = PG_DB_TABLE.users.update().where(
            PG_DB_TABLE.users.c.id == user_id
        ).values(
            role=role
        )

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)
            return response.rowcount > 0

        return __transaction()
