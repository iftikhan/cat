import json
from src.utils.constants import USER_ROLE

from src.utils.auth import get_authenticated_user
from src.utils.response import build_response
from src.models.users import UserModel


def admin_manage_users(event, context):
    user_id = get_authenticated_user(event)
    user_model = UserModel()
    current_user = user_model.retrieve_user(user_id)

    if not current_user.is_admin:
        return build_response({
            'msg': 'access denied',
        }, 403)

    http_method = event['requestContext']['httpMethod']
    # query_params = event.get('queryStringParameters') or {}
    http_path = event['path']
    path_params = event.get('pathParameters', {})

    if http_path == '/admin/users':
        if http_method == 'GET':
            # created_by = query_params.get('created_by')
            users = user_model.list_users()
            return build_response({
                'users': [user.to_dict() for user in users],
            })
        elif http_method == 'POST':
            params = json.loads(event['body'] or '{}')
            required = ['email', 'role', ]
            for attr in required:
                if attr not in params or not params.get(attr):
                    return build_response({
                        attr: f'{attr} is required.'
                    }, 400)

            if params['role'] not in [USER_ROLE.user, USER_ROLE.admin, USER_ROLE.superadmin]:
                return build_response({
                    'role': f'Invalid role - {params["role"]}'
                }, 400)

            user_model.invite_user(
                params['email'], params['role']
            )

            return build_response({
                'status': True,
            })
    elif 'user_id' in path_params:
        user_id = path_params['user_id']
        if http_method == 'PUT':
            params = json.loads(event['body'] or '{}')
            if 'role' not in params or not params['role']:
                return build_response({
                    'role': 'role is required.'
                }, 400)

            if params['role'] not in [USER_ROLE.user, USER_ROLE.admin]:
                return build_response({
                    'role': 'Invalid role'
                })

            user_model.update_user_role(
                user_id, params['role']
            )
            return build_response({
                'status': True
            })
    return build_response({})
