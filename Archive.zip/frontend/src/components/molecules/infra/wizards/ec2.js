import React from 'react';
import PropTypes from 'prop-types';

const Ec2Wizard = () => {
  return (
    <>
      <h3>Ec2 Wizard</h3>
      <p>Comming soon..</p>
    </>
  )
};

Ec2Wizard.propTypes = {
  properties: PropTypes.shape({

  }).isRequired,
}

export default Ec2Wizard;
