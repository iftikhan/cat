import os
import boto3
import tempfile
from typing import Optional
from openpyxl import Workbook
from sqlalchemy.engine.base import Connection

from src.config import settings
from src.utils.pgsql import PgsqlManager
from src.models.jobs import JobEntry, JobsModel
from src.models.report_summaries import ReportSummaryModel
from src.models.report_details import ReportDetailsModel


class ExcelReport:
    __connection: Connection = None

    def __init__(self, db_manager: Optional[PgsqlManager] = None) -> None:
        if settings.IS_LOCAL:
            self.REPORTS_BASE_PATH = os.path.join(os.path.dirname(settings.BASE_DIR), 'tmp')
        else:
            self.REPORTS_BASE_PATH = tempfile.mkdtemp()

        if isinstance(db_manager, PgsqlManager):
            self.__db_manager = db_manager
        else:
            self.__db_manager = PgsqlManager()

        self.__job_model = JobsModel(self.__db_manager)
        self.__summary_model = ReportSummaryModel(self.__db_manager)
        self.__details_model = ReportDetailsModel(self.__db_manager)

    @property
    def connection(self) -> Connection:
        if not isinstance(self.__connection, Connection):
            self.__connection = self.__db_manager.get_db_connection()

        return self.__connection

    def create_report(self, job_id: str) -> str:
        job_instance = self.__job_model.get_job(job_id)

        workbook = Workbook()

        workbook.remove_sheet(workbook.worksheets[0])

        self.__write_validation_summary_sheet(workbook, job_instance)
        # self.__write_dataset_summary_sheet(workbook, job_instance)
        self.__write_issue_summary_sheet(workbook, job_instance)
        self.__write_details_sheet(workbook, job_instance)
        self.__write_rules_sheet(workbook, job_instance)

        report_path = os.path.join(self.REPORTS_BASE_PATH, f'{job_id}.xlsx')
        workbook.save(report_path)

        s3_client = boto3.client('s3')
        s3_report_url = f'public/reports/{job_id}/report.xlsx'
        s3_client.upload_file(
            report_path, settings.STORAGE_BUCKET, s3_report_url)

    def __write_validation_summary_sheet(self, wb: Workbook, job: JobEntry):
        sheet = wb.create_sheet('Validation Summary')
        cur_row_index = 1

        # Write title
        sheet.append([f'{job.dataset_name} Validator Report'])
        sheet.merge_cells(start_row=cur_row_index, end_row=cur_row_index, start_column=1, end_column=5)
        sheet.append([])
        cur_row_index += 2

        configurations = [
            ['Project', job.project_name],
            ['Study', job.study_name],
            ['Version', job.version_name],
            ['Dataset', job.dataset_name],
            ['Created By', job.user_id],
            ['Job Status', job.long_status_text],
        ]

        for row in configurations:
            sheet.append(row)
            sheet.merge_cells(start_row=cur_row_index, end_row=cur_row_index, start_column=2, end_column=5)
            cur_row_index += 1

        sheet.append([])
        sheet.append([])
        cur_row_index += 2

        insight = self.__summary_model.get_insight(job.id)
        # sheet.append([
        #     'Total Checks', 'Total Rejects', 'Total Errors', 'Total Warnings', 'Compliance Score',
        # ])
        sheet.append(tuple(insight.keys()))
        sheet.append(tuple(insight.values()))
        cur_row_index += 2

        # sheet.append([])
        # sheet.append([])
        # cur_row_index += 2

        # subtitle = (
        #     "Problems with your Validator installation detected\n"
        #     "which may cause inaccurate validation results"
        # )
        # sheet.append([subtitle])
        # sheet.merge_cells(start_row=cur_row_index, end_row=cur_row_index, start_column=1, end_column=5)
        # sheet.append([])
        # cur_row_index += 2

        # sheet.append(['Problem', 'Details', 'Link'])
        # cur_row_index += 1

        # problems = [
        #     [
        #         'SNOMED not configured',
        #         (
        #             'SNOMED is a licensed dictionary, therefore it is not included in '
        #             'Pinnacle 21 Community. Community users must configure SNOMED manually. '
        #             'Without SNOMED configured, validation rules that check Trial Indication '
        #             'and Diagnosis Group in Trial Summary will not be executed. '
        #             'Please follow the link on the right for instructions.'
        #         ),
        #         'How to configure SNOMED'
        #     ]
        # ]

        # for problem in problems:
        #     sheet.append(problem)
        #     cur_row_index += 1

    def __write_dataset_summary_sheet(self, wb: Workbook, job: JobEntry):
        headers = [
            'Domain', 'Label', 'Class', 'Source', 'Records', 'Rejects', 'Errors', 'Warnings', 'Notices'
        ]
        sheet = wb.create_sheet('Dataset Summary')
        cur_row_index = 1

        # Write title
        sheet.append([f'{job.dataset_name} Validator Report'])
        sheet.merge_cells(start_row=cur_row_index, end_row=cur_row_index, start_column=1, end_column=len(headers))
        sheet.append([])
        cur_row_index += 2

        sheet.append(['Processed Sources'])
        sheet.merge_cells(start_row=cur_row_index, end_row=cur_row_index, start_column=1, end_column=len(headers))
        cur_row_index += 1

        sheet.append(headers)
        cur_row_index += 1

        rows = [
            ['GLOBAL', 'Global Metadata', '--', '--', '0', '1', '0', '0', '0'],
            ['AE', 'Adverse Events', 'EVENTS', 'ae.xpt', '59', '0', '0', '94', '0'],
            ['CE', 'Clinical Events', 'EVENTS', 'ce.xpt', '0', '0', '0', '32', '0'],
            ['CM', 'Concomitant Medications', 'INTERVENTIONS', 'cm.xpt', '154', '0', '0', '65', '0'],
            ['CO', 'Comments', 'SPECIAL PURPOSE', 'co.xpt', '53', '0', '0', '58', '0'],
        ]
        for row in rows:
            sheet.append(row)
            cur_row_index += 1

    def __write_issue_summary_sheet(self, wb: Workbook, job: JobEntry):
        headers = [
            'Source', 'Pinnacle 21 ID', 'Publisher ID', 'Message', 'Severity', 'Found', "Phastar's comment"
        ]
        sheet = wb.create_sheet('Issue Summary')
        cur_row_index = 1

        # Write title
        sheet.append([f'{job.dataset_name} Validator Report'])
        sheet.merge_cells(start_row=cur_row_index, end_row=cur_row_index, start_column=1, end_column=len(headers))
        sheet.append([])
        cur_row_index += 2

        sheet.append(['Issue Summary'])
        sheet.merge_cells(start_row=cur_row_index, end_row=cur_row_index, start_column=1, end_column=len(headers))
        cur_row_index += 1

        summaries = self.__summary_model.get_comparison(job.id)
        for summary in summaries:
            sheet.append([
                'SOURCE',
                summary.rule_id, summary.publisher_id,
                summary.message, summary.severity,
                summary.found, summary.comment
            ])
            cur_row_index += 1

    def __write_details_sheet(self, wb: Workbook, job: JobEntry):
        sheet = wb.create_sheet('Details')
        headers = [
            'Domain', 'Record', 'Count', 'Variables', 'Values',
            'Rule ID', 'Publisher ID', 'Message', 'Category', 'Severity'
        ]
        sheet.append(headers)
        rows = self.__details_model.get_by_job(job.id)
        for row in rows:
            sheet.append([
                row.domain, row.record_number, '',
                ', '.join(row.variable_names),
                ', '.join([str(item) for item in row.variable_values]),
                row.rule_id, row.publisher_id, row.message, row.category, row.severity
            ])

    def __write_rules_sheet(self, wb: Workbook, job: JobEntry):
        sheet = wb.create_sheet('Rules')
        sheet.append([
            'Rule ID', 'Publisher ID', 'Message', 'Description', 'Category', 'Severity'
        ])
        rules = self.__rule_model.list_rules_by_dataset(job.dataset_id)

        for rule in rules:
            sheet.append([
                rule.rule_id, rule.publisher_id, rule.message, rule.description, rule.category, rule.severity
            ])
