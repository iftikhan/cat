import React, { useEffect, useState, useCallback } from 'react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router';

import { Row, Col, Form, Button } from 'reactstrap';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from "react-bootstrap-table2-paginator";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";

import { FaPlusCircle } from 'react-icons/fa';
import Select2 from "react-select2-wrapper";

import API from 'helpers/api';
import LoadingModal from 'components/modals/Loading';
import { fetchLzAccountsRequest } from './actions';

const GxPInfraDashboard = ({
  infras, fetchingInfras, fetchLzAccountsRequest,
}) => {
  const [landingZones, setLandingZones] = useState([]);
  const [curLandingZoneId, setCurLandingZoneId] = useState(null);
  const [accounts, setAccounts] = useState([]);

  const history = useHistory();
  const { SearchBar } = Search;

  const pagination = paginationFactory({
    page: 1,
    alwaysShowAllBtns: true,
    showTotal: true,
    withFirstAndLast: false,
    sizePerPageRenderer: ({ options, currSizePerPage, onSizePerPageChange }) => (
      <div className="dataTables_length" id="datatable-basic_length">
        <label>
          Show{" "}
          {
            <select
              name="datatable-basic_length"
              aria-controls="datatable-basic"
              className="form-control form-control-sm"
              onChange={e => onSizePerPageChange(e.target.value)}
            >
              <option value="10">10</option>
              <option value="25">25</option>
              <option value="50">50</option>
              <option value="100">100</option>
            </select>
          }{" "}
          accounts.
        </label>
      </div>
    )
  });

  const getLandingZones = useCallback(() => {
    API.infrastructure.getLandingZones().then(({landing_zones: items}) => {
      setLandingZones(items);
      if (items.length === 0) {
        history.push('/gxp-infra/admin');
      } else {
        const [{id: landingZoneId}] = items;
        setCurLandingZoneId(landingZoneId);
      }
    }).catch(err => {
      console.error(err);
      alert('Failed to fetch landing zones')
    }).finally(() => {
      console.log('Done: Fetching landing zones')
    })
  }, [setLandingZones, setCurLandingZoneId, history])

  useEffect(() => {
    getLandingZones()
  }, [getLandingZones])

  const fetchLandingZoneAccounts = useCallback(() => {
    API.fetchLandingZoneAccounts(curLandingZoneId).then((response: {
      accounts: Array<Object>
    }) => {
      setAccounts(response.accounts);
    }).catch(() => {
      alert('something went wrong!');
    })
  }, [setAccounts, curLandingZoneId])

  useEffect(() => {
    if (curLandingZoneId) {
      fetchLandingZoneAccounts()
    }
  }, [
    curLandingZoneId, fetchLandingZoneAccounts,
  ]);

  const columns = [
    {
      dataField: 'organization_unit',
      text: 'Organization Unit',
      sort: true,
    }, {
      dataField: 'name',
      text: 'Account Name',
      sort: true,
    }, {
      dataField: 'account_id',
      text: 'Account Number',
      align: 'right',
      headerStyle: {width: '120px'},
      sort: true,
    }, {
      dataField: 'number_of_resources',
      text: 'Number of Resources',
      align: 'right',
      headerStyle: {width: '180px',},
      sort: true,
    }, {
      dataField: '',
      text: '',
      headerStyle: {width: '56px'},
      formatter: (value, row) => {
        const {id: accountId} = row;
        return (
          <Button
            className={'btn-sm'}
            onClick={() => history.push(`/gxp-infra/create/${curLandingZoneId}/accounts/${accountId}/resources`)}>
            <FaPlusCircle />
          </Button>
        )
      }
    },
  ];

  return (
    <>
      <Row>
        <Col size='auto'></Col>
        <Col sm={4} md={3}>
          <h3 className='mt-2'>
          Select Landing Zone
          </h3>
        </Col>
        <Col>
          <Form>
            <Select2
              className="form-control"
              defaultValue={curLandingZoneId}
              onChange={e => setCurLandingZoneId(e.target.value)}
              options={{
                placeholder: "Select",
              }}
              data={landingZones.map(({id, name}) => ({id, text: name}))}
            />
          </Form>
        </Col>
      </Row>
      <ToolkitProvider
        data={accounts}
        keyField='id'
        columns={columns}
        search
      >
        {props => (
          <div className="py-4">
            <Row>
              <div
                id="datatable-basic_filter"
                className="dataTables_filter px-4 pb-1"
              >
                <label>
                  Search:
                  <SearchBar
                    className="form-control-sm"
                    placeholder=""
                    {...props.searchProps}
                  />
                </label>
              </div>
            </Row>
            <BootstrapTable
              classes='align-items-center'
              {...props.baseProps}
              bootstrap4={true}
              pagination={pagination}
              bordered={false}
              headerClasses='thead-dark'
            />
          </div>
        )}
      </ToolkitProvider>
      <LoadingModal show={false} />
    </>
  )
}

const mapStateToProps = (state) => ({
});

const mapDispatchToProps = (dispatch) => ({
  fetchLzAccountsRequest: () => dispatch(fetchLzAccountsRequest()),
})

export default connect(mapStateToProps, mapDispatchToProps)(GxPInfraDashboard);
