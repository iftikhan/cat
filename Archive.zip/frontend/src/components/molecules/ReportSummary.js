import React, { useEffect, useState } from 'react';
import { useParams, useHistory } from 'react-router-dom';
import PropTypes from 'prop-types';
import classnames from "classnames";
import {
  Button, Row, Col, Dropdown,
} from 'reactstrap';
import { FaCheckCircle } from 'react-icons/fa';
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';
import cellEditFactory from 'react-bootstrap-table2-editor';

import API from 'helpers/api';

import SubTitle from 'components/common/SubTitle';
import ValidationConfiguration from './reports/ValidationConfiguration'

const ReportSummary = ({
  loadSummary, job, summaries, isLoading,
  onDownload,
}) => {
  const history = useHistory();
  const params = useParams();
  const { jobId } = params;

  const [isDownloading, setIsDownloading] = useState(false);

  const { project, study, version, dataset, status, ended_at: endedAt, created_by: author } = job || {};

  const productsWithButton = summaries.map(item => ({
    ...item,
    action: <><Button className={'btn-sm'}><FaCheckCircle /></Button></>
  }))

  useEffect(() => {
    loadSummary(jobId);
  }, [jobId, loadSummary])

  const columns = [{
    dataField: 'rule_id',
    text: 'Rule ID',
    filter: textFilter(),
    headerStyle: {width: '80px'},
    editable: false,
  }, {
    dataField: 'publisher_id',
    text: 'Publisher ID',
    filter: textFilter(),
    headerStyle: {width: '120px'},
    editable: false,
  }, {
    dataField: 'message',
    text: 'Message',
    filter: textFilter(),
    editable: false,
  }, {
    dataField: 'severity',
    text: 'Severity',
    filter: textFilter(),
    headerStyle: {width: '120px'},
    editable: false,
  }, {
    dataField: 'found',
    text: 'Found',
    filter: textFilter(),
    headerStyle: {width: '80px'},
    editable: false,
  }, {
    dataField: 'comment',
    text: 'Comment',
    filter: textFilter(),
    headerStyle: {width: '240px'},
    editable: (cell, row, rowIndex, colIndex) => {
      return true; //row.found > 0
    },
  },
  // {
  //   dataField: 'action',
  //   text: '',
  //   headerStyle: {width: '60px'},
  //   style: {textAlign: 'center'},
  //   formatter: (cel, row, rowIndex) => {
  //     if (row.found > 0) {
  //       return <Button className={'btn-sm'}><FaCheckCircle /></Button>
  //     } else {
  //       return <></>
  //     }
  //   },
  // }
  ];

  const afterSaveCell = (oldValue, newValue, row, column) => {
    if (column.dataField === 'comment') {
      API.saveComment(row.job_id, row.id, newValue).then(() => {}).catch(err => console.error(err));
    }
  }

  const summaryColumns = [
    {
      dataField: 'total',
      text: 'Total Checks'
    }, {
      dataField: 'reject',
      text: 'Total Rejects'
    }, {
      dataField: 'error',
      text: 'Total Errors'
    }, {
      dataField: 'warning',
      text: 'Total Warnings'
    }, {
      dataField: 'score',
      text: 'Compliance Score'
    },
  ]

  const onClickDownload = () => {
    setIsDownloading(true)
    onDownload(jobId).then(() => setIsDownloading(false)).catch(err => {
      setIsDownloading(false);
      alert('Failed to create report.')
    });
  }

  const rowClasses = (row, rowIndex) => {
    return `${row.found > 0 ? `${row.severity}-failed` : 'passed'}`;
  };

  const summaryRows = [{
    total: summaries.reduce((a, b) => a + 1, 0),
    reject: summaries.filter(item => item.severity === 'Reject' && parseInt(item.found) > 0).reduce((a, b) => a + 1, 0),
    error: summaries.filter(item => item.severity === 'Error' && parseInt(item.found) > 0).reduce((a, b) => a + 1, 0),
    warning: summaries.filter(item => item.severity === 'Warning' && parseInt(item.found) > 0).reduce((a, b) => a + 1, 0),
    score: `${(
      summaries.filter(item => parseInt(item.found) === 0 || ['Reject', 'Error'].indexOf(item.severity) < 0).reduce((a, b) => a + 1, 0) /
      summaries.reduce((a, b) => a + 1, 0)
    ) * 100} %`,
  }]

  return (
    <>
      <br />
      <Row>
        <Col>
          <Button
            disabled={isDownloading}
            onClick={onClickDownload}
          >{isDownloading ? 'Downloading...' : 'Download Report'}</Button>
          <Dropdown>
            <Dropdown.Toggle color="success" id="dropdown-basic">
              Dropdown Button
            </Dropdown.Toggle>

            <Dropdown.Menu>
              <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
              <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
              <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </Col>
        <Col style={{textAlign: 'right'}}>
          <Button onClick={() => history.push(`/gxp-qualification/jobs/${jobId}/details`)}>
            View Detailed Report
          </Button>
        </Col>
      </Row>

      <SubTitle title={`Summary Report for JOB ID: ${jobId}`} />

      {job && (
      <>
        <ValidationConfiguration
          title='Validation Configuration'
          data={{project, study, version, dataset, status, endedAt, author}}
          />

        <hr />
        <br />
        <h6>Validation Summary</h6>
        <br />
        <div className={classnames('gxp-qualification-summary')}>
          <BootstrapTable
            keyField='total' data={summaryRows}
            bordered={false} columns={summaryColumns} />
        </div>
      </>)
      }

      {!isLoading && (
      <>
        <hr />
        <br />
        <h6>Validation Summary Details</h6>
        <br />
        <div className={classnames('report-summary-table')}>
          <BootstrapTable
            keyField='rule_id' data={ productsWithButton } columns={ columns }
            filter={filterFactory()} rowClasses={rowClasses}
            noDataIndication={isLoading ? 'Loading Summary...' : 'No summary yet.'}
            cellEdit={ cellEditFactory({ mode: 'click', afterSaveCell }) }
            />
        </div>
      </>)}
    </>
  );
}

ReportSummary.propTypes = {
  isLoading: PropTypes.bool.isRequired,
  loadSummary: PropTypes.func.isRequired,
  job: PropTypes.shape({

  }),
  summaries: PropTypes.arrayOf(PropTypes.shape({

  })),
  onDownload: PropTypes.func.isRequired,
}

export default ReportSummary;
