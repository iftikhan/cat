class LandingZoneEntry:
    account_number: str
    region: str
    app_id: str
    resource_type: str
    resource_id: str
    expected_variable: str
    expected_value: str
    role_name: str

    def __init__(
        self, account_number: str, region: str, app_id: str, resource_type: str,
        resource_id: str, expected_variable: str, expected_value: str,
        role_name: str
    ) -> None:
        self.account_number = account_number
        self.region = region.lower()
        self.app_id = app_id
        self.resource_type = resource_type.lower()
        self.resource_id = str(resource_id)
        self.expected_variable = expected_variable
        self.expected_value = expected_value
        self.role_name = role_name
