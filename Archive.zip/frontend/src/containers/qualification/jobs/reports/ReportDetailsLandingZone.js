import React from "react";
import PropTypes from 'prop-types';

import BuildBlock from "./BuildSpecBlock";
import PostBuildSpecBlock from "./PostBuildSpecBlock";

const ReportDetailsLandingZone = ({
  details, onDownload,
  isDownloading, isLoading,
}) => {
  const {
    build_spec: buildSpec,
    post_build_spec: postBuildSpec,
  } = details;

  return (
    <>
      {buildSpec && 
        <>
          <BuildBlock
            title={'Installation Test Results for Landing Zone Resources'} items={buildSpec} />
          <br />
          <hr />
        </>}
      {postBuildSpec &&
        <PostBuildSpecBlock
          title={'Operation Test Results for Landing Zone Resources'} items={postBuildSpec} />}
    </>
  )
}

ReportDetailsLandingZone.propTypes = {
  details: PropTypes.shape({
    test_summary: PropTypes.shape({
      build_summary: PropTypes.shape({
        total_test_cases: PropTypes.number.isRequired,
        total_passed_cases: PropTypes.number.isRequired,
        total_failed_cases: PropTypes.number.isRequired,
      }).isRequired,
      post_build_summary: PropTypes.shape({
        total_test_cases: PropTypes.number.isRequired,
        total_passed_cases: PropTypes.number.isRequired,
        total_failed_cases: PropTypes.number.isRequired,
      }).isRequired,
    }).isRequired,
  }).isRequired,
  onDownload: PropTypes.func.isRequired,
  isDownloading: PropTypes.bool.isRequired,
  isLoading: PropTypes.bool.isRequired,
}

export default ReportDetailsLandingZone;
