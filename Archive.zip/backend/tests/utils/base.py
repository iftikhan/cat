from unittest import TestCase

from .client import Client


class ServerlessTestCase(TestCase):
    client = Client()
