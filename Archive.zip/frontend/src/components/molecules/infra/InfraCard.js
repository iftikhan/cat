import React, { useState } from 'react';
import PropTypes from 'prop-types';

import { Card, Col } from 'reactstrap';

import InfraModal from './InfraModal';

const InfraCard = ({
  id, name, accountId, roleName, description, onUpdate,
}) => {
  const [showEditModal, setShowEditModal] = useState(false);

  return (
    <>
      <Col xl={4} md={6} sm={6}>
        <Card>
          <Card.Header>{name}</Card.Header>
          <Card.Body>
            <Card.Subtitle className="mb-2 text-muted">{accountId}</Card.Subtitle>
            <Card.Text title={description}>
              {roleName}
            </Card.Text>
          </Card.Body>
          <Card.Footer>
            <Card.Link onClick={() => setShowEditModal(true)}>Edit Infra</Card.Link>
            <Card.Link href={`/gxp-infra/create/${id}/resources`}>Manage Resources</Card.Link>
          </Card.Footer>
        </Card>
      </Col>
      <InfraModal
        show={showEditModal} handleClose={() => setShowEditModal(false)}
        handleSubmit={onUpdate}
        defaultData={{id, name, accountId, roleName, description}}
        />
    </>
  )
}

InfraCard.propTypes = {
  id: PropTypes.number.isRequired,
  accountId: PropTypes.string.isRequired,
  roleName: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  description: PropTypes.string,
  onUpdate: PropTypes.func.isRequired,
}

InfraCard.defaultProps = {
  description: '',
}

export default InfraCard;
