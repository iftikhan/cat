import React from 'react';
import PropTypes from 'prop-types';

import { Input } from 'reactstrap';

import { CloudingProviders } from 'utils/constants';

const CloudProviderSelect = ({
  onChange, value, multiple, id, className, renderEmpty,
}) => {
  return (
    <Input
      className={className}
      type='select' value={value}
      onChange={(event) => onChange(event.target.value)}
    >
      {renderEmpty && <option value={''}>All Providers</option>}
      {CloudingProviders.map((item, idx) => (
        <option key={idx} value={item}>{item.toUpperCase()}</option>
      ))}
    </Input>
  )
}

CloudProviderSelect.propTypes = {
  value: PropTypes.string,
  onChange: PropTypes.func.isRequired,
  className: PropTypes.string,
  renderEmpty: PropTypes.bool,
};

CloudProviderSelect.defaultProps = {
  value: '',
  className: 'form-control-sm',
  renderEmpty: true,
}

export default CloudProviderSelect;
