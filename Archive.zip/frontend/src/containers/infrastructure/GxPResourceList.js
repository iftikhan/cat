import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { connect } from 'react-redux';

import {
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  UncontrolledDropdown,
} from 'reactstrap';
import Heartbeat from 'react-heartbeat';

import API from 'helpers/api';

import LoadingModal from 'components/modals/Loading';
import { infraResourceTypes } from 'utils/constants';
import { retrieveLzAccountRequest } from './actions';

import AccountInfo from 'components/molecules/infra/AccountInfo';
import Wizard from 'components/molecules/infra/wizards/index';
import ResourceList from 'components/molecules/resources/ResourceList';

const GxPResourceList = ({
  accountDetails, retrieveLzAccountRequest, retrievingInfraDetails,
}) => {
  const { landingZoneId, accountId } = useParams();
  const [ resourceType, setResourceType ] = useState(infraResourceTypes[0].value);
  const [ showResourceWizard, setShowResourceWizard ] = useState(false);
  const [ loading, setLoading ] = useState(false);
  const [ runningResources, setRunningResources ] = useState([]);

  const onNewResourceType = (resourceType: String) => {
    setResourceType(resourceType);
    setShowResourceWizard(true);
  }

  const onCreateNewResource = (resourceName: String, parameters: Object) => {
    setLoading(true);
    API.createInfrastructure(landingZoneId, accountId, resourceName, resourceType, parameters).then(res => {
      retrieveLzAccountRequest(landingZoneId, accountId)
      setShowResourceWizard(false);
    }).catch(err => {
      console.error(err);
      alert('Failed to create resource.')
    }).finally(() => {
      setLoading(false);
    })
  }

  const onDeleteResource = (resource) => {
    const {id: resourceId} = resource;
    setLoading(true);
    return API.deleteInfrastructure(landingZoneId, accountId, resourceId).then(({status}) => {
      retrieveLzAccountRequest(landingZoneId, accountId)
    }).catch(err => {
      console.error(err);
      alert('Failed to delete resource');
    }).finally(() => {
      setLoading(false);
    })
  }

  const checkStatus = () => {
    API.checkInfrastructureStatus(landingZoneId, accountId, runningResources.map(item => item.id)).then(({resource_status: runningResources}) => {
      const newRunningResources = runningResources.filter(
        ({status}) => ['provisioning', 'deleting', 'initiated'].indexOf(status) === -1
      )

      if (newRunningResources.length > 0) {
        retrieveLzAccountRequest(landingZoneId, accountId)
      }
    }).catch(err => {
      console.error(err)
    })
  }

  useEffect(() => {
    retrieveLzAccountRequest(landingZoneId, accountId)
  }, [landingZoneId, accountId, retrieveLzAccountRequest]);

  useEffect(() => {
    if (!!accountDetails) {
      const { resources } = accountDetails;
      const newRunningResources = resources.filter(
        ({ status }) => ['provisioning', 'deleting', 'initiated'].indexOf(status) > -1
      )
      setRunningResources(newRunningResources)
    }
  }, [
    accountDetails, setRunningResources,
  ])

  return (
    <>
      {accountDetails && (
        <AccountInfo {...accountDetails} />
      )}
      <hr />
      <div className='mb-3'>
        <UncontrolledDropdown>
          <DropdownToggle caret color="secondary">
            Add new Resource
          </DropdownToggle>
          <DropdownMenu>
            {infraResourceTypes.map(({name, value}, idx) => (
              <DropdownItem key={idx} onClick={() => onNewResourceType(value)}>
                {name}
              </DropdownItem>
            ))}
          </DropdownMenu>
        </UncontrolledDropdown>
      </div>
      {showResourceWizard && (
        <Wizard type={resourceType} onSubmit={onCreateNewResource} onClose={() => setShowResourceWizard(false)} />
      )}
      {accountDetails && accountDetails.resources && (
        <ResourceList
          landingZoneId={landingZoneId} accountId={accountId}
          resources={accountDetails.resources}
          onDeleteResource={onDeleteResource} />
      )}
      {runningResources.length > 0 && <Heartbeat heartbeatFunction={checkStatus} heartbeatInterval={3000} />}
      <LoadingModal show={loading} />
    </>
  )
}

const mapStateToProps = state => ({
  retrievingInfraDetails: state.infra.retrievingInfraDetails,
  accountDetails: state.infra.accountDetails,
});

const mapDispatchToProps = dispatch => ({
  retrieveLzAccountRequest: (landingZoneId: Number, accountId: Number) => dispatch(retrieveLzAccountRequest({landingZoneId, accountId})),
})

export default connect(mapStateToProps, mapDispatchToProps)(GxPResourceList);
