import time
from datetime import datetime
import sqlalchemy as sa
from sqlalchemy.engine import Engine, Connection, create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.exc import OperationalError

from src.config import settings
from src.utils.constants import JOB_STATUS, PROJECT_STATUS, RUN_METHOD, USER_ROLE, CloudProvider,\
    InfraResourceStatus, InfraStatus
from .logger import Logger


class Connector(object):
    def __init__(self, engine: Engine, debug: bool = False) -> None:
        self.__debug = debug
        self.__engine = engine
        self.__root_connection_lazy = None
        self.__session_lazy = None
        self.__log_if_debug('Constructed!')

    def __del__(self):
        self.__log_if_debug('Destruction...')

        if self.__session_lazy:
            self.__log_if_debug('Session : Closing...')
            self.__session_lazy.close()
            self.__log_if_debug('Session : Closed!')

        if self.__root_connection_lazy:
            self.__log_if_debug('Root Connection : Closing...')
            self.__root_connection_lazy.close()
            self.__log_if_debug('Root Connection : Closed!')

        # Close all real db-connections.
        # https://docs.sqlalchemy.org/en/13/core/connections.html#engine-disposal
        self.__log_if_debug('Engine : Disposing...')
        self.__engine.dispose()
        self.__log_if_debug('Engine : Disposed!')

        self.__log_if_debug('Destructed!')

    def __log_if_debug(self, message: str) -> None:
        if self.__debug:
            print('[{}] : {} ({}) : {}'.format(
                datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                self.__class__.__qualname__,
                self.__engine.url,
                message
            ))

    @property
    def connection(self) -> Connection:
        if self.__root_connection_lazy is None:
            self.__log_if_debug('Root Connection : Creating...')
            self.__root_connection_lazy = self.__engine.connect()
            self.__log_if_debug('Root Connection : Created!')

        # "Returns a branched version of this .Connection.
        # The Connection.close() method on the returned Connection can be called
        # and this Connection will remain open."
        branched_connection = self.__root_connection_lazy.connect()

        # So we always have only one real db connection.
        return branched_connection

    @property
    def session(self) -> Session:
        if self.__session_lazy is None:
            self.__log_if_debug('Session : Creating...')
            session_class = sessionmaker(bind=self.__engine)
            self.__session_lazy = session_class(bind=self.connection)
            self.__log_if_debug('Session : Created!')

        return self.__session_lazy


class PgsqlManager(object):
    """docstring here
    """
    def __init__(self, debug: bool = settings.DEBUG):
        self.__logger = Logger()

        self.__debug = debug
        self.__db_connection_string = self.__build_connection_string(
            settings.DATABASE_USERNAME,
            settings.DATABASE_PASSWORD,
            settings.DATABASE_HOST,
            settings.DATABASE_DBNAME
        )

        self.__db_connector_lazy = None
        self.__log_if_debug('Constructed!')

    def __build_connection_string(self, user: str, password: str, host: str, db: str) -> str:
        return f'{user}:{password}@{host}/{db}'

    def __del__(self):
        self.__log_if_debug('Destruction...')
        del self.__db_connector_lazy
        self.__log_if_debug('Destructed!')

    def __log(self, message: str) -> None:
        self.__logger.log_info('[{}] : {} : {}'.format(
            datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f'),
            self.__class__.__qualname__,
            message
        ))

    def __log_if_debug(self, message: str) -> None:
        if self.__debug:
            self.__log(message)

    def __create_engine(self, connection_string) -> Engine:
        self.__log_if_debug('Engine {} : Creating...'.format(connection_string))
        engine = create_engine(
            f'postgresql://{connection_string}', echo=self.__debug)
        self.__log_if_debug('Engine {} : Created!'.format(connection_string))
        return engine

    def __transaction_scope(self, connection: Connection, fn):
        def wrapper():
            def __transaction():
                self.__log('Transaction Opening...')
                transaction = connection.begin()
                self.__log('Transaction Opened!')

                try:
                    result = fn()
                except Exception:
                    self.__log('Transaction Rollback...')
                    transaction.rollback()
                    self.__log('Transaction Rollback!')
                    raise
                else:
                    self.__log('Transaction Commit...')
                    transaction.commit()
                    self.__log('Transaction Commit!')
                    return result
                finally:
                    self.__log('Transaction Closing...')
                    transaction.close()
                    self.__log('Transaction Closed!')

            attempt_number = 0
            deadlock_attempt_number = 0

            self.__log('Transaction Scope - Start!')
            while True:
                attempt_number += 1

                self.__log('Transaction Attempt #{} - Start...'.format(attempt_number))
                try:
                    result = __transaction()
                except OperationalError as transaction_error:
                    self.__log(
                        'Transaction Attempt #{} - ERROR - {}'.format(
                            attempt_number, transaction_error))

                    if attempt_number > 5:
                        raise transaction_error

                    if 'deadlock' in str(transaction_error).lower():
                        deadlock_attempt_number += 1
                        delay = deadlock_attempt_number * 0.1
                        self.__log(
                            'Transaction Attempt #{} - Retry after {} seconds...'.format(
                                attempt_number, delay))
                        time.sleep(delay)
                        continue

                    #  (1205, 'Lock wait timeout exceeded; try restarting transaction')
                    if 'Lock wait timeout exceeded; try restarting transaction' in\
                            str(transaction_error).lower():
                        self.__log(
                            'Transaction Attempt #{} - Retry immediately...'.format(
                                attempt_number))
                        continue

                    raise transaction_error

                self.__log('Transaction Attempt #{} - Success!'.format(attempt_number))

                self.__log('Transaction Scope - End!')
                return result

        return wrapper

    def __get_db_connector(self) -> Connector:
        if self.__db_connector_lazy is None:
            self.__log_if_debug('Common DB Connector : Creating...')
            engine = self.__create_engine(self.__db_connection_string)
            self.__db_connector_lazy = Connector(engine, self.__debug)
            self.__log_if_debug('Common DB Connector : Created!')

        return self.__db_connector_lazy

    def get_db_connection(self) -> Connection:
        return self.__get_db_connector().connection

    def db_transaction_scope(self, fn):
        """
        @db_manager.db_transaction_scope
        def transaction():
            return result

        result = transaction()
        """
        connection = self.get_db_connection()
        return self.__transaction_scope(connection, fn)

    def get_transaction_scope(self, connection: Connection):
        """
        @db_manager.get_transaction_scope(connection)
        def transaction():
            return result

        result = transaction()
        """

        def wrapper(fn):
            return self.__transaction_scope(connection, fn)

        return wrapper


class TABLE_NAME:
    SYS_DB_MIGRATION = 'sys_db_migration'
    QUALIFICATIN_TYPES_TABLE = 'qualification_types'
    SETTINGS_META_TABLE = 'settings'
    PARAMETERS_META_TABLE = 'parameters'
    PROJECTS_TABLE = 'projects'
    PROJECT_SETTINGS_TABLE = 'project_settings'
    PROJECT_PARAMETERS_TABLE = 'project_parameters'
    USERS_TABLE = 'users'
    JOBS_TABLE = 'jobs'
    REPORTS_TABLE = 'reports'
    LANDING_ZONE_TABLE = 'landing_zones'
    LZ_ACCOUNT_TABLE = 'landing_zone_accounts'
    LZ_INFRASTRUCTURE_TABLE = 'landing_zone_infrastructures'
    MANAGED_CONFIG_RULES = 'managed_config_rules'
    ACCOUNT_CONFIG_RULES = 'account_config_rules'


_metadata = sa.MetaData()

"""
CREATE TABLE sys_db_migration (
    "name" varchar(255) NULL,
    applied_at timestamp(0) NULL,
    CONSTRAINT sys_db_migration_un UNIQUE ("name")
);
"""
table_sys_db_migration = sa.Table(
    TABLE_NAME.SYS_DB_MIGRATION,
    _metadata,
    sa.Column('name', sa.String(255), nullable=False, primary_key=True),
    sa.Column('applied_at', sa.DateTime(), nullable=False),
)

_table_qualification_types = sa.Table(
    TABLE_NAME.QUALIFICATIN_TYPES_TABLE,
    _metadata,
    sa.Column('id', sa.INTEGER, primary_key=True),
    sa.Column('name', sa.String(36), nullable=False, unique=True),
    sa.Column('description', sa.String(128)),
    sa.Column('details', sa.JSON, nullable=False, default={}),
    sa.UniqueConstraint('name',),
)

_table_settings_meta = sa.Table(
    TABLE_NAME.SETTINGS_META_TABLE,
    _metadata,
    sa.Column('id', sa.INTEGER, primary_key=True),
    sa.Column('name', sa.String(36), nullable=False, unique=True),
    sa.Column('description', sa.String(128)),
    sa.UniqueConstraint('name'),
)

_table_parameters_meta = sa.Table(
    TABLE_NAME.PARAMETERS_META_TABLE,
    _metadata,
    sa.Column('id', sa.INTEGER, primary_key=True),
    sa.Column('resource_type', sa.String(36), nullable=False),
    sa.Column('expected_variable', sa.String(128), nullable=False),
    sa.Column('expected_value', sa.String(36), nullable=True),
    sa.Column('include', sa.BOOLEAN, nullable=False, default=True),
    sa.Column('section', sa.String(36), nullable=False, default='Build'),
    sa.Column('section_description', sa.String(128), nullable=False),
    sa.UniqueConstraint('resource_type', 'expected_variable'),
)

_table_users = sa.Table(
    TABLE_NAME.USERS_TABLE,
    _metadata,
    sa.Column('id', sa.String(36), primary_key=True),
    sa.Column('email', sa.String(80), unique=True),
    sa.Column('role', sa.Enum(
        USER_ROLE.superadmin, USER_ROLE.admin, USER_ROLE.user
    ), default=USER_ROLE.user),
    sa.Column('created_at', sa.DATETIME, nullable=False)
)

_table_projects = sa.Table(
    TABLE_NAME.PROJECTS_TABLE,
    _metadata,
    sa.Column('id', sa.INTEGER, primary_key=True),
    sa.Column('qualification_type_id', sa.ForeignKey('qualification_types.id')),
    sa.Column('landing_zone_id', sa.ForeignKey('landing_zones.id')),
    sa.Column('created_by', sa.ForeignKey('users.id')),
    sa.Column('name', sa.String(36), nullable=False),
    sa.Column('description', sa.String(128)),
    sa.Column('status', sa.Enum(PROJECT_STATUS.default), nullable=False, default=PROJECT_STATUS.default),
    sa.Column('created_at', sa.DATETIME, nullable=False),
    sa.Column('updated_at', sa.DATETIME, nullable=False)
)

_table_project_parameters = sa.Table(
    TABLE_NAME.PROJECT_PARAMETERS_TABLE,
    _metadata,
    sa.Column('id', sa.Integer, primary_key=True),
    sa.Column('parameter_id', sa.ForeignKey('parameters.id')),
    sa.Column('project_id', sa.ForeignKey('projects.id')),
    sa.Column('expected_variable', sa.String(128), nullable=True),
    sa.Column('expected_value', sa.String(36), nullable=True),
    sa.Column('include', sa.BOOLEAN, nullable=False, default=True),
    sa.Column('section', sa.String(36), nullable=False, default='Build'),
    sa.Column('section_description', sa.String(128), nullable=False),
    sa.UniqueConstraint('parameter_id', 'project_id'),
)

_table_project_settings = sa.Table(
    TABLE_NAME.PROJECT_SETTINGS_TABLE,
    _metadata,
    sa.Column('id', sa.String(36), primary_key=True),
    sa.Column('project_id', sa.ForeignKey('projects.id')),
    sa.Column('setting_id', sa.ForeignKey('settings.id')),
    sa.Column('value', sa.String(128), nullable=False),
    sa.Column('updated_at', sa.DATETIME, nullable=False),
)

_table_jobs = sa.Table(
    TABLE_NAME.JOBS_TABLE,
    _metadata,
    sa.Column('id', sa.Integer, primary_key=True),
    sa.Column('project_id', sa.ForeignKey('projects.id')),
    sa.Column('created_by', sa.ForeignKey('users.id')),
    sa.Column('run_method', sa.Enum(
        RUN_METHOD.api, RUN_METHOD.excel
    ), default=RUN_METHOD.excel),
    sa.Column('s3_input_url', sa.String(256), nullable=False),
    sa.Column('details', sa.JSON, nullable=False, default={}),
    sa.Column('status', sa.Enum(
        JOB_STATUS.running, JOB_STATUS.success, JOB_STATUS.failure, JOB_STATUS.error
    ), default=JOB_STATUS.running),
    sa.Column('started_at', sa.DATETIME, nullable=False),
    sa.Column('ended_at', sa.DATETIME),
)

_table_reports = sa.Table(
    TABLE_NAME.REPORTS_TABLE,
    _metadata,
    sa.Column('id', sa.Integer, primary_key=True),
    sa.Column('job_id', sa.ForeignKey('jobs.id')),
    sa.Column('status', sa.Enum(
        JOB_STATUS.running, JOB_STATUS.success, JOB_STATUS.failure, JOB_STATUS.error
    ), default=JOB_STATUS.running),
    sa.Column('found', sa.Integer, nullable=False, default=0),
    sa.Column('comment', sa.String(256), nullable=True),
    sa.Column('started_at', sa.DATETIME, nullable=False),
    sa.Column('ended_at', sa.DATETIME),
)

_table_lz_accounts = sa.Table(
    TABLE_NAME.LZ_ACCOUNT_TABLE,
    _metadata,
    sa.Column('landing_zone_id', sa.ForeignKey('landing_zones.id')),
    sa.Column('organization_unit', sa.String(36), nullable=False),
    sa.Column('id', sa.Integer, primary_key=True),
    sa.Column('created_by', sa.ForeignKey('users.id')),
    sa.Column('name', sa.String(36), nullable=False),
    sa.Column('account_id', sa.CHAR(12), nullable=False,),
    sa.Column('cross_account_role_name', sa.String(128), nullable=False),
    sa.Column('description', sa.String(128)),
    sa.Column('status', sa.Enum(InfraStatus.pending.value, ), default=InfraStatus.pending.value),
    sa.Column('created_at', sa.DATETIME, nullable=False),
    sa.Column('updated_at', sa.DATETIME, nullable=False)
)

_table_lz_infrastructures = sa.Table(
    TABLE_NAME.LZ_INFRASTRUCTURE_TABLE,
    _metadata,
    sa.Column('id', sa.Integer, primary_key=True),
    sa.Column('account_id', sa.ForeignKey(f'{TABLE_NAME.LZ_ACCOUNT_TABLE}.id')),
    sa.Column('stack_id', sa.String(256), nullable=True),
    sa.Column('resource_type', sa.String(36), nullable=False),
    sa.Column('name', sa.String(36), nullable=False),
    sa.Column('description', sa.String(128)),
    sa.Column('properties', sa.JSON, nullable=False),
    sa.Column('status', sa.Enum(
        InfraResourceStatus.initiated.value, InfraResourceStatus.provisioning.value,
        InfraResourceStatus.success.value, InfraResourceStatus.failed.value,
        InfraResourceStatus.deleting.value,
    ), default=InfraResourceStatus.initiated.value),
    sa.Column('created_by', sa.ForeignKey('users.id')),
    sa.Column('created_at', sa.DATETIME, nullable=False),
    sa.Column('updated_at', sa.DATETIME, nullable=False)
)

_table_landing_zones = sa.Table(
    TABLE_NAME.LANDING_ZONE_TABLE,
    _metadata,
    sa.Column('id', sa.Integer, primary_key=True),
    sa.Column('name', sa.String(36), nullable=False),
    sa.Column('description', sa.String(128)),
    sa.Column('url', sa.String(256), nullable=True),
    sa.Column('created_at', sa.DATETIME, nullable=False),
    sa.Column('updated_at', sa.DATETIME, nullable=False)
)

_table_managed_config_rules = sa.Table(
    TABLE_NAME.MANAGED_CONFIG_RULES,
    _metadata,
    sa.Column('id', sa.INTEGER, primary_key=True),
    sa.Column('provider', sa.Enum(
        CloudProvider.aws.value, CloudProvider.azure.value, CloudProvider.gcp.value
    ), default=CloudProvider.aws.value),
    sa.Column('name', sa.String(36)),
    sa.Column('description', sa.TEXT),
    sa.Column('services', sa.ARRAY(sa.TEXT), default=[]),
    sa.Column('standards', sa.ARRAY(sa.TEXT), default=[]),
    sa.Column('tags', sa.ARRAY(sa.TEXT), default=[])
)

_table_account_config_rules = sa.Table(
    TABLE_NAME.ACCOUNT_CONFIG_RULES,
    _metadata,
    sa.Column('id', sa.INTEGER, primary_key=True),
    sa.Column('landing_zone_account_id', sa.ForeignKey(f'{TABLE_NAME.LZ_ACCOUNT_TABLE}.id')),
    sa.Column('managed_config_rule_id', sa.ForeignKey(f'{TABLE_NAME.MANAGED_CONFIG_RULES}.id')),
    sa.Column('arn', sa.String(256), nullable=True),
    sa.Column('applied_by', sa.ForeignKey(f'{TABLE_NAME.USERS_TABLE}.id')),
    sa.Column('created_at', sa.DATETIME, nullable=False),
    sa.Column('updated_at', sa.DATETIME, nullable=False),
    sa.UniqueConstraint('landing_zone_account_id', 'managed_config_rule_id'),
)


class PG_DB_TABLE:
    qualification_types = _table_qualification_types
    parameters_meta = _table_parameters_meta
    settings_meta = _table_settings_meta
    users = _table_users
    projects = _table_projects
    project_parameters = _table_project_parameters
    project_settings = _table_project_settings
    jobs = _table_jobs
    reports = _table_reports
    lz_accounts = _table_lz_accounts
    lz_infrastructures = _table_lz_infrastructures
    landing_zones = _table_landing_zones
    managed_config_rules = _table_managed_config_rules
    account_config_rules = _table_account_config_rules
