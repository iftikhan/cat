import re

from src.config import settings
from src.utils.constants import CloudformationType


PREDEFINED_ACLs = [
    'LogDeliveryWrite', 'Private', 'PublicRead', 'PublicReadWrite', 'AuthenticatedRead',
    'AwsExecRead', 'BucketOwnerRead', 'BucketOwnerFullControl',
]


class CloudFormationBase:
    DEFAULT_VERSION = "2010-09-09"

    resource_type: CloudformationType

    name: str
    description: str
    properties: dict

    def __init__(self, name: str, description: str = None) -> None:
        if not self.resource_type:
            raise NotImplementedError('resource_type is required.')

        self.name = re.sub(r'[\s\t]', '-', name)
        self.description = description or ''

    def to_cloudformation(self) -> dict:
        return {
            "AWSTemplateFormatVersion": self.DEFAULT_VERSION,
            "Description": self.description,
            "Resources": {
                ''.join(self.name.split('-')): {
                    "Type": self.resource_type.value,
                    "Properties": self.convert_properties_to_cf_resources(),
                }
            },
            "Parameters": {},
            "Metadata": {},
            "Conditions": {}
        }

    def convert_properties_to_cf_resources(self):
        raise NotImplementedError(f'to_cloudformation is not implemented for {self.resource_type}')


class S3CloudFormation(CloudFormationBase):
    resource_type = CloudformationType.s3

    def __init__(
        self, name: str,
        bucket_name: str,
        access_logging: str = None,
        access_logging_file_prefix: str = None,
        access_logging_target_bucket: str = None,
        block_public_acls: str = None,
        block_public_policies: str = None,
        ignore_public_acls: str = None,
        kms_master_key_id: str = None,
        object_versioning: str = None,
        predefined_acl: str = None,
        restrict_public_bukcet_policies: str = None,
        server_side_encryption: str = None,
        description: str = None,
    ) -> None:
        super().__init__(name, description=description)
        self.access_logging = access_logging
        self.access_logging_file_prefix = access_logging_file_prefix
        self.access_logging_target_bucket = access_logging_target_bucket
        self.block_public_acls = block_public_acls
        self.block_public_policies = block_public_policies
        self.bucket_name = bucket_name
        self.ignore_public_acls = ignore_public_acls
        self.kms_master_key_id = kms_master_key_id
        self.object_versioning = object_versioning
        self.predefined_acl = predefined_acl if predefined_acl in PREDEFINED_ACLs else None
        self.restrict_public_bukcet_policies = restrict_public_bukcet_policies
        self.server_side_encryption = server_side_encryption

    def convert_properties_to_cf_resources(self):
        cf_result = {
            "BucketName": self.bucket_name,
            "BucketEncryption": {
                "ServerSideEncryptionConfiguration": [
                    {
                        "ServerSideEncryptionByDefault": {
                            "SSEAlgorithm": self.server_side_encryption,
                        }
                    }
                ]
            },
            "PublicAccessBlockConfiguration": {
                "BlockPublicAcls": self.block_public_acls,
                "BlockPublicPolicy": self.block_public_policies,
                "IgnorePublicAcls": self.ignore_public_acls,
                "RestrictPublicBuckets": self.restrict_public_bukcet_policies
            },
            "Tags": [
                {"Key": "Stack", "Value": settings.PROJECT_NAME},
            ]
        }

        if self.object_versioning:
            cf_result["VersioningConfiguration"] = {
                "Status": "Enabled"
            }

        if self.server_side_encryption == 'aws:kms':
            cf_result["BucketEncryption"]["ServerSideEncryptionConfiguration"][0][
                "ServerSideEncryptionByDefault"]["KMSMasterKeyID"] = self.kms_master_key_id

        if self.access_logging:
            cf_result["LoggingConfiguration"] = {
                "DestinationBucketName": self.access_logging_target_bucket,
                "LogFilePrefix": self.access_logging_file_prefix
            }

        if self.predefined_acl:
            cf_result["AccessControl"] = self.predefined_acl

        return cf_result
