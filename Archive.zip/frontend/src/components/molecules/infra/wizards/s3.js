import React, { useState } from 'react';
import PropTypes from 'prop-types';

import {
  FormGroup, Input, Col, Row, Button,
} from 'reactstrap';

import { InfraOptions } from 'utils/constants';

const { s3: { serverSideEncriptionOptions, predefinedACLs }} = InfraOptions;

const S3Wizard = ({
  name, properties, onSubmit, onClose, disabled,
}) => {
  const [resourceName, setResourceName] = useState(name);
  const [config, setConfig] = useState(properties);

  const onChange = (attr: String, value: any) => {
    setConfig({
      ...config,
      [attr]: value,
    })
  }

  const isValid = () => {
    const {
      bucket_name,
    } = config;
    return (
      bucket_name.length > 0
    )
  }

  return (
    <Col>
      <h3>S3 Bucket Wizard</h3>
      <hr />
      <FormGroup>
        <Input
          type="text" placeholder="Resource Name"
          onChange={(event) => {setResourceName(event.target.value)}}
          value={resourceName} disabled={disabled}
          />
      </FormGroup>
      <hr />
      <FormGroup>
        <Input
          type="text" placeholder="Bucket Name"
          onChange={(event) => {onChange('bucket_name', event.target.value)}}
          value={config.bucket_name}
          />
      </FormGroup>
      <FormGroup>
        <div className="custom-control custom-control-alternative custom-checkbox">
          <input
            className="custom-control-input"
            id="new-s3-resource-obj-versioning"
            type="checkbox"
            checked={config.object_versioning}
            onChange={(event) => onChange('object_versioning', event.target.checked)}
          />
          <label
            className="custom-control-label"
            htmlFor="new-s3-resource-obj-versioning"
          >
            <span className="text-muted">Object Versioning</span>
          </label>
        </div>
      </FormGroup>
      <Row>
        <Col>
          <FormGroup>
            <Input
              type="select" value={config.server_side_encryption}
              onChange={(event) => onChange('server_side_encryption', event.target.value)}
            >
              {serverSideEncriptionOptions.map(({name, value}, idx) => (
                <option key={idx} value={value}>{name}</option>
              ))}
            </Input>
          </FormGroup>
        </Col>
        {config.server_side_encryption === serverSideEncriptionOptions[1].value && (
          <Col>
            <FormGroup>
              <Input
                type="text" placeholder="KMS Mastar Key ID"
                onChange={(event) => {onChange('kms_master_key_id', event.target.value)}}
                value={config.kms_master_key_id}
                />
            </FormGroup>
          </Col>
        )}
      </Row>
      
      <FormGroup>
        <div className="custom-control custom-control-alternative custom-checkbox">
          <input
            className="custom-control-input"
            id="new-s3-resource-access-logging"
            type="checkbox"
            checked={config.access_logging}
            onChange={(event) => onChange('access_logging', event.target.checked)}
          />
          <label
            className="custom-control-label"
            htmlFor="new-s3-resource-access-logging"
          >
            <span className="text-muted">Access Logging</span>
          </label>
        </div>
      </FormGroup>
      {config.access_logging && (
        <Row>
          <Col>
            <FormGroup>
              <Input
                type="text" placeholder="Access Logging Target Bucket"
                onChange={(event) => {onChange('access_logging_target_bucket', event.target.value)}}
                value={config.access_logging_target_bucket}
                />
            </FormGroup>
          </Col>
          <Col>
            <FormGroup>
              <Input
                type="text" placeholder="Access Logging File Prefix"
                onChange={(event) => {onChange('access_logging_file_prefix', event.target.value)}}
                value={config.access_logging_file_prefix}
                />
            </FormGroup>
          </Col>
        </Row>
      )}
      <Row>
        <Col md={6}>
          <FormGroup>
            <div className="custom-control custom-control-alternative custom-checkbox">
              <input
                className="custom-control-input"
                id="new-s3-resource-block-public-acls"
                type="checkbox"
                checked={config.block_public_acls}
                onChange={(event) => onChange('block_public_acls', event.target.checked)}
              />
              <label
                className="custom-control-label"
                htmlFor="new-s3-resource-block-public-acls"
              >
                <span className="text-muted">Block Public ACLs</span>
              </label>
            </div>
          </FormGroup>
        </Col>
        <Col md={6}>
          <FormGroup>
            <div className="custom-control custom-control-alternative custom-checkbox">
              <input
                className="custom-control-input"
                id="new-s3-resource-block-public-policies"
                type="checkbox"
                checked={config.block_public_policies}
                onChange={(event) => onChange('block_public_policies', event.target.checked)}
              />
              <label
                className="custom-control-label"
                htmlFor="new-s3-resource-block-public-policies"
              >
                <span className="text-muted">Block Public Policies</span>
              </label>
            </div>
          </FormGroup>
        </Col>
        <Col md={6}>
          <FormGroup>
            <div className="custom-control custom-control-alternative custom-checkbox">
              <input
                className="custom-control-input"
                id="new-s3-resource-ignore-public-acls"
                type="checkbox"
                checked={config.ignore_public_acls}
                onChange={(event) => onChange('ignore_public_acls', event.target.checked)}
              />
              <label
                className="custom-control-label"
                htmlFor="new-s3-resource-ignore-public-acls"
              >
                <span className="text-muted">Ignore Public ACLs</span>
              </label>
            </div>
          </FormGroup>
        </Col>
        <Col md={6}>
          <FormGroup>
            <div className="custom-control custom-control-alternative custom-checkbox">
              <input
                className="custom-control-input"
                id="new-s3-resource-restrict-public-bucket-policies"
                type="checkbox"
                checked={config.restrict_public_bukcet_policies}
                onChange={(event) => onChange('restrict_public_bukcet_policies', event.target.checked)}
              />
              <label
                className="custom-control-label"
                htmlFor="new-s3-resource-restrict-public-bucket-policies"
              >
                <span className="text-muted">Restric Public Bucket Policies</span>
              </label>
            </div>
          </FormGroup>
        </Col>
      </Row>
      <hr />
      <Row>
        <Col><Button color='secondary' onClick={() => onClose()}>Cancel</Button></Col>
        <Col>
          <Button
            disabled={!isValid()} color='primary' className={'float-right'}
            onClick={() => onSubmit(resourceName, config)}
          >Save Changes</Button>
        </Col>
      </Row>

      <hr />
    </Col>
  )
};

S3Wizard.propTypes = {
  name: PropTypes.string,
  stackId: PropTypes.string,
  properties: PropTypes.shape({
    bucket_name: PropTypes.string,
    object_versioning: PropTypes.bool,
    server_side_encryption: PropTypes.string,
    kms_master_key_id: PropTypes.string,
    access_logging: PropTypes.bool,
    access_logging_target_bucket: PropTypes.string,
    access_logging_file_prefix: PropTypes.string,
    block_public_acls: PropTypes.bool,
    block_public_policies: PropTypes.bool,
    ignore_public_acls: PropTypes.bool,
    restrict_public_bukcet_policies: PropTypes.bool,
    predefined_acl: PropTypes.string,
  }),
  onSubmit: PropTypes.func.isRequired,
  onClose: PropTypes.func,
  disabled: PropTypes.bool,
}

S3Wizard.defaultProps = {
  name: '',
  stackId: '',
  disabled: false,
  properties: {
    bucket_name: '',
    object_versioning: false,
    server_side_encryption: serverSideEncriptionOptions[0].value,
    kms_master_key_id: 'aws/s3',
    access_logging: false,
    access_logging_target_bucket: '',
    access_logging_file_prefix: '',
    block_public_acls: false,
    block_public_policies: false,
    ignore_public_acls: false,
    restrict_public_bukcet_policies: false,
    predefined_acl: predefinedACLs[0],
  },
  onClose: () => {},
}

export default S3Wizard;
