import React from 'react';
import PropTypes from 'prop-types';

import {
  Card, CardHeader, CardBody,
} from 'reactstrap';

const ApplicationInfo = ({
  items,
}) => {
  return (
    <Card>
      <CardHeader>Application Information</CardHeader>
      <CardBody className='react-bootstrap-table'>
        <table className='table'>
          <thead className='thead-dark'>
            <tr>
              <th>S.N</th>
              <th>Application Name</th>
              <th>Server Name</th>
              <th>Server OS</th>
              <th>Server FQDN</th>
            </tr>
          </thead>
          <tbody>
            {items.map(({
              application_name: appName,
              server_name: serverName,
              server_os: serverOS,
              server_fqdn: serverFQDN,
            }, idx) => (
              <tr key={idx}>
                <td>{idx + 1}</td>
                <td>{appName}</td>
                <td>{serverName}</td>
                <td>{serverOS}</td>
                <td>{serverFQDN}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </CardBody>      
    </Card>
  )
}

ApplicationInfo.propTypes = {
  items: PropTypes.arrayOf(PropTypes.shape({
    application_name: PropTypes.string.isRequired,
    server_environment: PropTypes.string.isRequired,
    server_fqdn: PropTypes.string.isRequired,
    server_name: PropTypes.string.isRequired,
    server_os: PropTypes.string.isRequired
  })).isRequired,
}

export default ApplicationInfo;
