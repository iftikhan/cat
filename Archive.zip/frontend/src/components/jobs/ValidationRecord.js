import React from 'react';
import PropTypes from 'prop-types';

import { Row, Col } from 'reactstrap';
import { BiCheck, BiX } from 'react-icons/bi';

const ValidationRecord = ({
  success, caption,
}) => {
  return (
    <Row>
      <Col xs={10}>{caption}</Col>
      <Col xs={2}>
        {success
        ? <BiCheck color={'green'} size={24} />
        : <BiX color={'red'} size={24} />}
      </Col>
    </Row>
  )
};

ValidationRecord.propTypes = {
  success: PropTypes.bool.isRequired,
  caption: PropTypes.string.isRequired,
}

export default ValidationRecord;
