import json
import boto3

from src.config import settings
from src.utils.modules import get_class_by_name


class LambdaFunction:
    FUNC_NAME_MAPPING = {
        'quaValidateFile': 'validate',
        'quaInitJob': 'init_job',
        # 'createReport': 'generate_report',
        'tool': 'execute_tool',
    }

    @staticmethod
    def get_lambda_client():
        return boto3.client('lambda')

    @classmethod
    def invoke_lambda(cls, name: str, event: dict = {}, invocation_type: str = 'Event'):
        if settings.IS_LOCAL:
            function_name = cls.FUNC_NAME_MAPPING[name.split('-')[-1]]
            func_module = get_class_by_name(f'handlers.{function_name}')
            return func_module(event, None)
        else:
            client = cls.get_lambda_client()
            return client.invoke(
                FunctionName=name,
                InvocationType=invocation_type,
                LogType='Tail',
                Payload=json.dumps(event)
            )
