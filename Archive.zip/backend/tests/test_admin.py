import random

from .utils.base import ServerlessTestCase


class AdminTabTest(ServerlessTestCase):
    def test_options(self):
        result = self.client.http.get('/qua/options')
        self.assertEqual(result.status_code, 200)

        response = result.json_body
        self.assertIsNotNone(response.get('parameters'))
        self.assertIsNotNone(response.get('qualification_types'))

        parameters = response['parameters']
        qualification_types = response['qualification_types']
        self.assertTrue(isinstance(parameters, list))
        self.assertTrue(isinstance(qualification_types, list))

    def test_project_create_and_delete(self):
        result = self.client.http.get('/qua/options')
        response = result.json_body
        parameters = response['parameters']
        qualification_types = response['qualification_types']

        name = 'Unittest Project'
        landing_zone_id = 2
        qualification_type = random.choice(qualification_types)
        qualification_type_id = qualification_type['id']
        settings = qualification_type['settings']

        result = self.client.http.post(
            '/qua/admin/projects', body={
                'name': name,
                'landing_zone_id': landing_zone_id,
                'qualification_type_id': qualification_type_id,
                'settings': settings,
                'parameters': parameters,
            }
        )
        self.assertEqual(result.status_code, 400)

        for item in settings:
            item['value'] = f'TEST {item["description"]} value'

        result = self.client.http.post(
            '/qua/admin/projects', body={
                'name': name,
                'landing_zone_id': landing_zone_id,
                'qualification_type_id': qualification_type_id,
                'settings': settings,
                'parameters': parameters,
            }
        )
        self.assertEqual(result.status_code, 200)
        response = result.json_body
        self.assertIsInstance(response.get('project_id'), int)

    def test_list_projects(self):
        result = self.client.http.get('/qua/admin/projects')
        self.assertEqual(result.status_code, 200)

        response = result.json_body
        self.assertIsInstance(response['projects'], list)

        for project in response['projects'][:1]:
            required_attrs = ['id', 'name', 'qualification_type_id', 'created_by']
            for attr in required_attrs:
                self.assertIsNotNone(project.get(attr))

            result = self.client.http.get(f'/qua/admin/projects/{project["id"]}')
            self.assertEqual(result.status_code, 200)

            retrieve_response = result.json_body
            self.assertIsInstance(retrieve_response.get('project'), dict)

            project = retrieve_response['project']
            self.assertIsInstance(project.get('settings'), list)
            self.assertIsInstance(project.get('settings'), list)

        self.assertTrue(len(response['projects']) < 30)
