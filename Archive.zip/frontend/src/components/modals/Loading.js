import React from 'react';
import PropTypes from 'prop-types';
import classnames from "classnames";

import {
  Modal,
  // ProgressBar
} from 'reactstrap';
import Loader from "react-loader-spinner";

const LoadingModal = ({
  show,
  progress,
}) => {
  const handleClose = () => {}
  return (
    <Modal show={show} onHide={handleClose} className={classnames('loading-modal')} animation={true}>
      <Loader
        type="Puff"
        color="#00BFFF"
        height={100}
        width={100}
      />
      {/* {progress && <ProgressBar now={progress} />} */}
    </Modal>
  )
}

LoadingModal.propTypes = {
  show: PropTypes.bool.isRequired,
  progress: PropTypes.number,
}

export default LoadingModal;
