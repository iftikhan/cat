from typing import List, Optional

import boto3
from src.utils.logger import Logger
from src.utils.aws.sts import STS


class RESOURCE_TYPE:
    ec2_instance = 'AWS::EC2::Instance'


class CrossAccountClientBase:
    client_name: str = None
    account_id: str = None
    cross_account_role: str = None
    region_name: str = None

    __client = None

    def __init__(
        self, client_name: Optional[str] = None, account_id: str = None,
        cross_account_role: str = None, region_name: str = None
    ) -> None:
        if isinstance(client_name, str):
            self.client_name = client_name

        if not self.client_name:
            raise ValueError('client_name can not be empty.')

        self.account_id = account_id
        self.cross_account_role = cross_account_role
        self.region_name = region_name

        self.__sts = STS()
        self.__logger = Logger()

        if account_id and cross_account_role:
            self.__client = self.get_client(account_id, cross_account_role, region_name)
        else:
            self.__client = boto3.client(self.client_name)

    @property
    def client(self):
        return self.get_client(self.account_id, self.cross_account_role, self.region_name)

    def refresh_client(self, account_id: str, cross_account_role: str, region_name: str = None):
        self.__client = self.get_client(account_id, cross_account_role, region_name)

    def log_info(self, msg: str):
        self.__logger.log_info(msg)

    def log_exception(self, exception: Exception):
        self.__logger.log_exception(exception)

    def get_client(self, account_id: str, cross_account_role: str, region_name: str = None):
        if self.__client and all(x == y for x, y in zip(
            [self.account_id, self.cross_account_role, self.region_name],
            [account_id, cross_account_role, region_name])
        ):
            return self.__client

        self.log_info(
            f"Getting {self.client_name} Client in Region: {region_name} Account ID: {account_id} "
            f"using Cross Account Role: {cross_account_role}"
        )

        return self.__sts.get_assume_role_client(
            account_id,
            region_name=region_name,
            cross_account_role=cross_account_role,
            client_name=self.client_name
        )

    def create_spec(self, actual_values: List[dict], expected_values: List[dict]):
        raise NotImplementedError()

    def get_all_provisions(self, account_id: str, cross_role: str, region: str = 'us-east-1'):
        raise NotImplementedError()

    def make_spec(self, actual_values: List[dict], expected_values: List[dict]):
        all_build_spec = []
        all_post_build_spec = []
        self.log_info("NOTE: Printing Build/Post-Build Specifications")

        actual_value_dictionary = dict([
            (item['ResourceName'], item) for item in actual_values
        ])
        for expected in expected_values:
            build_spec = {}
            post_build_spec = {}
            if expected["Section"].lower() == "build":
                build_spec["ResourceName"] = expected['ResourceName']
                build_spec["Parameter"] = expected['ExpectedVariable']
                build_spec["SectionDescription"] = expected['SectionDescription']
                build_spec["ExpectedValue"] = expected['ExpectedValue']

                # Find Actual Value
                if expected["ResourceName"] in actual_value_dictionary:
                    actual = actual_value_dictionary[expected["ResourceName"]]
                    build_spec["ActualValue"] = actual.get(expected['ExpectedVariable'])
                else:
                    build_spec["ActualValue"] = ""

                build_spec["Drift"] = (
                    build_spec["ExpectedValue"].lower() != build_spec["ActualValue"].lower()) or (
                    build_spec["ExpectedValue"] == "" and build_spec["ActualValue"] == "")

                all_build_spec.append(dict(build_spec).copy())

            elif expected["Section"].lower() == "post-build":
                post_build_spec["ResourceName"] = expected['ResourceName']
                post_build_spec["Parameter"] = expected['ExpectedVariable']
                post_build_spec["SectionDescription"] = expected['SectionDescription']
                post_build_spec["ExpectedValue"] = expected['ExpectedValue']

                # Find Actual Value
                if expected["ResourceName"] in actual_value_dictionary:
                    actual = actual_value_dictionary[expected["ResourceName"]]
                    post_build_spec["ActualValue"] = actual.get(expected['ExpectedVariable'])
                else:
                    post_build_spec["ActualValue"] = ""

                post_build_spec["Drift"] = (
                    post_build_spec["ExpectedValue"].lower() != post_build_spec["ActualValue"].lower()) or (
                    post_build_spec["ExpectedValue"] == "" and post_build_spec["ActualValue"] == "")

                all_post_build_spec.append(dict(post_build_spec).copy())

        return all_build_spec, all_post_build_spec
