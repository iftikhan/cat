"""
Launcher for local usage.

$ python migration.py create migration_name
\r\n
$ python migration.py diff
\r\n
$ python migration.py log [limit=10]
\r\n
$ python migration.py up [limit]
\r\n
$ python migration.py down limit
\r\n
$ python migration.py redo limit
\r\n

"""

import sys
from src.utils.pgsql import PgsqlManager, TABLE_NAME
from src.bin.migrations.bin import (
    action_create,
    action_diff, action_log,
    action_up, action_down, action_redo
)

if __name__ != '__main__':
    raise Exception('Import is unsupported!')

arguments = sys.argv
if len(arguments) == 1:
    print(__doc__)
    exit(0)

action_name = sys.argv[1]
action_args = sys.argv[2:]

actions_map = {
    'create': action_create,
    'diff': action_diff,
    'log': action_log,
    'up': action_up,
    'down': action_down,
    'redo': action_redo,
}


def create_migration_table_if_not_exists():
    query = """
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public';"""

    db_manager = PgsqlManager()
    conn = db_manager.get_db_connection()

    @db_manager.get_transaction_scope(conn)
    def __transaction():
        rows = conn.execute(query).fetchall()
        if TABLE_NAME.SYS_DB_MIGRATION not in [row[0] for row in rows]:
            # NOTE: Create the migration table.
            migration_table_create_query = f"""
                CREATE TABLE "{TABLE_NAME.SYS_DB_MIGRATION}" (
                    "name" varchar(255) NULL,
                    applied_at timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE UNIQUE INDEX sys_db_migration_name_idx ON sys_db_migration ("name");"""
            conn.execute(migration_table_create_query)

    __transaction()


action = actions_map.get(action_name)
if not action:
    raise Exception('Action "{}" is unknown!'.format(action_name))
else:
    create_migration_table_if_not_exists()

action(*action_args)
