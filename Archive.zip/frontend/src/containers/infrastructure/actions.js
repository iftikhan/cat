import createAction from 'redux/helpers/createAction';

export const namespace = 'infra';

export const fetchLandingZonesRequest = createAction(namespace, 'FETCH_LANDING_ZONES_REQUEST');
export const fetchLandingZonesSuccess = createAction(namespace, 'FETCH_LANDING_ZONES_SUCCESS');
export const fetchLandingZonesFailure = createAction(namespace, 'FETCH_LANDING_ZONES_FAILURE');

export const fetchLzAccountsRequest = createAction(namespace, 'FETCH_LANDING_ZONE_ACCOUNTS_REQUEST');
export const fetchLzAccountsSuccess = createAction(namespace, 'FETCH_LANDING_ZONE_ACCOUNTS_SUCCESS');
export const fetchLzAccountsFailure = createAction(namespace, 'FETCH_LANDING_ZONE_ACCOUNTS_FAILURE');

export const retrieveLzAccountRequest = createAction(namespace, 'RETRIEVE_LANDING_ZONE_ACCOUNT_REQUEST');
export const retrieveLzAccountSuccess = createAction(namespace, 'RETRIEVE_LANDING_ZONE_ACCOUNT_SUCCESS');
export const retrieveLzAccountFailure = createAction(namespace, 'RETRIEVE_LANDING_ZONE_ACCOUNT_FAILURE');
