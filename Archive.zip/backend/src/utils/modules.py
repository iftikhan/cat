def get_class_by_name(full_class_name: str) -> type:
    parts = full_class_name.split('.')

    module = __import__('.'.join(parts[:-1]))
    for submodule in parts[1:]:
        module = getattr(module, submodule)

    return module
