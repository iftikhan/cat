import React from 'react';
import PropTyes from 'prop-types'

import { useHistory } from 'react-router';

import { Tabs, Tab } from 'reactstrap';

const QualificationTabMenu = ({
  pathname,
}) => {
  const history = useHistory();
  const segs = pathname.split('/').filter(item => !!item);
  let selected = 'create-job';

  if (segs.length > 1) {
    selected = segs[1]
  }
  return (
    <div className='tabbed-menu'>
      <Tabs
        id="controlled-tab-example"
        activeKey={selected}
        onSelect={(value) => {history.push(`/gxp-qualification/${value}`)}}
      >
        <Tab eventKey="create-job" title="Create Job">
        </Tab>
        <Tab eventKey="jobs" title="View Jobs">
        </Tab>
        <Tab eventKey="dashboard" title="Dashboard">
        </Tab>
        <Tab eventKey="admin" title="Admin">
        </Tab>
      </Tabs>
    </div>
  )
};

QualificationTabMenu.propTypes = {
  pathname: PropTyes.string.isRequired,
}

export default QualificationTabMenu;
