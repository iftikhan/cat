import React from 'react';
import PropTypes from 'prop-types';

import { Col, Card, CardHeader, CardBody } from 'reactstrap'

const AccountInfo = ({
  name, accountId, roleName, resources,
  organizationUnitName
}) => {
  return (
    <Card>
      <CardHeader>Account Information</CardHeader>
      <CardBody>
        <Col>
          <table className='table'>
            <tbody>
              <tr>
                <td>Organization Unit</td>
                <td><strong>{organizationUnitName}</strong></td>
              </tr>
              <tr>
                <td>Account Name</td>
                <td><strong>{name}</strong></td>
              </tr>
              <tr>
                <td>Account Number</td>
                <td><strong>{accountId}</strong></td>
              </tr>
            </tbody>
          </table>
        </Col>
      </CardBody>
    </Card>
  )
}

AccountInfo.propTypes = {
  name: PropTypes.string.isRequired,
  accountId: PropTypes.string.isRequired,
  roleName: PropTypes.string.isRequired,
  resources: PropTypes.arrayOf(PropTypes.object),
}

export default AccountInfo;
