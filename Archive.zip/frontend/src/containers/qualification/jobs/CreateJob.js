import React, { useEffect, useState } from 'react';
import { connect  } from 'react-redux';
import { useHistory } from 'react-router';
import PropTypes from 'prop-types';

import {
  Row, Col, FormGroup, Input, Button,
} from 'reactstrap';

import API from 'helpers/api';

import NoProjectModal from 'components/modals/NoProject';
import JobCreateReport from 'components/modals/JobCreateReport';

import {
  fetchProjectsRequest,
  uploadGxPRequest, uploadGxPSuccess, uploadGxPFailure,
} from 'containers/qualification/actions';

const CreateJob = ({
  projects, fetchProjectsRequest, fetchingProjects, fetchingProjectsFinished,
  uploadGxPRequest, uploadGxPSuccess, uploadGxPFailure,
}) => {
  const fetchingParameter = false;

  const runMethods = ['Excel', 'API'];
  const history = useHistory();

  const [project, setProject] = useState(null);
  const [runMethod, setRunMethod] = useState(runMethods[0])
  const [selectedFile, setSelectedFile] = useState(null);
  const [showNoProjectModal, setShowNoProjectModal] = useState(false);
  const [showJobCreateReport, setShowJobCreateReport] = useState(false);
  const [result, setResult] = useState({});
  const [createStatus, setCreateStatus] = useState(false);

  useEffect(() => {
    fetchProjectsRequest()
  }, [fetchProjectsRequest]);

  useEffect(() => {
    if (fetchingProjectsFinished && projects.length === 0) {
      setShowNoProjectModal(true);
    } else {
      const [first] = projects;
      setProject(first?.id);
    }
  }, [projects, setShowNoProjectModal, fetchingProjectsFinished]);

  const onCreateJob = async () => {
    try {
      uploadGxPRequest()
      const { key } = await API.uploadFileToS3(project, runMethod, selectedFile);
      API.createJob(project, key, runMethod).then(res => {
        setResult(res);
        setShowJobCreateReport(true);
        setCreateStatus(true);
        uploadGxPSuccess();
        history.push('/gxp-qualification/jobs');
      }).catch(err => {
        setResult(err?.response?.data || {});
        setCreateStatus(false);
        setShowJobCreateReport(true);
        uploadGxPFailure();
      })
    } catch (err) {
      uploadGxPFailure()
      console.error(err);
      alert('Failed to upload file to s3.');
    }
  }

  return (
    <>
      <h2>Create a Job</h2>
      <FormGroup className="mt-3" disabled={fetchingParameter}>
        <Row>
          <Col sm="2">
            <label className='mt-2'>Project</label>
          </Col>
          <Col sm="5">
            <Input
              type="select" value={project ? project : ''}
              onChange={e => setProject(e.target.value)}>
              {projects.map(({id, name}, idx) => (
                <option key={id} value={id}>{name}</option>
              ))}
            </Input>
          </Col>
        </Row>
      </FormGroup>
      <FormGroup className="mt-3" disabled={fetchingParameter}>
        <Row>
          <Col sm={2}>
            <label className='mt-2'>Run Method</label>
          </Col>
          <Col sm="3">
            {runMethods.map((method, idx) => (
              <div key={idx} className="custom-control custom-radio mb-3">
                <input
                  className="custom-control-input"
                  id={`qualification-create-job-run-method-${method}`}
                  type="radio" value={method}
                  checked={method === runMethod}
                  onChange={(event) => setRunMethod(event.target.value)}
                />
                <label
                  className="custom-control-label"
                  htmlFor={`qualification-create-job-run-method-${method}`}
                >
                  <span className="text-muted">{method}</span>
                </label>
              </div>
            ))}
          </Col>
        </Row>
      </FormGroup>
      <br />
      <FormGroup className="mb-3 mt-3">
        <Row>
          <Col sm="2">
            <label className='mt-2'>Upload GxP</label>
          </Col>
          <Col sm="10" lg={8}>
            <div className="custom-file">
              <input
                className="custom-file-input"
                id="qualification-create-job-file"
                // placeholder='Choose File'
                disabled={runMethod !== 'Excel'}
                accept='application/excel .csv .xlsx'
                lang="en" type="file"
                onChange={event => {setSelectedFile(event.target.files[0])}}
              />
              <label className="custom-file-label" htmlFor="qualification-create-job-file">
                {selectedFile ? selectedFile.name : "Choose File"}
              </label>
            </div>
          </Col>
        </Row>
      </FormGroup>
      <br />
      <Row>
        <Col>
          <Button
            color="primary" type="submit"
            disabled={(runMethod === 'Excel' && !selectedFile)} onClick={onCreateJob}
          >
            Validate
          </Button>
        </Col>
      </Row>
      <NoProjectModal show={showNoProjectModal} />
      <JobCreateReport
        show={showJobCreateReport} onHide={() => setShowJobCreateReport(false)}
        validationResult={result} success={createStatus}
        />
    </>
  )
}

CreateJob.propTypes = {
  projects: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.oneOfType([
      PropTypes.number, PropTypes.string
    ]).isRequired,
    name: PropTypes.string.isRequired
  })).isRequired,
  fetchingProjectsFinished: PropTypes.bool.isRequired,
  fetchProjectsRequest: PropTypes.func.isRequired,
  uploadGxPRequest: PropTypes.func.isRequired,
  uploadGxPSuccess: PropTypes.func.isRequired,
  uploadGxPFailure: PropTypes.func.isRequired,
}

const mapStateToProps = state => ({
  projects: state.qualifications.projects,
  fetchingProjects: state.qualifications.fetchingProjects,
  fetchingProjectsFinished: state.qualifications.fetchingProjectsFinished,
});

const mapDispatchToProps = dispatch => ({
  fetchProjectsRequest: () => dispatch(fetchProjectsRequest()),
  uploadGxPRequest: () => dispatch(uploadGxPRequest()),
  uploadGxPSuccess: () => dispatch(uploadGxPSuccess()),
  uploadGxPFailure: () => dispatch(uploadGxPFailure()),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateJob);
