import createAction from 'redux/helpers/createAction';

export const namespace = 'settings';

export const DO_SOMETHING = createAction(namespace, 'DO_SOMETHING');

