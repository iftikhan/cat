import React, { useState } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';

import {
  Row, Col, Button,
} from 'reactstrap';
import BootstrapTable from 'react-bootstrap-table-next';

import UserModal from 'components/modals/User';

const UsersTable = ({
  users, isLoading, onInviteUser, onUpdateUser,
}) => {
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showUpdateUserModal, setShowUpdateUserModal] = useState(false);
  const [curUser, setCurUser] = useState(null);

  const onClickEdit = (row) => {
    const {
      id, role, email,
    } = row;

    setCurUser({id, email, role});
    setShowUpdateUserModal(true)
  }

  const columns = [
    {
      dataField: 'id',
      text: 'User ID',
      // headerStyle: { width: '280px', textAlign: 'center' },
      style: { textAlign: 'left' },
    }, {
      dataField: 'email',
      text: 'Email',
      // headerStyle: { width: '180px', textAlign: 'center' },
    }, {
      dataField: 'role',
      text: 'Role',
      headerStyle: { width: '120px', textAlign: 'center' },
    }, {
      dataField: 'action',
      text: '',
      style: {
        textAlign: 'center',
        display: 'flex',
        justifyContent: 'space-evenly',
      },
      headerStyle: { width: '180px' },
      formatter: (cel, row, rowIndex) => {
        return (<>
          <Button
            title='Edit Account'
            className={classnames('btn-sm btn-primary')}
            onClick={() => onClickEdit(row)}>Edit</Button>
        </>)
      },
    },
  ]


  return (
    <>
      <br />
      <Row>
        <Col><h2>Users</h2></Col>
        <Col>
          <Button className='btn-sm float-right' onClick={() => setShowInviteModal(true)}>invite user</Button>
        </Col>
      </Row>
      <BootstrapTable
        keyField='id' data={ users } columns={ columns }
        noDataIndication={isLoading ? 'Loading...' : 'No job yet.'}
      />
      <UserModal
        show={showInviteModal}
        handleClose={() => setShowInviteModal(!showInviteModal)}
        handleSubmit={onInviteUser}
        />
      {curUser && <UserModal
        show={showUpdateUserModal}
        userData={curUser}
        handleClose={() => setShowUpdateUserModal(!showUpdateUserModal)}
        handleSubmit={onUpdateUser(curUser.id)}
        />}
    </>
  )
}

UsersTable.propTypes = {
  isLoading: PropTypes.bool.isRequired,
  users: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.string.isRequired,
    email: PropTypes.string.isRequired,
    role: PropTypes.string.isRequired,
  })).isRequired,
  credentials: PropTypes.shape({
  }),
  onInviteUser: PropTypes.func.isRequired,
  onUpdateUser: PropTypes.func.isRequired,
}

UsersTable.defaultProps = {
  credentials: {},
}

export default UsersTable;
