import React, { useEffect, useState } from 'react';
import { useParams, useHistory } from 'react-router-dom';
import { connect } from 'react-redux';

import API from 'helpers/api';

import LoadingModal from 'components/modals/Loading';
import { retrieveLzAccountRequest } from './actions';

import Wizard from 'components/molecules/infra/wizards/index';

const ResourceDetails = ({
  accountDetails, retrieveLzAccountRequest, retrievingInfraDetails,
}) => {
  const { landingZoneId, accountId, resourceId } = useParams();
  const [loading, setLoading] = useState(false);
  const [resource, setResource] = useState(null);

  const history = useHistory();

  const goToResourceListPage = () => {
    history.push(`/gxp-infra/${landingZoneId}/accounts/${accountId}/resources`)
  }

  const onUpdateNewResource = (resourceName: String, parameters: Object) => {
    setLoading(true);
    API.updateInfrastructure(landingZoneId, accountId, resourceId, resourceName, parameters).then(res => {
      goToResourceListPage()
    }).catch(err => {
      console.error(err);
      alert('Failed to create resource.')
    }).finally(() => {
      setLoading(false);
    })
  }

  useEffect(() => {
    setLoading(true)
    API.retrieveLzAccountstructure(landingZoneId, accountId, resourceId).then(({
      resource, status
    }) => {
      if (status) {
        setResource(resource);
      } else {
        alert('Failed to retrieve resource');
      }
    }).catch(err => {
      console.error(err);
      alert('Can not retrieve resource');
    }).finally(() => {
      setLoading(false);
    })
  }, [landingZoneId, accountId, resourceId]);

  const renderResource = () => {
    const {
      stack_id: stackId, properties,
      name, status, resource_type: resourceType, description,
    } = resource;

    return (
      <>
        <br />
        <h3>{name}</h3>
        <p>{description}</p>
        <span>Resource Type: <strong>{resourceType}</strong></span>
        <hr />
        <Wizard
          type={resourceType} name={name}
          stackId={stackId}
          disabled={status === 'provisioning'}
          properties={properties}
          onSubmit={onUpdateNewResource}
          onClose={goToResourceListPage} />
      </>
    )
  }

  return (
    <>
      {resource && renderResource()}
      <LoadingModal show={loading} />
    </>
  )
}

const mapStateToProps = state => ({
  retrievingInfraDetails: state.infra.retrievingInfraDetails,
  accountDetails: state.infra.accountDetails,
});

const mapDispatchToProps = dispatch => ({
  retrieveLzAccountRequest: (landingZoneId, accountId) => dispatch(retrieveLzAccountRequest({accountId, landingZoneId})),
})

export default connect(mapStateToProps, mapDispatchToProps)(ResourceDetails);
