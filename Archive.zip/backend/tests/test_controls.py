from .utils.base import ServerlessTestCase


class GxPControlTestCase(ServerlessTestCase):
    def test_get_managed_rules(self):
        result = self.client.http.get('/controls/managed_rules?provider=aws')
        self.assertEqual(result.status_code, 200)
        self.assertTrue('managed_rules' in result.json_body)

        managed_rules = result.json_body['managed_rules']
        self.assertTrue(all(isinstance(item, dict) for item in managed_rules))

    def test_get_managed_rules_per_landing_zone(self):
        result = self.client.http.get(
            '/controls/managed_rules?provider=aws&landing_zone_id=1')
        self.assertEqual(result.status_code, 200)
        self.assertTrue('managed_rules' in result.json_body)

        managed_rules = result.json_body['managed_rules']
        self.assertTrue(all(isinstance(item, dict) for item in managed_rules))

    def test_apply_managed_rules(self):
        result = self.client.http.post(
            '/controls/apply',
            body={
                'managed_rule_ids': [2, 3],
                'account_ids': [1, 2]
            })
        self.assertEqual(result.status_code, 200)
        self.assertTrue('status' in result.json_body)
        self.assertTrue(result.json_body['status'])

    def test_list_rules_per_account(self):
        account_id = 2
        result = self.client.http.get(f'/controls/accounts/{account_id}/rules')
        self.assertEqual(result.status_code, 200)
        self.assertTrue('account_rules' in result.json_body)

        account_rules = result.json_body['account_rules']
        self.assertTrue(all(isinstance(item, dict) for item in account_rules))

    def test_update_rules_per_account(self):
        account_id = 2
        result = self.client.http.put(
            f'/controls/accounts/{account_id}/rules',
            body={
                'managed_rule_ids': [2, 3],
            })
        self.assertEqual(result.status_code, 200)
        self.assertTrue('status' in result.json_body)
        self.assertTrue(result.json_body['status'])
