import os
import shutil
from datetime import datetime
from typing import Dict, Optional

import boto3
import pdfkit
from urllib.parse import unquote_plus
from jinja2 import Environment, FileSystemLoader

from src.config import settings
from src.utils.aws.s3 import S3Util
from src.utils.logger import Logger
from src.models.jobs import JobEntry


class ServiceInterface:
    def collect_resource(self, job_entry: JobEntry):
        raise NotImplementedError()

    def generate_report(self, job_entry: JobEntry, key_path: str):
        raise NotImplementedError()

    def validate(self, project_id: int, key_path: str, run_method: str) -> Dict[str, bool]:
        raise NotImplementedError()


class ResourceCollectorBase:
    def make_test_summary(self, all_build_spec, all_post_build_spec):
        test_summary = {}

        total_build_passed_cases = 0
        total_build_failed_cases = 0
        for build_spec in all_build_spec:
            for drift_build_spec in build_spec.get("Spec"):
                if drift_build_spec.get("Drift"):
                    total_build_failed_cases = total_build_failed_cases + 1
                if not drift_build_spec.get("Drift"):
                    total_build_passed_cases = total_build_passed_cases + 1

        total_post_build_passed_cases = 0
        total_post_build_failed_cases = 0
        for post_build_spec in all_post_build_spec:
            for drift_post_build_spec in post_build_spec.get("Spec"):
                if drift_post_build_spec.get("Drift"):
                    total_post_build_failed_cases = total_post_build_failed_cases + 1
                if not drift_post_build_spec.get("Drift"):
                    total_post_build_passed_cases = total_post_build_passed_cases + 1

        test_summary["build_summary"] = {
            "total_test_cases": total_build_passed_cases + total_build_failed_cases,
            "total_passed_cases": total_build_passed_cases,
            "total_failed_cases": total_build_failed_cases
        }
        test_summary["post_build_summary"] = {
            "total_test_cases": total_post_build_passed_cases + total_post_build_failed_cases,
            "total_passed_cases": total_post_build_passed_cases,
            "total_failed_cases": total_post_build_failed_cases
        }

        return test_summary


class ReportBase:

    DATE_FORMAT = "%d-%b-%Y %I:%M:%S %z"
    template_category: str = None

    def __init__(self) -> None:
        self.__logger = Logger()
        self.s3_client = boto3.client("s3")

        if not self.template_category:
            raise ValueError('template_category is required.')

    def generate_pdf(self, data, report_key_path: str, s3_kms) -> Optional[str]:
        self.__logger.log_info("NOTE: Running generate_pdf.")
        report_filename = '.'.join(os.path.basename(report_key_path).split('.'))
        _, header_file_path = self.process_template('header', data, report_filename)
        _, footer_file_path = self.process_template('footer', data, report_filename)
        html, _ = self.process_template('_main', data, report_filename)

        tmp_file_path = '/tmp/' + report_filename

        pdf_generator_bin = '/opt/bin/wkhtmltopdf'
        if not os.path.exists(pdf_generator_bin):
            pdf_generator_bin = shutil.which('wkhtmltopdf')

        options = {
            "header-html": header_file_path,
            "footer-html": footer_file_path,
            "enable-local-file-access": None,
            'encoding': 'utf-8'
        }
        config = pdfkit.configuration(wkhtmltopdf=pdf_generator_bin)
        pdfkit.from_string(
            html,
            tmp_file_path,
            configuration=config,
            options=options
        )

        if os.path.exists(tmp_file_path):
            s3_util = S3Util()
            s3_util.upload_file_to_s3(tmp_file_path, settings.STORAGE_BUCKET, report_key_path)
            return report_key_path
        else:
            self.__logger.log_info('PDF file is not available!')

    def process_template(self, template_type: str, data, output_file_name):
        self.__logger.log_info("NOTE: Running process_template.")

        images_path = os.path.join(settings.TEMPLATES_DIR, 'images')
        report_time = datetime.utcnow().strftime(self.DATE_FORMAT) + " UTC"

        file = os.path.join(settings.TEMPLATES_DIR, self.template_category, f'{template_type}.html')
        with open(file, 'r') as f:
            jinja_main = f.read()
        jinja_complete_template = Environment(
            loader=FileSystemLoader(
                os.path.join(settings.TEMPLATES_DIR, self.template_category)
            )).from_string(jinja_main)

        html = jinja_complete_template.render(
            images_path=images_path,
            date=report_time,
            data=data
        )

        html_file_path = f'/tmp/{output_file_name.rsplit(".", 1)[0]}-{template_type}.html'
        with open(html_file_path, 'w') as f:
            f.write(html)

        return html, html_file_path

    def generate_report(self, job_entry: JobEntry, key_path: str) -> Optional[str]:
        key_path = unquote_plus(key_path)
        s3_util = S3Util()
        collected_resources = s3_util.read_json_file(settings.STORAGE_BUCKET, key_path)

        output_folder = f'public/{job_entry.project_id}/{job_entry.user_id}/{job_entry.id}/reports'
        output_file_name = f"{'.'.join(job_entry.filename.split('.')[:-1])}.pdf"
        s3_kms = os.environ.get("bucketKMS", "")

        # Generate the iqoq report and save it the output s3 bucket
        return self.generate_pdf(collected_resources, f'{output_folder}/{output_file_name}', s3_kms)
