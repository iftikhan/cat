import React from 'react';

const JobReport = () => {
  return (
    <>
      <h2>Job Report</h2>
    </>
  )
}

export default JobReport;
