import json

from src.utils.auth import get_authenticated_user
from src.utils.response import build_response
from src.models.users import UserModel
from src.models.admin.accounts import AccountModel


def admin_manage_accounts(event, context):
    user_id = get_authenticated_user(event)
    user_model = UserModel()
    current_user = user_model.retrieve_user(user_id)

    if not current_user.is_admin:
        return build_response({
            'msg': 'access denied',
        }, 403)

    http_method = event['requestContext']['httpMethod']
    # query_params = event.get('queryStringParameters') or {}
    http_path = event['path']
    path_params = event.get('pathParameters', {})
    account_model = AccountModel()
    print(path_params)

    if http_path == '/admin/accounts':
        if http_method == 'GET':
            # created_by = query_params.get('created_by')
            accounts = account_model.list_accounts()
            return build_response({
                'accounts': [account.to_dict() for account in accounts],
            })
        elif http_method == 'POST':
            params = json.loads(event['body'] or '{}')
            required = ['account_name', 'account_id', 'aws_access_key_id', 'aws_secret_access_key']
            for attr in required:
                if attr not in params or not params.get(attr):
                    return build_response({
                        attr: f'{attr} is required.'
                    }, 400)

            account_model.create_account(
                params['account_name'], params['account_id'],
                params['aws_access_key_id'], params['aws_secret_access_key'],
            )

            return build_response({
                'status': True,
            })
    elif 'id' in path_params:
        id = path_params['id']
        if http_method == 'PUT':
            params = json.loads(event['body'] or '{}')
            required = ['account_name', 'account_id', 'aws_access_key_id', 'aws_secret_access_key']
            for attr in required:
                if attr not in params or not params.get(attr):
                    return build_response({
                        attr: f'{attr} is required.'
                    }, 400)

            account_model.update_account(
                id, params['account_name'], params['account_id'],
                params['aws_access_key_id'], params['aws_secret_access_key'],
            )
    return build_response({})
