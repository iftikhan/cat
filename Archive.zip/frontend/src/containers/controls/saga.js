// import { call, put, takeEvery } from 'redux-saga/effects';

// import API from 'helpers/api';
import {
} from './actions';

// function* fetchLandingZoneAccounts() {
//   try {
//     const { infras } = yield call(API.fetchLandingZoneAccounts);
//     yield put(fetchLzAccountsSuccess({ infras }));
//   } catch (e) {
//     yield put(fetchLzAccountsFailure());
//   }
// }

export const controlSagas = [
];
