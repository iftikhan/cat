class PathNotFoundException(Exception):
    pass
