import React from 'react';
import PropTypes from 'prop-types';

import { Input } from 'reactstrap';
import Select2 from "react-select2-wrapper";

import { CloudServices } from 'utils/constants';

const CloudServicesSelect = ({
  onChange, value, provider, id, multiple, className,
}) => {
  const services = !!provider ? (CloudServices[provider] || []) :
    Object.values(CloudServices).reduce((a, b) => a.concat(b), []);
  if (multiple) {
    return (
      <Select2
        className={className}
        data-minimum-results-for-search="Infinity"
        defaultValue={value}
        multiple
        id={id}
        onChange={(e) => {onChange(Array.from(e.target.selectedOptions, option => option.value))}}
        data={services.map((item) => ({id: item, text: item}))}
        />
    )
  }

  return (
    <Input
      className={className}
      type='select' value={value}
      onChange={(event) => onChange(event.target.value)}
    >
      <option value={''}>All Services</option>
      {services.map((item, idx) => (
        <option key={idx} value={item}>{item.toUpperCase()}</option>
      ))}
    </Input>
  )
}

CloudServicesSelect.propTypes = {
  value: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.arrayOf(PropTypes.string),
  ]),
  onChange: PropTypes.func.isRequired,
  provider: PropTypes.string.isRequired,
  multiple: PropTypes.bool,
  className: PropTypes.string,
};

CloudServicesSelect.defaultProps = {
  value: '',
  multiple: false,
  className: "form-control-sm",
};

export default CloudServicesSelect;
