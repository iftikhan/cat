from src.config import settings
from .utils.base import ServerlessTestCase


class CreateJobTestCase(ServerlessTestCase):
    def test_create_CEMF_job(self):
        params = {
            "project_id": "2",
            "key_path": "2/5e4704f4-fd07-4768-90b4-f3111662d692/drafts/CEMF-blueprint-Wave2021(2).csv",
            "run_method": "Excel"
        }
        result = self.client.http.post('/qua/jobs', body=params)
        self.assertEqual(result.status_code, 201)
        response = result.json_body
        self.assertTrue(response['excel'])
        self.assertTrue(response['assume_role'])
        self.assertTrue(response['ec2'])
        self.assertTrue(response['iam'])

    def test_create_lz_job(self):
        params = {
            'project_id': 6,
            'run_method': 'Excel',
            'key_path': (
                '2/5e4704f4-fd07-4768-90b4-f3111662d692/drafts/'
                'expected_values_sheet_lz_with_accounts(new).xlsx'
            ),
        }

        result = self.client.http.post('/qua/jobs', body=params)
        self.assertEqual(result.status_code, 201)
        response = result.json_body
        self.assertTrue(response['excel'])
        self.assertTrue(response['assume_role'])
        self.assertTrue(response['ec2'])
        self.assertTrue(response['iam'])

    def test_init_job(self):
        # job_ids = [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
        job_ids = [20]  # , 14, 15]
        for job_id in job_ids:
            params = {'job_id': job_id}
            result = self.client.lambda_function.invoke_lambda(
                settings.INIT_JOB_FUNCTION_NAME, params)
            assert result is None

    def test_jobs_list(self):
        result = self.client.http.get('/qua/jobs')
        assert result.status_code == 200

        response = result.json_body
        assert 'jobs' in response
        jobs = response['jobs']
        assert isinstance(jobs, list)

    def test_jobs_dashboard(self):
        result = self.client.http.get('/qua/jobs/dashboard')
        assert result.status_code == 200

        response = result.json_body
        assert 'jobs' in response
        jobs = response['jobs']
        assert isinstance(jobs, list)
