from src.config import settings


def get_authenticated_user(event: dict = {}) -> str:
    if settings.IS_LOCAL:
        return settings.LOCAL_HARDCODED_USERNAME

    authorizer = event['requestContext']['authorizer']['claims']
    return authorizer['cognito:username']
