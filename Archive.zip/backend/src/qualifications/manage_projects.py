import json

from src.utils.auth import get_authenticated_user
from src.utils.response import build_response
from src.models.users import UserModel
from src.models.admin.projects import ProjectModel


def admin_manage_projects(event, context):
    user_id = get_authenticated_user(event)
    user_model = UserModel()
    current_user = user_model.retrieve_user(user_id)

    if not current_user.is_admin:
        return build_response({
            'msg': 'access denied',
        }, 403)

    http_method = event['requestContext']['httpMethod']
    # query_params = event.get('queryStringParameters') or {}
    http_path = event['path']
    path_params = event.get('pathParameters', {})
    project_model = ProjectModel()

    if http_path == '/qua/admin/projects':
        if http_method == 'GET':
            # created_by = query_params.get('created_by')
            projects = project_model.list_projects()
            return build_response({
                'projects': [project.to_dict() for project in projects],
            })
        elif http_method == 'POST':
            params = json.loads(event['body'] or '{}')
            required = ['name', 'qualification_type_id', 'settings', 'parameters']
            for attr in required:
                if attr not in params or not params.get(attr):
                    return build_response({
                        attr: f'{attr} is required.'
                    }, 400)

            for idx, setting in enumerate(params['settings']):
                if not setting.get('value'):
                    return build_response({
                        'settings': f'value can not be empty at index - {idx}'
                    }, 400)

            project_id = project_model.create(
                params['name'], params['qualification_type_id'], params['landing_zone_id'],
                current_user.id, params['settings'], params['parameters']
            )

            return build_response({
                'status': True,
                'project_id': project_id
            })
    elif 'id' in path_params:
        id = path_params['id']
        if http_method == 'GET':
            project = project_model.get_detail(id)
            return build_response({
                'status': True,
                'project': project.to_dict(),
            })
        elif http_method == 'PUT':
            params = json.loads(event['body'] or '{}')

            response = project_model.update(id, **params)
            return build_response({
                'status': response
            })
    return build_response({})
