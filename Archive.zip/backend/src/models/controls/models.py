import itertools
from typing import List

from sqlalchemy.engine.base import Connection
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy import UniqueConstraint
from sqlalchemy.sql.elements import and_, not_
from src.models.infra.entries import LandingZoneAccountEntry

from src.utils.logger import Logger
from src.utils.constants import CloudProvider
from src.utils.pgsql import PG_DB_TABLE, PgsqlManager
from src.models.controls.entries import ManagedConfigRule


class ControlsModel:
    __connection: Connection = None

    def __init__(self) -> None:
        self.__db_manager = PgsqlManager()

        self.__logger = Logger()

    @property
    def connection(self) -> Connection:
        if not self.__connection:
            self.__connection = self.__db_manager.get_db_connection()

        return self.__connection

    def get_managed_rules(self, provider: str = None) -> List[ManagedConfigRule]:
        stmt = PG_DB_TABLE.managed_config_rules.select()
        if provider:
            stmt = stmt.where(
                PG_DB_TABLE.managed_config_rules.c.provider == provider
            )
        rows = self.connection.execute(stmt)
        return [ManagedConfigRule(**row) for row in rows]

    def create_managed_rule(
        self, provider: CloudProvider, name: str, services: List[str] = [],
        standards: List[str] = [], tags: List[str] = [], description: str = ''
    ):
        stmt = PG_DB_TABLE.managed_config_rules.insert().values(
            provider=provider.value,
            name=name, services=services,
            tags=tags, description=description,
            standards=standards,
        )

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)
            return response.rowcount

        return __transaction()

    def retrieve_managed_rule(self, rule_id: int) -> ManagedConfigRule:
        stmt = PG_DB_TABLE.managed_config_rules.select().where(
            PG_DB_TABLE.managed_config_rules.c.id == rule_id
        )
        row = self.connection.execute(stmt).fetchone()
        return ManagedConfigRule(**row) if row else None

    def update_managed_rule(self, rule_id: int, **kwargs) -> bool:
        permitted_attrs = ['provider', 'services', 'tags', 'standards', 'description']
        params = {}
        for key, value in kwargs.items():
            if key not in permitted_attrs:
                continue

            if key == 'provider':
                params[key] = CloudProvider(value).value
            else:
                params[key] = value

        if not params:
            return False

        stmt = PG_DB_TABLE.managed_config_rules.update().where(
            PG_DB_TABLE.managed_config_rules.c.id == rule_id
        ).values(**params)

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)
            return response.rowcount

        return __transaction()

    def get_managed_rules_per_landing_zone(
        self, landing_zone_id: int, provider: CloudProvider = CloudProvider.aws
    ) -> List[ManagedConfigRule]:
        query = f"""
            SELECT
                (CASE
                    WHEN grouped_acr.number_of_accounts_applied is null
                    THEN 0 else grouped_acr.number_of_accounts_applied
                END) AS number_of_accounts_applied,
                mcr.*
            FROM managed_config_rules mcr LEFT JOIN (
                SELECT acr.managed_config_rule_id, count(*) AS number_of_accounts_applied
                    FROM account_config_rules acr JOIN (
                        SELECT *
                        FROM landing_zone_accounts
                        WHERE landing_zone_id = {landing_zone_id}
                    ) lza ON acr.landing_zone_account_id = lza.id
                GROUP BY managed_config_rule_id
                ) AS grouped_acr ON mcr.id = grouped_acr.managed_config_rule_id
            WHERE mcr.provider = '{provider.value}'
            ORDER BY number_of_accounts_applied desc
            ;"""
        rows = self.connection.execute(query)
        return [ManagedConfigRule(**row) for row in rows]

    def apply_managed_rules_to_accounts(
        self, managed_rule_ids: List[int], account_ids: List[int], applied_by: str
    ):
        insert_stmt = insert(PG_DB_TABLE.account_config_rules).values([
            {
                'managed_config_rule_id': managed_rule_id,
                'landing_zone_account_id': account_id,
                'applied_by': applied_by
            }
            for (managed_rule_id, account_id)
            in itertools.product(managed_rule_ids, account_ids)
        ])
        update_on_duplicate = insert_stmt.on_conflict_do_update(
            constraint=UniqueConstraint(
                PG_DB_TABLE.account_config_rules.c.landing_zone_account_id,
                PG_DB_TABLE.account_config_rules.c.managed_config_rule_id,
            ),
            set_={
                'updated_at': insert_stmt.excluded.updated_at,
            }
        )

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(update_on_duplicate)
            return response.rowcount > 0

        return __transaction()

    def list_managed_rules_per_account(self, account_id: int) -> List[ManagedConfigRule]:
        query = f"""
            SELECT
                acr.landing_zone_account_id is not null as is_applied_to_account,
                mcr.*
            FROM managed_config_rules mcr
                LEFT JOIN (
                    SELECT managed_config_rule_id,landing_zone_account_id
                    FROM account_config_rules
                    WHERE landing_zone_account_id = {account_id}
                ) acr ON mcr.id = acr.managed_config_rule_id
            ORDER BY mcr.id;"""
        rows = self.connection.execute(query)
        return [ManagedConfigRule(**row) for row in rows]

    def update_rules_per_account(self, account_id: int, managed_rule_ids: List[int], applied_by: str):
        delete_stmt = PG_DB_TABLE.account_config_rules.delete().where(
            and_(
                PG_DB_TABLE.account_config_rules.c.landing_zone_account_id == account_id,
                not_(PG_DB_TABLE.account_config_rules.c.managed_config_rule_id.in_(managed_rule_ids))
            )
        )

        insert_stmt = insert(PG_DB_TABLE.account_config_rules).values([
            {
                'managed_config_rule_id': managed_rule_id,
                'landing_zone_account_id': account_id,
                'applied_by': applied_by
            }
            for managed_rule_id
            in managed_rule_ids
        ])
        update_on_duplicate = insert_stmt.on_conflict_do_update(
            constraint=UniqueConstraint(
                PG_DB_TABLE.account_config_rules.c.landing_zone_account_id,
                PG_DB_TABLE.account_config_rules.c.managed_config_rule_id,
            ),
            set_={
                'updated_at': insert_stmt.excluded.updated_at,
            }
        )

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(delete_stmt)
            self.__logger.log_info(f'{response.rowcount} rules removed from {account_id} account!')

            response = self.connection.execute(update_on_duplicate)
            self.__logger.log_info(f'{response.rowcount} rules inserted or updated!')
            return response.rowcount > 0

        return __transaction()

    def list_accounts_per_managed_rule(
        self, rule_id: int, landing_zone_id: int = None
    ) -> List[LandingZoneAccountEntry]:
        where_clause = f"WHERE landing_zone_id = {landing_zone_id}" if landing_zone_id else ''
        query = f"""
            SELECT
                (acr.landing_zone_account_id is not null) AS is_applied,
                lza.*
            FROM landing_zone_accounts lza
                LEFT JOIN (
                    SELECT landing_zone_account_id
                    FROM account_config_rules
                    WHERE managed_config_rule_id = {rule_id}
                ) acr ON lza.id = acr.landing_zone_account_id
            {where_clause}
            ORDER BY lza.id;"""
        rows = self.connection.execute(query)
        return [LandingZoneAccountEntry(**row) for row in rows]

    def update_accounts_per_rule(self, rule_id: int, account_ids: List[int], applied_by: str):
        delete_stmt = PG_DB_TABLE.account_config_rules.delete().where(
            and_(
                PG_DB_TABLE.account_config_rules.c.managed_config_rule_id == rule_id,
                not_(PG_DB_TABLE.account_config_rules.c.landing_zone_account_id.in_(account_ids))
            )
        )

        insert_stmt = insert(PG_DB_TABLE.account_config_rules).values([
            {
                'managed_config_rule_id': rule_id,
                'landing_zone_account_id': account_id,
                'applied_by': applied_by
            }
            for account_id
            in account_ids
        ])
        update_on_duplicate = insert_stmt.on_conflict_do_update(
            constraint=UniqueConstraint(
                PG_DB_TABLE.account_config_rules.c.landing_zone_account_id,
                PG_DB_TABLE.account_config_rules.c.managed_config_rule_id,
            ),
            set_={
                'updated_at': insert_stmt.excluded.updated_at,
            }
        )

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(delete_stmt)
            self.__logger.log_info(f'{response.rowcount} accounts removed from {rule_id} rule!')

            response = self.connection.execute(update_on_duplicate)
            self.__logger.log_info(f'{response.rowcount} rules inserted or updated!')
            return response.rowcount > 0

        return __transaction()
