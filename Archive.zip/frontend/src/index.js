/*!

=========================================================
* Argon Dashboard PRO React - v1.2.1
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-dashboard-pro-react
* Copyright 2021 Creative Tim (https://www.creative-tim.com)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
import React from "react";
import ReactDOM from "react-dom";
import Amplify from 'aws-amplify';
import * as Sentry from "@sentry/react";
import { Integrations } from "@sentry/tracing";

// react library for routing
import { BrowserRouter } from "react-router-dom";

// plugins styles from node_modules
import "react-notification-alert/dist/animate.css";
import "react-perfect-scrollbar/dist/css/styles.css";
import "@fullcalendar/common/main.min.css";
import "@fullcalendar/daygrid/main.min.css";
import "sweetalert2/dist/sweetalert2.min.css";
import "select2/dist/css/select2.min.css";
import "quill/dist/quill.core.css";
import "@fortawesome/fontawesome-free/css/all.min.css";
// plugins styles downloaded
import "assets/vendor/nucleo/css/nucleo.css";
// core styles
import "assets/scss/argon-dashboard-pro-react.scss?v1.2.0";
import 'assets/scss/App.scss';

import config from './aws-export';

import App from "App";

const { aws_cloud_logic_custom: endpoints } = config;

if (process.env.NODE_ENV === 'development') {
  config['aws_cloud_logic_custom'][0]['endpoint'] = 'http://localhost:8000/dev';
}

Amplify.configure({
  Auth: {
    mandatorySignIn: true,
    region: config.aws_project_region,
    userPoolId: config.aws_user_pools_id,
    identityPoolId: config.aws_cognito_identity_pool_id,
    userPoolWebClientId: config.aws_user_pools_web_client_id,
    authenticationFlowType: 'USER_PASSWORD_AUTH',
  },
  API: {
    endpoints: endpoints,
  },
  Storage: { 
    bucket: process.env.REACT_APP_STORAGE_BUCKET,
    region: process.env.REACT_APP_REGION,
    identityPoolId: config.aws_cognito_identity_pool_id,
  }
});

if (process.env.NODE_ENV !== 'development') {
  Sentry.init({
    dsn: "https://6d19cdc62d6d41c2ac25224b5c755f64@o917954.ingest.sentry.io/5905994",
    integrations: [new Integrations.BrowserTracing()],
    // Set tracesSampleRate to 1.0 to capture 100%
    // of transactions for performance monitoring.
    // We recommend adjusting this value in production
    tracesSampleRate: 1.0,
  });
}

ReactDOM.render(
  <BrowserRouter>
    <App />
  </BrowserRouter>,
  document.getElementById("root")
);
