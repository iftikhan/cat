import React from 'react';
import PropTypes from 'prop-types';

import S3Wizard from "./s3";
import Ec2Wizard from "./ec2";

const Wizard = ({
  type, stackId, ...others
}) => {
  const components = {
    s3: S3Wizard,
    ec2: Ec2Wizard,
  }

  const Component = components[type];
  
  return <Component stackId={stackId} {...others} />
};

Wizard.propTypes = {
  type: PropTypes.string.isRequired,
  name: PropTypes.string,
  stackId: PropTypes.string,
  disabled: PropTypes.bool,
}

Wizard.defaultProps = {
  name: '',
  stackId: '',
  disabled: false,
}

export default Wizard;
