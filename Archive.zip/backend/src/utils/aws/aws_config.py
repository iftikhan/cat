from typing import List
from .common import CrossAccountClientBase


class AwsConfig(CrossAccountClientBase):
    client_name = 'config'

    def describe_config_ruls(self, rule_names: List[str]):
        response = self.client.describe_config_rules(
            ConfigRuleNames=rule_names,
            # NextToken='string'
        )
        return response
