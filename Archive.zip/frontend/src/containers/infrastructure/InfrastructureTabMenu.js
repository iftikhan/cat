import React from 'react';
import PropTyes from 'prop-types'

import { useHistory } from 'react-router';

import { Tabs, Tab } from 'reactstrap';

const InfrastructureTabMenu = ({
  pathname,
}) => {
  const history = useHistory();
  const segs = pathname.split('/').filter(item => !!item);
  let selected = 'dashboard';

  if (segs.length > 1) {
    selected = ['dashboard', 'admin'].indexOf(segs[1]) >= 0 ? segs[1] : 'create';
  }
  return (
    <div className='tabbed-menu'>
      <Tabs
        className='tab-infra' id="controlled-tab-example" activeKey={selected}
        onSelect={(value) => {history.push(`/gxp-infra/${value}`)}}
      >
        <Tab eventKey="dashboard" title="Dashboard">
        </Tab>
        <Tab eventKey="create" title="Create Infrastructure">
        </Tab>
        <Tab eventKey="admin" title="Admin">
        </Tab>
      </Tabs>
    </div>
  )
};

InfrastructureTabMenu.propTypes = {
  pathname: PropTyes.string.isRequired,
}

export default InfrastructureTabMenu;
