echo "Sending message to migrate database..."
aws lambda invoke --function-name gxpvalidator-$STAGE-tool \
    --payload fileb://$CODEBUILD_SRC_DIR/scripts/migration.json \
    migration_response.json

echo "Initializing parameters..."
aws lambda invoke --function-name gxpvalidator-$STAGE-tool \
    --payload fileb://$CODEBUILD_SRC_DIR/scripts/init_params.json \
    init_param_response.json


echo "Clearing AWS PROFILE"
unset AWS_DEFAULT_REGION
unset AWS_ACCESS_KEY_ID
unset AWS_SECRET_ACCESS_KEY
unset AWS_SESSION_TOKEN

echo "Exporting deployment Result..."
cd $CODEBUILD_SRC_DIR
echo Copying aws-export-$STAGE.js to s3://$DEPLOYMENT_CONFIG_BUCKET/$STAGE/aws-export.js
aws s3 cp aws-export-$STAGE.js s3://$DEPLOYMENT_CONFIG_BUCKET/$STAGE/aws-export.js
