from typing import Optional

class ClientResponse:
    status_code: int
    msg: str
    json_body: Optional[dict] = None

    def __init__(self, status_code: int = 200, msg: str = None, json_body: str = None, ) -> None:
        self.status_code = status_code
        self.json_body = json_body
        self.msg = msg
