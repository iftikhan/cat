from src.qualifications.services.core import ReportBase


class LandingZoneReport(ReportBase):

    template_category = 'lz'
