import React, { useEffect, useState, useCallback } from 'react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router';

import {
  Row, Col,
  Button, Input,
  Card, CardHeader, CardBody, Badge,
} from 'reactstrap';

import { FaQuestionCircle, FaEdit } from 'react-icons/fa';

import API from 'helpers/api';
import LoadingModal from 'components/modals/Loading';
import { fetchLzAccountsRequest } from 'containers/infrastructure/actions';
import SearchTable from 'components/tables/SearchTable';
import CloudProviderSelect from 'components/molecules/controls/CloudProviderSelect';
import CloudServicesSelect from 'components/molecules/controls/CloudServicesSelect';
import CloudComplianceStandarSelect from 'components/molecules/controls/CloudComplianceStandarSelect';
import ManagedRuleModal from 'components/molecules/controls/ManagedRuleModal';

const GxPControlManagement = ({
  infras, fetchingInfras, fetchLzAccountsRequest,
}) => {
  const [managedRules, setManagedRules] = useState([]);
  const [filteredRules, setFilteredRules] = useState([]);
  const [selectedProvider, setSelectedProvider] = useState('');
  const [selectedCloudService, setSelectedCloudService] = useState('');
  const [selectedStandard, setSelectedStandard] = useState('');
  const [searchKeyword, setSearchKeyword] = useState('');

  const [showNewRuleModal, setShowNewRuleModal] = useState(false);

  const history = useHistory();

  const fetchManagedRules = useCallback((provider: String) => {
    return API.controls.getManagedRules(provider)
    .then(({managed_rules: rules, status}) => {
      if (status) {
        setManagedRules(rules);
      }
    }).catch(err => {
      console.error(err);
    })
  }, [setManagedRules]);

  useEffect(() => {
    fetchManagedRules(selectedProvider);
  }, [fetchManagedRules, selectedProvider]);

  const managedRuleColumns = [
    {
      dataField: 'id',
      text: 'ID',
      sort: true,
      // formatter: (cel, row, rowIndex) => {
      //   const { description, id } = row;
      //   return <span>
      //     <FaEdit className='text-info' title='Edit' onClick={() => {history.push(`/gxp-control/manage/${id}`)}} />
      //     &nbsp;&nbsp;{cel}&nbsp;&nbsp;
      //     <FaQuestionCircle
      //       title={description}
      //       className='ni ni-air-baloon text-info' id={`managed-rule-tooltip-handler-${id}`}
      //       />
      //   </span>
      // }
    }, {
      dataField: 'name',
      text: 'Managed Rule Name',
      sort: true,
      formatter: (cel, row, rowIndex) => {
        const { description, id } = row;
        return <span>
          <FaEdit className='text-info' title='Edit' onClick={() => {history.push(`/gxp-control/manage/${id}`)}} />
          &nbsp;&nbsp;{cel}&nbsp;&nbsp;
          <FaQuestionCircle
            title={description}
            className='ni ni-air-baloon text-info' id={`managed-rule-tooltip-handler-${id}`}
            />
        </span>
      }
    }, {
      dataField: 'provider',
      text: 'Provider',
      sort: true,
      formatter: (provider, row, rowIndex) => {
        return <Badge color="primary" pill>{provider}</Badge>
      }
    }, {
      dataField: 'standards',
      text: 'Standard',
      sort: true,
      formatter: (standards, row, rowIndex) => {
        return <>
          {standards.map((standard, idx) => (
            <Badge color="primary" key={idx} pill>{standard}</Badge>
          ))}
        </>
      }
    }, {
      dataField: 'services',
      text: 'Services',
      sort: true,
      formatter: (services, row, rowIndex) => {
        return <>
          {services.map((service, idx) => (
            <Badge color="primary" key={idx} pill>{service}</Badge>
          ))}
        </>
      }
    }, {
      dataField: 'tags',
      text: 'Tags',
      sort: true,
      formatter: (tags, row, rowIndex) => {
        return <>
          {tags.map((tag, idx) => (
            <Badge color="primary" key={idx} pill>{tag}</Badge>
          ))}
        </>
      }
    },
  ]

  const onCreateNewRule = (
    name: String, provider: String, services: Array<String>,
    standards: Array<String>, tags: Array<String>, description: String = ''
  ) => {
    API.controls.createManagedRule(name, provider, services, standards, tags, description)
    .then(({status}) => {
      if (status) {
        fetchManagedRules();
        setShowNewRuleModal(false);
      } else {
        alert('Failed to create the rule')
      }
    }).catch(err => {
      console.error(err);
      alert('Something went wrong!')
    })
  }

  useEffect(() => {
    setFilteredRules(managedRules.filter(({tags, provider, name, services, standards, description}) => {
      if (!!searchKeyword) {
        if (name.toLowerCase().indexOf(searchKeyword.toLowerCase()) < 0) {
          return false;
        }
      }

      if (!!selectedCloudService) {
        const filtered = services.filter((item) => item.toLowerCase() === selectedCloudService.toLowerCase())
        if (filtered.length === 0) {
          return false
        }
      }

      if (!!selectedStandard) {
        const filtered = standards.filter((item) => item.toLowerCase() === selectedStandard.toLowerCase())
        if (filtered.length === 0) {
          return false
        }
      }
      return true
    }))
  }, [
    selectedProvider, selectedCloudService, selectedStandard,
    setFilteredRules, managedRules, searchKeyword,
  ])

  return (
    <>
      <Card>
        <CardHeader>
          <Row className="align-items-center">
            <div className="col">
              <h3 className="mb-0">Controls</h3>
            </div>
            <div className="col text-right">
              <Button
                color="primary"
                href="#pablo"
                onClick={() => setShowNewRuleModal(true)}
                size="sm"
              >
                Add new
              </Button>
            </div>
          </Row>
        </CardHeader>
        <CardBody>
          <Row className='mb-3'>
            <Col lg={3} sm={6}>
              <Input
                className="form-control-sm"
                placeholder="Type keyword.."
                value={searchKeyword}
                onChange={(event) => setSearchKeyword(event.target.value)}
              />
            </Col>
            <Col lg={2} sm={6}>
              <CloudProviderSelect value={selectedProvider} onChange={setSelectedProvider} />
            </Col>
            <Col lg={2} sm={6}>
              <CloudServicesSelect
                provider={selectedProvider} value={selectedCloudService}
                onChange={setSelectedCloudService} />
            </Col>
            <Col lg={3} sm={6}>
              <CloudComplianceStandarSelect
                value={selectedStandard} onChange={setSelectedStandard} />
            </Col>
          </Row>
          <SearchTable
            columns={managedRuleColumns} keyField='id'
            enableSearch={false}
            data={filteredRules.map((rule, idx) => ({
              ...rule,
            }))}
            entryNamePlural='rules'
            noDataIndication={'No managed rule'}
            />
        </CardBody>
      </Card>
      <LoadingModal show={false} />
      <ManagedRuleModal
        onSubmit={onCreateNewRule}
        isOpen={showNewRuleModal} toggle={() => setShowNewRuleModal(false)} />
    </>
  )
}

const mapStateToProps = (state) => ({
});

const mapDispatchToProps = (dispatch) => ({
  fetchLzAccountsRequest: () => dispatch(fetchLzAccountsRequest()),
})

export default connect(mapStateToProps, mapDispatchToProps)(GxPControlManagement);
