# AutoGxP

## Technical stacks
- language: `python3.7`
- framework: `serverless`
- CI/CD: AWS `CodeCommit`, `Pipeline`, `CodeDeploy`
- Architecture: `serverless`, `microservice`, `lambda`

## Install dependencies

### Prepare aws cli and credentials
Please be sure that you installed aws cli v2 by using the file downloaded from [this page](https://awscli.amazonaws.com/AWSCLIV2.msi). Please note that this is Windows installer. Please verify that you've installed the aws cli by executing `aws --version`

Open `~/.aws/credentials`(Linux & Mac) or `%USERPROFILE%\.aws\credentials` (Windows) and add the followings. If the file doesn't exist yet, you can create it.
```
[gxp-deploy]
aws_access_key_id=<API_KEY>
aws_secret_access_key=<SECRET_KEY>
region=us-east-1
```

In order to use aws codecommit repositogies, you should install `git-remote-codecommit` with the following command.
```
pip install git-remote-codecommit
```
Now you are ready to clone the repository from aws codecommit. Please don't forget to set the system environment for aws credentials. You gave `gxp-deploy` as the profile name of aws credentials.

```
set AWS_PROFILE=gxp-deploy  #(use `export` isntead of `set` if your os is unix.)
git clone codecommit::us-east-1://gxp-backend
```

Now you cloned the repository and ready to install depdendencies.

### Python dependencies
This project was built under `pipenv` so you need to install. If you have `pip` installed on your loca
```
pip install --user pipenv
```
Once it's installed, you can activate the `pipenv` inside the root directory where you see `Pipfile`. Follow the instructions to install all the dependencies required.
```sh
pipenv shell
pipenv install --dev
```

### Serverless framework dependencies
[This page](https://www.serverless.com/framework/docs/getting-started) gives you the more details on how to use the `serverless` framework.

Install serverless in global space
```
npm install -g serverless
npm install --global yarn
```
Also this project uses several additional plugins and I recommend `yarn` to install the dependencies.
```
yarn install
```
Now you installed all the dependencies required to launch the app on your local machine. Please be aware of that `docker` is required to launch the project on local.


### Additional prerequests
- Install postgresql on your local machine and create a database `gxp`.

## Development on local
### Prepare the environment variables
You need to create `.env.dev` file from the `.env.dev.example`. Simply run the following command and adjust the content (note that you give the correct name of database created in your local postgresql instance).
```
cp .env.dev.example .env.dev
```

### Launch dev server
```
sls --offline
```