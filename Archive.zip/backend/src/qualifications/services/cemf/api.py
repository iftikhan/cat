import json
from typing import Dict, List, Optional, Tuple
import requests

# from src.config import settings
from src.utils.logger import Logger
from src.utils.exceptions import InvalidCmefTokenException


class CemfCPU:
    cores: int
    model_name: str

    def __init__(self, cores: int, model_name: str) -> None:
        self.cores = cores
        self.model_name = model_name

    def __repr__(self) -> str:
        return f'<CPU({self.cores}): {self.model_name}>'

    def __str__(self) -> str:
        return self.model_name

    def to_dict(self) -> dict:
        return {
            'cores': self.cores,
            'modelName': self.model_name,
        }


class CemfDisk:
    name: str
    size: int
    is_protected: bool

    def __init__(self, name: str, size: str, is_protected: bool) -> None:
        self.name = name
        self.size = size
        self.is_protected = is_protected

    @property
    def sizegib(self) -> str:
        return str(self.size / 1073741824) + " GiB"

    def __repr__(self) -> str:
        return f'<CemfDisk({self.name}): {self.sizegib}>'

    def __str__(self) -> str:
        return f'{self.name}: {self.sizegib}'

class CemfServer:
    server_name: str
    server_id: str
    server_os: str
    memory: int
    public_ips: List[str]

    disks: Tuple[CemfDisk]
    cpus: Tuple[CemfCPU]

    def __init__(
        self, server_id: str, server_name: str, server_os: str, memory: int,
        public_ips: List[str], cpus: List[Dict], disks: List[Dict]
    ) -> None:
        self.server_id = server_id
        self.server_name = server_name
        self.server_os = server_os
        self.memory = memory
        self.public_ips = public_ips

        self.cpus = tuple([CemfCPU(item['cores'], item['modelName']) for item in cpus])
        self.disks = tuple(
            sorted(
                [CemfDisk(
                    item['name'], item['size'], item['isProtected']
                ) for item in disks],
                key=lambda disk: disk.size
            ))

    def __repr__(self) -> str:
        return f'<CemfServer({self.server_id}): {self.server_name}>'

    def __str__(self) -> str:
        return self.server_name


class CemfProject:
    project_id: str
    project_name: str

    __servers: List[CemfServer]

    def __init__(self, project_id: str, project_name: str) -> None:
        self.project_id = project_id
        self.project_name = project_name

        self.__servers = []

    def __repr__(self) -> str:
        return f'<CemfProject({self.project_id}): {self.project_name}>'

    def __str__(self) -> str:
        return self.project_name

    @property
    def servers(self) -> Tuple[CemfServer]:
        return tuple(self.__servers)

    def add_server(self, server: CemfServer):
        self.__servers.append(server)


class CemfAPI(object):
    __host = 'https://console.cloudendure.com'
    __endpoint = '/api/latest/{}'
    __headers = {'Content-Type': 'application/json'}
    __session = {}
    __auth_response: Optional[requests.models.Response] = None

    def __init__(self, token: str) -> None:
        self.__token = token

        self.__logger = Logger()

    def authenticate(self) -> requests.models.Response:
        login_data = {"userApiToken": self.__token}
        self.__logger.log_info('Authenticating CMEF API with token...')
        self.__auth_response = requests.post(
            self.__host + self.__endpoint.format('login'),
            data=json.dumps(login_data), headers=self.__headers)
        if self.__auth_response.status_code != 200 and self.__auth_response.status_code != 307:
            raise InvalidCmefTokenException("ERROR: Invalid Login Credentials. Please check CMEF API TOKEN")
        else:
            self.__logger.log_info('Successfully authenticated.')
            self.__headers['X-XSRF-TOKEN'] = self.auth_response.cookies['XSRF-TOKEN']
            self.__session = {'session': self.auth_response.cookies['session']}

    @property
    def auth_response(self) -> requests.models.Response:
        if not isinstance(self.__auth_response, requests.models.Response):
            self.__auth_response = self.authenticate()

        return self.__auth_response

    def get_projects(self) -> List[CemfProject]:
        self.__logger.log_info('Retrieving projects via CMEF API...')
        response = requests.get(
            self.__host + self.__endpoint.format('projects'),
            headers=self.__headers, cookies=self.__session)
        if response.status_code != 200:
            raise Exception('CMEF API Failed to fetch projects.')
        else:
            self.__logger.log_info('Successfully retrieved projects via CMEF!')

        projects = response.json()['items']

        return [CemfProject(item['id'], item['name']) for item in projects]

    def get_machines(self, projects: List[CemfProject]) -> List[CemfProject]:
        for project in projects:
            self.__logger.log_info(f'Fetching machine info for project {project.project_id}...')
            response = requests.get(
                self.__host + self.__endpoint.format('projects/{}/machines').format(project.project_id),
                headers=self.__headers, cookies=self.__session)

            if response.status_code != 200:
                self.__logger.log_exception(Exception(f"Failed to fetch the machines for {project.project_id}!"))
                continue
            else:
                self.__logger.log_info(f'Successfully fetched machines for {project.project_id}!')

            for machine in response.json()['items']:
                source_properties = machine.get('sourceProperties', {})
                project.add_server(CemfServer(
                    server_id=machine['id'],
                    server_name=source_properties.get('name'),
                    server_os=source_properties.get('os'),
                    memory=source_properties.get('memory'),
                    public_ips=source_properties.get('publicIps', []),
                    cpus=source_properties.get('cpu', []),
                    disks=source_properties.get('disks', [])
                ))

        return projects

    def get_projects_with_machines(self, project_names: List[str] = []) -> List[CemfProject]:
        self.authenticate()
        projects = self.get_projects()

        if project_names:  # and not settings.IS_LOCAL:
            projects = [project for project in projects if project.project_name in project_names]

        return self.get_machines(projects)
