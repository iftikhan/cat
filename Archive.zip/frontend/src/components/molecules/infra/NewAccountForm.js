import React, { useState } from 'react';
import PropTypes from 'prop-types'

import {
  FormGroup, Col, Row, Button, Input,
  Card, CardHeader, CardBody,
} from 'reactstrap'

const NewAccountForm = ({
  onSubmit, disabled,
}) => {
  const [orgUnit, setOrgUnit] = useState('');
  const [roleName, setRoleName] = useState('');
  const [accountName, setAccountName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');

  const isValid = () => {
    return (
      orgUnit.trim().length > 0 &&
      roleName.trim().length > 0 &&
      accountName.trim().length > 0 &&
      accountNumber.trim().length === 12
    )
  }

  const onClickSave = () => {
    onSubmit(orgUnit, accountNumber, accountName, roleName).then(() => {
      setRoleName('');
      setOrgUnit('');
      setAccountName('');
      setAccountNumber('');
    })
  }

  return (
    <Card>
      <CardHeader>Add New Account</CardHeader>
      <CardBody>
        <FormGroup className="mb-3" disabled={disabled}>
          <Row>
            <Col sm={3} xs={6}>
              <label className='mt-2'>Organization Unit</label>
            </Col>
            <Col sm="3" xs={6}>
              <Input
                type='text'
                value={orgUnit}
                onChange={e => setOrgUnit(e.target.value)} />
            </Col>
            <Col sm="3" xs={6}>
              <label className='mt-2'>Role Name</label>
            </Col>
            <Col sm="3" xs={6}>
              <Input
                type='text'
                value={roleName}
                onChange={e => setRoleName(e.target.value)} />
            </Col>
          </Row>
        </FormGroup>
        <FormGroup className="mb-3" disabled={disabled}>
          <Row>
            <Col sm="3" xs={6}>
              <label className='mt-2'>Account Name</label>
            </Col>
            <Col sm="3" xs={6}>
              <Input
                type='text'
                value={accountName}
                onChange={e => setAccountName(e.target.value)} />
            </Col>
            <Col sm="3" xs={6}>
              <label className='mt-2'>Account Number</label>
            </Col>
            <Col sm="3" xs={6}>
              <Input
                type='text'
                value={accountNumber}
                onChange={e => setAccountNumber(e.target.value)} />
            </Col>
          </Row>
        </FormGroup>
        <FormGroup>
          <Row>
            <Col>
              <Button
                className='float-right' disabled={!isValid()}
                onClick={onClickSave} color='primary'
                >Save changes</Button>
            </Col>
          </Row>
        </FormGroup>
      </CardBody>
    </Card>
  )
}

NewAccountForm.propTypes = {
  onSubmit: PropTypes.func.isRequired,
  disabled: PropTypes.bool,
}

NewAccountForm.defaultProps = {
  disabled: false,
}

export default NewAccountForm;
