import re
import json

from src.config import settings
from src.utils.constants import InfraResourceStatus
from src.utils.response import build_response
from src.utils.auth import get_authenticated_user
from src.utils.aws import LambdaFunction
from src.utils.exceptions import IncorrectCrossAccountRoleException
from src.utils.aws.sts import STS
from src.models.infra.infra_model import InfraModel


def manage_infra(event, context):
    model = InfraModel()
    user_id = get_authenticated_user(event)
    http_method = event['requestContext']['httpMethod']
    # query_params = event.get('queryStringParameters') or {}
    http_path = event['path']
    path_params = event.get('pathParameters') or {}

    if http_path == '/infra/lz':
        if http_method == 'GET':
            landing_zones = model.list_landing_zones()
            return build_response({
                'landing_zones': [item.to_dict() for item in landing_zones]
            })
        elif http_method == 'POST':
            params = json.loads(event['body'] or '{}')
            name = params.pop('name', None)

            if not name:
                return build_response({
                    'status': False,
                    'msg': 'name is required.'
                }, 400)

            status = model.create_landing_zone(name)
            return build_response({
                'status': status,
            })

    elif 'landing_zone_id' in path_params:
        landing_zone_id = path_params['landing_zone_id']
        if re.search(rf'^\/infra\/lz\/{landing_zone_id}$', http_path):
            if http_method == 'GET':
                pass
            elif http_method == 'PUT':
                params = json.loads(event['body'] or '{}')
                name = params.pop('name', None)

                if not name:
                    return build_response({
                        'status': False,
                        'msg': 'name is required.'
                    }, 400)

                status = model.update_landing_zone(landing_zone_id, name)
                return build_response({
                    'status': status,
                })

        elif re.search(rf'^\/infra\/lz\/{landing_zone_id}/accounts$', http_path):
            if http_method == 'GET':
                # created_by = query_params.get('created_by')
                items = model.list_lz_accounts(landing_zone_id)
                return build_response({
                    'status': True,
                    'accounts': [item.to_dict() for item in items],
                })
            elif http_method == 'POST':
                params = json.loads(event['body'] or '{}')
                permitted_attrs = [
                    'name', 'account_id', 'organization_unit', 'cross_account_role_name']
                refined_params = {}

                for attr in permitted_attrs:
                    if attr not in params or not params.get(attr):
                        return build_response({
                            'msg': f'{attr} is required',
                        }, 400)
                    else:
                        refined_params.update({attr: params[attr]})

                account_id = refined_params['account_id']
                cross_account_role_name = refined_params['cross_account_role_name']

                sts = STS()
                try:
                    sts.get_assume_role_client(account_id, cross_account_role_name, 'iam')
                except IncorrectCrossAccountRoleException:
                    return build_response({
                        'status': False,
                        'msg': 'Incorrect assume'
                    }, status_code=400)

                refined_params['created_by'] = user_id
                status = model.create_lz_account(landing_zone_id, **refined_params)
                return build_response({
                    'status': status
                }, status_code=201 if status else 400)

        elif 'account_id' in path_params:
            account_id = path_params['account_id']
            if re.search(rf'^\/infra\/lz\/{landing_zone_id}/accounts/{account_id}$', http_path):
                if http_method == 'GET':
                    instance = model.retrieve_lz_account(landing_zone_id, account_id)

                    if instance is None:
                        return build_response({}, 404)

                    return build_response({
                        'account': instance.to_response(),
                    })
                elif http_method == 'PUT':
                    params = json.loads(event['body'] or '{}')
                    instance = model.update_lz_account(account_id, **params)

                    if instance is None:
                        return build_response({}, 404)

                    return build_response({
                        'status': instance,
                    })
            elif re.search(rf'^\/infra\/lz\/{landing_zone_id}/accounts/{account_id}/resources$', http_path):
                if http_method == 'POST':
                    params = json.loads(event['body'] or '{}')
                    refined_params = {}
                    required_params = ['name', 'resource_type', 'properties']
                    for param in required_params:
                        if param not in params:
                            return build_response({
                                'status': False,
                                'msg': f'{param} is required.'
                            }, 400)

                        refined_params[param] = params[param]

                    resource_id = model.create_resource(
                        account_id, created_by=user_id, **refined_params)
                    LambdaFunction.invoke_lambda(settings.EXECUTE_TOOL_FUNCTION_NAME, {
                        'tool': 'infra', 'action': 'create_resource',
                        'params': {
                            'landing_zone_id': landing_zone_id,
                            'account_id': account_id, 'resource_id': resource_id
                        }
                    })
                    return build_response({
                        'status': resource_id > 0,
                        'resource_id': resource_id,
                    })
            elif re.search(rf'^\/infra\/lz\/{landing_zone_id}/accounts/{account_id}/resources/status$', http_path):
                params = json.loads(event['body'] or '{}')
                if not params.get('resource_ids'):
                    return build_response({
                        'msg': 'resource_ids is required.'
                    })
                return build_response({
                    'resource_status': model.get_status(params['resource_ids'])
                })
            elif 'resource_id' in path_params:
                resource_id = path_params['resource_id']
                if http_method == 'GET':
                    resource = model.retrieve_resource(resource_id)
                    if resource:
                        return build_response({
                            'status': True,
                            'resource': resource.to_dict(),
                        })
                    else:
                        return build_response({
                            'status': False,
                        }, status_code=404)
                elif http_method == 'PUT':
                    params = json.loads(event['body'] or '{}')
                    refined_params = {}
                    required_params = ['name', 'properties']
                    permitted_attrs = required_params + ['description']
                    for param in permitted_attrs:
                        if param not in params:
                            if param in required_params:
                                return build_response({
                                    'status': False,
                                    'msg': f'{param} is required.'
                                }, 400)
                            else:
                                continue

                        refined_params[param] = params[param]

                    status = model.update_resource(resource_id, **refined_params)

                    if 'properties' in refined_params:
                        LambdaFunction.invoke_lambda(settings.EXECUTE_TOOL_FUNCTION_NAME, {
                            'tool': 'infra', 'action': 'update_resource',
                            'params': {
                                'landing_zone_id': landing_zone_id,
                                'account_id': account_id, 'resource_id': resource_id
                            }
                        })

                    return build_response({
                        'status': True,
                    }, status_code=200 if status else 400)
                elif http_method == 'DELETE':
                    resource = model.retrieve_resource(resource_id)

                    if resource.status in [InfraResourceStatus.provisioning, InfraResourceStatus.deleting]:
                        return build_response({
                            'status': False,
                            'msg': f'resource can not be deleted in {resource.status} status'
                        }, 400)

                    LambdaFunction.invoke_lambda(settings.EXECUTE_TOOL_FUNCTION_NAME, {
                        'tool': 'infra', 'action': 'delete_resource',
                        'params': {
                            'landing_zone_id': landing_zone_id,
                            'account_id': account_id, 'resource_id': resource_id
                        }
                    })
                    return build_response({
                        'status': True,
                    })

    return build_response({
        'status': False,
    }, 400)


__all__ = ('manage_infra', )
