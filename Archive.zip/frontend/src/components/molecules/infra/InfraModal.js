import React, { useState } from 'react';
import PropTypes from 'prop-types';

import {
  Modal, ModalHeader, ModalBody, ModalFooter,
  Button, FormGroup, Input,
} from 'reactstrap';

const InfraModal = ({
  show, handleClose, handleSubmit, defaultData,
}) => {
  const [formData, setFormData] = useState({
    name: '',
    accountId: '',
    roleName: '',
    description: '',
    ...defaultData,
  });

  const onChange = (key, value) => {
    setFormData({
      ...formData,
      [key]: value,
    })
  }

  const isValid = () => {
    const {
      name, roleName, accountId
    } = formData
    return (
      name.trim().length > 0 && roleName.trim().length > 0 &&
      accountId.trim().length === 12
    )
  }

  const onSubmit = () => {
    const {
      id, name, accountId, roleName, description,
    } = formData;

    handleSubmit({id, name, roleName, accountId, description})
  }

  return (
    <Modal show={show} onHide={handleClose}>
      <ModalHeader closeButton>
        <Modal.Title>New Infrastructure</Modal.Title>
      </ModalHeader>
      <ModalBody>
        <FormGroup>
          <label>Name</label>
          <Input
            type="text" placeholder="Name"
            onChange={(event) => {onChange('name', event.target.value)}}
            value={formData.name || ''}
            />
        </FormGroup>
        <FormGroup>
          <label>Account ID</label>
          <Input
            type="text" placeholder="Account ID"
            onChange={(event) => {onChange('accountId', event.target.value)}}
            value={formData.accountId || ''}
            />
        </FormGroup>
        <FormGroup>
          <label>Assumed Role Name</label>
          <Input
            type="text" placeholder="Cross Account Role"
            onChange={(event) => {onChange('roleName', event.target.value)}}
            value={formData.roleName || ''}
            />
        </FormGroup>
        <FormGroup>
          <label>Description</label>
          <Input
            type="text" placeholder="Description"
            onChange={(event) => {onChange('description', event.target.value)}}
            value={formData.description || ''}
            />
        </FormGroup>
      </ModalBody>
      <ModalFooter>
        <Button color="secondary" onClick={handleClose}>
          Close
        </Button>
        <Button color="primary" disabled={!isValid()} onClick={onSubmit}>
          Save Changes
        </Button>
      </ModalFooter>
    </Modal>
  )
}

InfraModal.propTypes = {
  show: PropTypes.bool.isRequired,
  handleClose: PropTypes.func,
  handleSubmit: PropTypes.func.isRequired,
  defaultData: PropTypes.shape({
    name: PropTypes.string,
    accountId: PropTypes.string,
    roleName: PropTypes.string,
    description: PropTypes.string,
    id: PropTypes.number,
  })
}

InfraModal.defaultProps = {
  defaultData: {
    name: '',
    accountId: '',
    roleName: '',
    description: '',
    id: null,
  }
}

InfraModal.defaultProps = {
  handleClose: () => {},
  userData: {},
}

export default InfraModal;
