from src.utils.constants import InfraResourceType

from .s3 import S3CloudFormation, CloudFormationBase


def get_cf_class(resource_type: InfraResourceType) -> CloudFormationBase.__class__:
    mappings = {
        InfraResourceType.s3: S3CloudFormation
    }

    return mappings[resource_type]
