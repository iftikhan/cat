// import createAction from 'redux/helpers/createAction';

export const namespace = 'control';
