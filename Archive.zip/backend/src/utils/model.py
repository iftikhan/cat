from typing import Optional
from sqlalchemy.engine.base import Connection

from src.utils.pgsql import PgsqlManager


class ModelBase(object):
    __db_manager: PgsqlManager = None
    __connection: Connection = None

    def __init__(self, db_manager: Optional[PgsqlManager] = None) -> None:
        if isinstance(db_manager, PgsqlManager):
            self.__db_manager = db_manager
        else:
            self.__db_manager = PgsqlManager()

        super().__init__()

    @property
    def connection(self) -> Connection:
        if not isinstance(self.__connection, Connection):
            self.__connection = self.__db_manager.get_db_connection()

        return self.__connection

    @property
    def db_manager(self) -> PgsqlManager:
        return self.__db_manager
