from typing import Any, Dict, List, Tuple


class ServerSetting:
    variable: str
    value: Any

    def __init__(self, variable: str, value: Any) -> None:
        self.variable = variable
        self.value = value

    def __repr__(self) -> str:
        return f'<ServerSetting({self.variable}): {self.value}>'

    def __str__(self) -> str:
        return f'{self.variable}: {self.value}'

    def to_dict(self) -> dict:
        return {
            'ExpectedVariable': self.variable,
            'ExpectedValue': self.value,
        }


class Server:
    name: str
    os: str
    fqdn: str
    environment: str

    settings: List[ServerSetting]

    def __init__(self, name: str, os: str, fqdn: str, environment: str) -> None:
        self.name = name
        self.os = os
        self.fqdn = fqdn
        self.environment = environment

        self.settings = []

    def __repr__(self) -> str:
        return f'<Server({self.name}): {self.os}({self.environment})>'

    def __str__(self) -> str:
        return f'{self.name}({self.environment}): {self.os}'

    def add_setting(self, variable: str, value: Any):
        self.settings.append(ServerSetting(variable, value))

    def to_dict(self) -> dict:
        return {
            'server_name': self.name,
            'server_os': self.os,
            'server_fqdn': self.fqdn,
            'server_environment': self.environment,
            'settings': [setting.to_dict() for setting in self.settings]
        }


class Project:
    name: str

    __servers: Dict[str, Server]

    def __init__(self, name: str) -> None:
        self.name = name
        self.__servers = {}

    @property
    def servers(self) -> Tuple[Server]:
        return tuple(self.__servers.values())

    def __repr__(self) -> str:
        return f'<Project: {self.name}>'

    def __str__(self) -> str:
        return self.name

    def add_server(
        self, server_name: str, server_os: str, server_fqdn: str,
        server_environment: str, variable: str, value: Any
    ):
        if server_name not in self.__servers:
            self.__servers[server_name] = Server(server_name, server_os, server_fqdn, server_environment)

        self.__servers[server_name].add_setting(variable, value)

    def to_dict(self) -> dict:
        return {
            'project_name': self.name,
            'servers': [server.to_dict() for server in self.servers]
        }


class Application:
    name: str

    __projects: Dict[str, Project]

    def __init__(self, name: str) -> None:
        self.name = name
        self.__projects = {}

    @property
    def projects(self) -> Tuple[Project]:
        return tuple(self.__projects.values())

    def __repr__(self) -> str:
        return f'<Application: {self.name}>'

    def __str__(self) -> str:
        return self.name

    def add_project(
        self, project_name: str, server_name: str,
        server_os: str, server_fqdn: str, server_environment: str,
        variable: str, value: Any
    ):
        if project_name not in self.__projects:
            self.__projects[project_name] = Project(project_name)

        self.__projects[project_name].add_server(
            server_name, server_os, server_fqdn, server_environment,
            variable, value)

    def to_dict(self) -> dict:
        return {
            'app_name': self.name,
            'projects': [project.to_dict() for project in self.projects]
        }


class Wave:
    wave_id: str
    __applications: Dict[str, Application]

    def __init__(self, wave_id: str) -> None:
        self.wave_id = wave_id
        self.__applications = {}

    @property
    def applications(self) -> Tuple[Application]:
        return tuple(self.__applications.values())

    def __str__(self) -> str:
        return self.wave_id

    def __repr__(self) -> str:
        return f'<Wave: {self.wave_id}>'

    def add_application(
        self, application_name: str, project_name: str, server_name: str,
        server_os: str, server_fqdn: str, server_environment: str,
        variable: str, value: Any
    ):
        if application_name not in self.__applications:
            self.__applications[application_name] = Application(application_name)

        self.__applications[application_name].add_project(
            project_name, server_name, server_os, server_fqdn, server_environment, variable, value)

    def to_dict(self) -> dict:
        return {
            'wave_id': self.wave_id,
            'applications': [app.to_dict() for app in self.applications]
        }


class AwsAccountEntry:
    account_id: str
    assume_role_name: str

    __waves: Dict[str, Wave]

    def __init__(self, account_id: str, assume_role_name: str) -> None:
        self.account_id = account_id
        self.assume_role_name = assume_role_name
        self.__waves = {}

    @property
    def waves(self) -> Tuple[Wave]:
        return tuple(self.__waves.values())

    def __repr__(self) -> str:
        return f'<Account: {self.account_id}>'

    def __str__(self) -> str:
        return self.account_id

    def add_parameters(
        self, wave_id: str, application_name: str, project_name: str,
        server_name: str, server_os: str, server_fqdn: str,
        server_environment: str, variable: str, value: Any,
    ):
        if wave_id not in self.__waves:
            self.__waves[wave_id] = Wave(wave_id)

        self.__waves[wave_id].add_application(
            application_name, project_name, server_name,
            server_os, server_fqdn, server_environment,
            variable, value)

    def to_dict(self) -> dict:
        return {
            'account_id': self.account_id,
            'assume_role_name': self.assume_role_name,
            'waves': [wave.to_dict() for wave in self.waves]
        }
