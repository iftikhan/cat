import React, { useState } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';

import {
  Row, Col, Button,
} from 'reactstrap';
import BootstrapTable from 'react-bootstrap-table-next';

import AccountModal from 'components/modals/Account';

const AccountsTable = ({
  accounts, isLoading, onNewAccount, onUpdateAccount,
}) => {
  const [showNewModal, setShowNewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [curAccount, setCurAccount] = useState(null);

  const onClickEdit = (row) => {
    const {
      id, account_name: accountName, account_id: accountId,
    } = row;

    setCurAccount({id, accountName, accountId});
    setShowEditModal(true)
  }

  const columns = [
    {
      dataField: 'account_name',
      text: 'Account Name',
      headerStyle: { width: '180px', textAlign: 'center' },
      style: { textAlign: 'left' },
    }, {
      dataField: 'account_id',
      text: 'Account ID',
    }, {
      dataField: 'action',
      text: '',
      style: {
        textAlign: 'center',
        display: 'flex',
        justifyContent: 'space-evenly',
      },
      headerStyle: { width: '180px' },
      formatter: (cel, row, rowIndex) => {
        return (<>
          <Button
            title='Edit Account'
            className={classnames('btn-sm btn-primary')}
            onClick={() => onClickEdit(row)}>Edit</Button>
        </>)
      },
    },
  ]


  return (
    <>
      <br />
      <Row>
        <Col><h2>Accounts</h2></Col>
        <Col>
          <Button className='btn-sm float-right' onClick={() => setShowNewModal(true)}>create new</Button>
        </Col>
      </Row>
      <BootstrapTable
        keyField='id' data={ accounts } columns={ columns }
        noDataIndication={isLoading ? 'Loading...' : 'No job yet.'}
      />
      <AccountModal
        show={showNewModal}
        handleClose={() => setShowNewModal(!showNewModal)}
        handleSubmit={onNewAccount}
        />
      {curAccount && <AccountModal
        show={showEditModal}
        accountData={curAccount}
        handleClose={() => setShowEditModal(!showEditModal)}
        handleSubmit={onUpdateAccount(curAccount.id)}
        />}
    </>
  )
}

AccountsTable.propTypes = {
  isLoading: PropTypes.bool.isRequired,
  accounts: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.string.isRequired,
    account_name: PropTypes.string.isRequired,
    account_id: PropTypes.string.isRequired,
  })).isRequired,
  credentials: PropTypes.shape({
  }),
  onNewAccount: PropTypes.func.isRequired,
  onUpdateAccount: PropTypes.func.isRequired,
}

AccountsTable.defaultProps = {
  credentials: {},
}

export default AccountsTable;
