import createReducer from 'redux/helpers/createReducer';

import {
  namespace,
  fetchAccountsRequest, fetchAccountsSuccess, fetchAccountsFailure,
  fetchUsersRequest, fetchUsersSuccess, fetchUsersFailure,
} from './actions';

const defaultState = {
  fetchingAccounts: false,
  accounts: [],
  fetchingUsers: false,
  users: [],
}

const reducer = createReducer(namespace, defaultState, {
  [fetchAccountsRequest.Type]: (state, action) => ({
    ...state,
    fetchingAccounts: true,
  }),
  [fetchAccountsSuccess.Type]: (state, { payload }) => ({
    ...state,
    fetchingAccounts: false,
    accounts: payload.accounts,
  }),
  [fetchAccountsFailure.Type]: (state, action) => ({
    ...state,
    fetchingAccounts: false,
  }),
  [fetchUsersRequest.Type]: (state, action) => ({
    ...state,
    fetchingUsers: true,
  }),
  [fetchUsersSuccess.Type]: (state, { payload }) => ({
    ...state,
    fetchingUsers: false,
    users: payload.users,
  }),
  [fetchUsersFailure.Type]: (state, action) => ({
    ...state,
    fetchingUsers: false,
  }),
});

export default reducer;
export { namespace };
