import React from 'react';
import PropTypes from 'prop-types';

import { Col } from 'reactstrap';

import ValidationConfigurationRow from './ValidationConfigurationRow';


const ValidationConfiguration = ({
  title, data,
}) => {
  const {
    project, qualificationType, runMethod, id, status, endedAt, createdBy,
  } = data;

  return (
    <Col>
      <h4>{title}</h4>
      <ul>
        <ValidationConfigurationRow key='project' title='Project'
          value={project} />
        <ValidationConfigurationRow key='qualificationType' title='Qualification Type'
          value={qualificationType} />
          <ValidationConfigurationRow key='runNumber' title='Run Number'
            value={id} />
        <ValidationConfigurationRow key='runMethod' title='Run Method'
          value={runMethod} />
        <ValidationConfigurationRow key='createdBy' title='Created By'
          value={createdBy} />
        <ValidationConfigurationRow key='jobStatus' title='Job Status'
          value={status === 'Run Successful' ? `Successfully completed on ${endedAt}` : status} />
      </ul>
    </Col>
  )
}

ValidationConfiguration.propTypes = {
  title: PropTypes.string.isRequired,
  data: PropTypes.shape({
    project: PropTypes.any.isRequired,
    qualificationType: PropTypes.string.isRequired,
    runMethod: PropTypes.string.isRequired,
    id: PropTypes.number.isRequired,
    status: PropTypes.string.isRequired,
    endedAt: PropTypes.string.isRequired,
    createdBy: PropTypes.string.isRequired,
  })
}

export default ValidationConfiguration;
