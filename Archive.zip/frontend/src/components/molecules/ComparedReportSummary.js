import React, { useEffect, useState } from 'react';
import { useParams, useHistory, Link } from 'react-router-dom';
import { FaThumbsUp, FaThumbsDown } from "react-icons/fa";

import PropTypes from 'prop-types';
import classnames from "classnames";
import {
  Button, Row, Col, Dropdown, DropdownButton, ButtonGroup,
} from 'reactstrap';
import { FaCheckCircle } from 'react-icons/fa';
import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';
import cellEditFactory from 'react-bootstrap-table2-editor';

import API from 'helpers/api';

import SubTitle from 'components/common/SubTitle';
import ValidationConfiguration from './reports/ValidationConfiguration'

const ComparedReportSummary = ({
  loadSummary, job, summaries, isLoading,
  onDownload,
}) => {
  const history = useHistory();
  const params = useParams();
  const { jobId } = params;

  const [isDownloading, setIsDownloading] = useState(false);

  const { project, study, version, dataset, status, ended_at: endedAt, created_by: author } = job || {};

  const productsWithButton = summaries.map(item => ({
    ...item,
    action: <><Button className={'btn-sm'}><FaCheckCircle /></Button></>
  }))

  useEffect(() => {
    loadSummary(jobId);
  }, [jobId, loadSummary])

  const columns = [{
    dataField: 'rule_id',
    text: 'Rule ID',
    filter: textFilter(),
    headerStyle: {width: '80px'},
    editable: false,
    formatter: (cel, row, rowIndex) => {
      return (
        <Link to={`/gxp-qualification/jobs/${jobId}/details/${cel}`}>{cel}</Link>
      )
    },
  }, {
    dataField: 'publisher_id',
    text: 'Publisher ID',
    filter: textFilter(),
    headerStyle: {width: '120px'},
    editable: false,
  }, {
    dataField: 'message',
    text: 'Message',
    filter: textFilter(),
    editable: false,
  }, {
    dataField: 'severity',
    text: 'Severity',
    filter: textFilter(),
    headerStyle: {width: '120px'},
    editable: false,
  }, {
    dataField: 'found',
    text: 'Found',
    filter: textFilter(),
    headerStyle: {width: '120px'},
    editable: false,
  }, {
    dataField: 'difference',
    text: 'Comparison',
    filter: textFilter(),
    headerStyle: {width: '240px'},
    formatter: (cel, row, rowIndex) => {
      const difference = parseInt(cel),
            found = parseInt(row.found);
      if (difference > 0) {
        return (
          <><FaThumbsDown color='red' /> Findings Increased (Previous = {found - difference})</>
        )
      } else if (cel < 0) {
        return (
          <><FaThumbsUp color='green' /> Findings Decreased (Previous = {found - difference})</>
        )
      } else {
        return <>No Change</>
      }
    }
  }, {
    dataField: 'comment',
    text: 'Comment',
    filter: textFilter(),
    headerStyle: {width: '240px'},
    editable: (cell, row, rowIndex, colIndex) => {
      return true; //row.found > 0
    },
  },
  ];

  const afterSaveCell = (oldValue, newValue, row, column) => {
    if (column.dataField === 'comment') {
      API.saveComment(row.job_id, row.id, newValue).then(() => {}).catch(err => console.error(err));
    }
  }

  const summaryColumns = [
    {
      dataField: 'total',
      text: 'Total Checks'
    }, {
      dataField: 'reject',
      text: 'Total Rejects'
    }, {
      dataField: 'error',
      text: 'Total Errors'
    }, {
      dataField: 'warning',
      text: 'Total Warnings'
    }, {
      dataField: 'score',
      text: 'Compliance Score'
    },
  ]

  const onClickDownload = (mode: String) => {
    setIsDownloading(true)
    onDownload(jobId, mode, () => setIsDownloading(false)).then(() => {
      setIsDownloading(false);
    }).catch(err => {
      setIsDownloading(false);
      alert('Failed to create report.')
    });
  }

  const rowClasses = (row, rowIndex) => {
    return `${row.found > 0 ? `${row.severity}-failed` : 'passed'}`;
  };

  const summaryRows = [{
    total: summaries.reduce((a, b) => a + 1, 0),
    reject: summaries.filter(item => item.severity === 'Reject' && parseInt(item.found) > 0).reduce((a, b) => a + 1, 0),
    error: summaries.filter(item => item.severity === 'Error' && parseInt(item.found) > 0).reduce((a, b) => a + 1, 0),
    warning: summaries.filter(item => item.severity === 'Warning' && parseInt(item.found) > 0).reduce((a, b) => a + 1, 0),
    score: `${(
      summaries.filter(item => parseInt(item.found) === 0 || ['Reject', 'Error'].indexOf(item.severity) < 0).reduce((a, b) => a + 1, 0) /
      summaries.reduce((a, b) => a + 1, 0)
    ) * 100} %`,
  }]

  return (
    <>
      <br />
      <Row>
        <Col>
          <DropdownButton
            color='primary' as={ButtonGroup} disabled={isDownloading}
            title={isDownloading ? 'Downloading...' : 'Download Report'}>
            <Dropdown.Item eventKey='pdf' onClick={() => onClickDownload('pdf')}>PDF</Dropdown.Item>
            <Dropdown.Item eventKey='xlsx' onClick={() => onClickDownload('xlsx')}>XLSX</Dropdown.Item>
          </DropdownButton>
        </Col>
        <Col style={{textAlign: 'right'}}>
          <Button onClick={() => history.push(`/gxp-qualification/jobs/${jobId}/details`)}>
            View Detailed Report
          </Button>
        </Col>
      </Row>

      <SubTitle title={`Summary Report for JOB ID: ${jobId}`} />

      {job && (
      <>
        <ValidationConfiguration
          title='Validation Configuration'
          data={{project, study, version, dataset, status, endedAt, author}}
          />

        <hr />
        <br />
        <h6>Validation Summary</h6>
        <br />
        <div className={classnames('gxp-qualification-summary')}>
          <BootstrapTable
            keyField='total' data={summaryRows}
            bordered={false} columns={summaryColumns} />
        </div>
      </>)
      }

      {!isLoading && (
      <>
        <hr />
        <br />
        <h6>Validation Summary Details</h6>
        <br />
        <div className={classnames('report-summary-table')}>
          <BootstrapTable
            keyField='rule_id' data={ productsWithButton } columns={ columns }
            filter={filterFactory()} rowClasses={rowClasses}
            noDataIndication={isLoading ? 'Loading Summary...' : 'No summary yet.'}
            cellEdit={ cellEditFactory({ mode: 'click', afterSaveCell }) }
            />
        </div>
      </>)}
    </>
  );
}

ComparedReportSummary.propTypes = {
  isLoading: PropTypes.bool.isRequired,
  loadSummary: PropTypes.func.isRequired,
  job: PropTypes.shape({

  }),
  summaries: PropTypes.arrayOf(PropTypes.shape({

  })),
  onDownload: PropTypes.func.isRequired,
}

export default ComparedReportSummary;
