from typing import Any, Dict, List, Tuple

import boto3

from src.config import settings
from src.utils.logger import Logger
from src.utils.aws.s3 import S3Util
from src.utils.aws.sts import STS
from src.models.parameters import ParameterEntry
from src.qualifications.services.core import ResourceCollectorBase

from .ec2 import CemfEc2
from .entries import Application, AwsAccountEntry
from .api import CemfAPI


class CemfResourceCollector(ResourceCollectorBase):
    def __init__(self) -> None:
        self.__sts = STS()

        self.__logger = Logger()

    @staticmethod
    def make_application_info(applications: Tuple[Application]) -> List[dict]:
        applications_info = []

        for app in applications:
            for project in app.projects:
                for server in project.servers:
                    applications_info.append(dict(
                        application_name=app.name,
                        **server.to_dict()
                    ))

        return applications_info

    @staticmethod
    def make_cemf_header(
        wave_id: str, account_number: str, account_name: str,
        job_id: int, event_type: str, created_by: str,
        source_build_spec: Any, source_post_spec: Any
    ) -> Dict[str, str]:
        return {
            'WaveId': wave_id,
            'AccountNumber': account_number,
            'AccountName': account_name,
            'AccountFullName': f'{account_number}({account_name})',
            'RunNumber': job_id,
            'EnvType': event_type,
            'CreatedBy': created_by,
            'SourceBuildSpec': source_build_spec,
            'SourcePostBuildSpec': source_post_spec,
        }

    def make_cemf_input_json(self, input_data: dict) -> Tuple[AwsAccountEntry]:
        self.__logger.log_info("NOTE: Parsing Expected Value Input JSON and creating hierarchial JSON output")

        accounts: Dict[str, AwsAccountEntry] = {}

        for current_rec in input_data:
            aws_account_id = current_rec["aws_accountid"]
            assume_role_name = current_rec["default_cross_account_role"]

            if aws_account_id not in accounts:
                accounts[aws_account_id] = AwsAccountEntry(aws_account_id, assume_role_name)

            current_account = accounts[aws_account_id]
            current_account.add_parameters(
                current_rec["wave_id"], current_rec["app_name"],
                current_rec["cloudendure_projectname"],
                server_name=current_rec["server_name"],
                server_os=current_rec["server_os"],
                server_fqdn=current_rec["server_fqdn"],
                server_environment=current_rec["server_environment"],
                variable=current_rec["ExpectedVariable"],
                value=current_rec["ExpectedValue"]
            )

        return tuple(accounts.values())

    def run_resource_collector(
        self, job_id: int, expected_val_input_json, default_region, parameters: List[ParameterEntry],
        expected_val_source, output_folder_name,
        cemf_api_token
    ) -> Tuple[List[str], List[dict]]:
        # Step 1- Parse input XLSX file and make a hierarchical expected value JSON File
        aws_accounts = self.make_cemf_input_json(expected_val_input_json)

        project_names = []
        for account in aws_accounts:
            for wave in account.waves:
                for application in wave.applications:
                    for project in application.projects:
                        project_names.append(project.name)

        # Step 2 - Get Machine Information from CMEF
        cemf_client = CemfAPI(cemf_api_token)
        cemf_projects = cemf_client.get_projects_with_machines(project_names)

        # Step 3- Create a separate report for each Account/WaveId combination
        result_files = []
        s3_util = S3Util()
        report_details = []

        for account in aws_accounts:
            account_name = self.__sts.get_account_name(account.account_id, account.assume_role_name)

            for wave in account.waves:
                final_output = {}

                application_info = []
                all_resources = []
                all_windows_resources = []
                all_windows_build_spec = []
                all_windows_post_build_spec = []
                all_build_spec = []
                all_server_mapping_windows = []

                all_linux_resources = []
                all_linux_build_spec = []
                all_linux_post_build_spec = []
                all_post_build_spec = []
                all_server_mapping_linux = []

                applications = wave.applications

                # Step 1 - Get Application Information
                application_info = self.__class__.make_application_info(applications)

                # Step 2 - Find CMEF Metadata & Build Specs
                ec2 = CemfEc2()
                (
                    cemf_resource_metadata_print, cemf_server_mapping,
                    print_all_cemf_build_spec, print_all_cemf_post_build_spec
                ) = ec2.cemf_metadata(
                    cemf_projects, account.account_id, wave.wave_id, applications,
                    default_region, parameters, account.assume_role_name,
                    expected_val_source
                )

                # Step 2.1 - Append CMEF EC2 Resource Metadata to All Resources
                for server_mapping in cemf_server_mapping:
                    if server_mapping.get("ServerOS") == "windows":
                        all_server_mapping_windows.append(server_mapping)
                    else:
                        all_server_mapping_linux.append(server_mapping)

                # Step 2.1 - Append CMEF EC2 Resource Metadata to All Resources
                for cmef_resources in cemf_resource_metadata_print:
                    if cmef_resources.get("ResourceOS") == "windows":
                        all_windows_resources.append(cmef_resources)
                        all_resources.append(cmef_resources)
                    else:
                        all_linux_resources.append(cmef_resources)
                        all_resources.append(cmef_resources)

                # Step 2.2 - Append OU Build Spec to All Build Spec
                for cmef_build_spec in print_all_cemf_build_spec:
                    if cmef_build_spec.get("ResourceOS") == "windows":
                        all_windows_build_spec.append(dict(cmef_build_spec).copy())
                        all_build_spec.append(dict(cmef_build_spec).copy())
                    else:
                        all_linux_build_spec.append(dict(cmef_build_spec).copy())
                        all_build_spec.append(dict(cmef_build_spec).copy())

                # Step 2.3 - Append OU Post Build Spec to All Post Build Spec
                for cmef_post_build_spec in print_all_cemf_post_build_spec:
                    if cmef_post_build_spec.get("ResourceOS") == "windows":
                        all_windows_post_build_spec.append(dict(cmef_post_build_spec).copy())
                        all_post_build_spec.append(dict(cmef_post_build_spec).copy())
                    else:
                        all_linux_post_build_spec.append(dict(cmef_post_build_spec).copy())
                        all_post_build_spec.append(dict(cmef_post_build_spec).copy())

                # Step 3 - Create Test Summary
                test_summary = self.make_test_summary(all_build_spec, all_post_build_spec)

                # Step 4 - Make CMEF Header
                EnvType = "Dev"

                # Get CreatedBy
                username = None
                try:
                    iam = boto3.client('iam')
                    username = iam.get_user()["User"]["UserName"]
                except iam.exceptions.ClientError as e:
                    username = e.response["Error"]["Message"].split(" ")[-1]
                current_account = boto3.client('sts').get_caller_identity().get('Account')
                CreatedBy = f'{username}@{current_account}'

                SourceBuildSpec = expected_val_source
                SourcePostBuildSpec = "DynamoDB table - rapidq-spec-parameters"
                header = self.__class__.make_cemf_header(
                    wave.wave_id, account.account_id, account_name, job_id, EnvType, CreatedBy,
                    SourceBuildSpec, SourcePostBuildSpec)

                # Step 5 - Create Final Output
                final_output = header
                final_output["application_info"] = application_info
                final_output["server_mapping_windows"] = all_server_mapping_windows
                final_output["server_mapping_linux"] = all_server_mapping_linux
                final_output["resources_windows"] = all_windows_resources
                final_output["resources_linux"] = all_linux_resources
                final_output["build_spec_windows"] = all_windows_build_spec
                final_output["build_spec_linux"] = all_linux_build_spec
                final_output["post_build_spec_windows"] = all_windows_post_build_spec
                final_output["post_build_spec_linux"] = all_linux_post_build_spec
                final_output["test_summary"] = test_summary

                # Upload final_output to S3 Bucket
                output_file_name = f"wave-{wave.wave_id}-account-{account.account_id}-run-{job_id}.json"
                s3_util.upload_dict_object_to_s3(
                    final_output, settings.STORAGE_BUCKET, output_folder_name, output_file_name)

                result_files.append(f'{output_folder_name}/{output_file_name}')
                report_details.append(final_output)

        return result_files, report_details
