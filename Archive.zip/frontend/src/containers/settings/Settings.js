import React from 'react';

import { Col } from 'reactstrap';

const SettingsPage = () => {
  // const breadcrumbs = [{
  //   title: 'Home',
  //   link: '/'
  // }, {
  //   title: 'Settings',
  // }]

  return (
    <Col>
      <h2>Settings page</h2>
    </Col>
  )
}

export default SettingsPage;
