import os
import json
import boto3
from urllib.parse import unquote_plus

from src.utils.logger import Logger


class S3Util:
    def __init__(self) -> None:
        self.__client = boto3.client('s3')

        self.__logger = Logger()

    def read_json_file(self, bucket_name: str, key_path: str) -> dict:
        self.__logger.log_info(f'Reading json content from s3://{bucket_name}/{key_path}...')
        s3_object_key = unquote_plus(key_path)
        obj = self.__client.get_object(Bucket=bucket_name, Key=s3_object_key)
        input_file_content = obj['Body'].read().decode('utf-8')
        return json.loads(input_file_content)

    def upload_dict_object_to_s3(self, data: dict, bucket_name: str, key_path: str, filename: str):
        if filename:
            key_path = os.path.join(key_path, filename)

        self.__logger.log_info(f"NOTE: Uploading file - {key_path} to S3 Bucket - {bucket_name}")

        try:
            self.__client.put_object(
                Body=str(json.dumps(data, indent=4)),
                Bucket=bucket_name, Key=key_path)
        except Exception as e:
            self.__logger.log_info(
                f'Failed to upload file data to s3://{bucket_name}/{key_path} with exception {e}'
            )

    def upload_file_to_s3(self, file_path: str, bucket_name: str, key_path: str, filename: str = None):
        if filename:
            key_path = os.path.join(key_path, filename)

        self.__logger.log_info(f"NOTE: Uploading file - {key_path} to S3 Bucket - {bucket_name}")
        try:
            self.__client.upload_file(file_path, bucket_name, key_path)
        except Exception as e:
            self.__logger.log_info(
                f"ERROR: Cannot upload {key_path} to S3 - Bucket - {bucket_name}, File - . Exception: ", str(e))
