"""
AutoIQOQ Resource Collector Lambda Function
___________________________________________

Description: This code finds AWS resource information from different accounts.
The account id from which AWS metadata needs to be queried is specified from a
JSON file uploaded to a S3 bucket.
The code then compares the expected value of metadata from the JSON file with the actual value
that comes after querying in different accounts.
It then makes a final JSON file that can be passed to IQOQ Report generator lambda function to create
an IQOQ report

Dependencies:
Trigger: Upload of JSON file to S3 Bucket
Input: JSON File with following mandatory fields
Output: JSON file with following sections:

"""

from typing import Dict

from src.config import settings
from src.utils.aws.s3 import S3Util
from src.models.jobs import JobEntry
from src.models.admin.projects import ProjectModel
from src.utils.validators import Ec2PermissionValidator
from src.utils.validators import IAMValidator
from src.qualifications.services.core import ServiceInterface
from src.qualifications.services.cemf.validators import CemfCSVValidator, AssumeRoleValidator
from src.qualifications.services.cemf.resources import CemfResourceCollector
from src.qualifications.services.cemf.report import CemfReport


class CEMFService(ServiceInterface):

    # default_ddb_region = "us-east-1"
    # default_cross_account_role = "autogxp-dev-crossaccount-role"
    # cemf_api_token = "48D0-69D1-716B-7102-8EF5-D007-C44B-1286-7451-6CF9-769E-8B87-4F6B-700F-1A9B-F531"
    # ddb_spec_table_name = "rapidq-spec-parameters"

    def collect_resource(self, job_entry: JobEntry):
        s3_util = S3Util()
        project_model = ProjectModel()

        project = project_model.get_detail(job_entry.project_id)
        cemf_csv_file_content = s3_util.read_json_file(settings.STORAGE_BUCKET, job_entry.s3_input_url)
        output_folder_name = f'public/{job_entry.project_id}/{job_entry.user_id}/{job_entry.id}/resource-collector'
        cemf_csv_file_details = cemf_csv_file_content["CEMF_JSON_FileDetails"]
        cemf_csv_s3_key = cemf_csv_file_content["CEMF_CSV_S3_Key"]
        default_region = project.setting.get('default_region')
        cemf_api_token = project.setting.get('cemf_api_token')

        # Call Resource Collector Function
        collector = CemfResourceCollector()
        return collector.run_resource_collector(
            job_entry.id, cemf_csv_file_details, default_region, project.parameters,
            cemf_csv_s3_key, output_folder_name, cemf_api_token
        )

    def generate_report(self, job_entry: JobEntry, key_path: str):
        report_util = CemfReport()
        return report_util.generate_report(job_entry, key_path)

    def validate(self, project_id: int, key_path: str, run_method: str) -> Dict[str, bool]:
        file_validator = CemfCSVValidator()
        role_validator = AssumeRoleValidator()
        ec2_validator = Ec2PermissionValidator()
        iam_validator = IAMValidator()

        excel_validate_result, data = file_validator.run(project_id, key_path, run_method)
        role_validate_result, output_key_path = role_validator.run(project_id, key_path, data)

        role_result = all(status for _, status in role_validate_result.items()) if role_validate_result else False
        ec2_result = ec2_validator.run()
        iam_result = iam_validator.run()

        return {
            'excel': excel_validate_result,
            'assume_role': role_result,
            'ec2': ec2_result,
            'iam': iam_result,
            'output_key_path': output_key_path,
        }
