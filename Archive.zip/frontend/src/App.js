import { Provider } from 'react-redux';
import { ConnectedRouter } from 'connected-react-router';
import { withAuthenticator } from '@aws-amplify/ui-react'
import { Route, Switch, Redirect } from "react-router-dom";

import store, { history } from './redux';

import AdminLayout from "layouts/Admin.js";
import GxInfraPLayout from "layouts/GxPInfraLayout";
import GxPQualificationLayout from 'layouts/GxPQualificationLayout';
import GxPControlLayout from 'layouts/GxPControlLayout';
// import RTLLayout from "layouts/RTL.js";
// import AuthLayout from "layouts/Auth.js";
// import IndexView from "views/Index.js";


const App = () => {
  return (
    <Provider store={store}>
      <ConnectedRouter history={history} >
        <Switch>
          <Route path="/gxp-infra" render={(props) => <GxInfraPLayout {...props} />} />
          <Route path="/gxp-qualification" render={(props) => <GxPQualificationLayout {...props} />} />
          <Route path="/gxp-control" render={(props) => <GxPControlLayout {...props} />} />
          <Route path="/admin" render={(props) => <AdminLayout {...props} />} />
          {/* <Route path="/rtl" render={(props) => <RTLLayout {...props} />} />
          <Route path="/auth" render={(props) => <AuthLayout {...props} />} />
          <Route path="/" render={(props) => <IndexView {...props} />} /> */}
          <Redirect from="*" to="/gxp-infra/dashboard" />
        </Switch>
      </ConnectedRouter>
    </Provider>
  );
}

export default withAuthenticator(App);
