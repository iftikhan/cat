import React from 'react';
import PropTypes from 'prop-types';

import  { Card, CardHeader, CardBody } from 'reactstrap';

const ServerMapping = ({
  title, servers,
}) => {
  return (
    <Card>
      <CardHeader>{title}</CardHeader>
      <CardBody>
      {servers.map(({
          ServerName: serverName, OperatingSystem: operatingSystem, ServerMapping: mappings,
        }, serverIdx) => (
          <div key={serverIdx}>
            <table className='table'>
              <thead className='thead-dark'>
                <tr>
                  <td>S.N</td>
                  <td>Type</td>
                  <td>Pre Migration</td>
                  <td>Post Migration</td>
                </tr>
              </thead>
              <tbody>
                  <>
                    <tr key={serverIdx}>
                      <td colSpan={4}>{`Server Name: ${serverName} | Operating System: ${operatingSystem}`}</td>
                    </tr>
                    {mappings.map(({Attribute: type, PreMigration: preMigration, PostMigration: postMigration}, idx) => (
                      <tr key={idx}>
                        <td>{idx + 1}</td>
                        <td>{type}</td>
                        <td>{
                          typeof preMigration === 'string'
                          ? preMigration
                          : preMigration.map(item => Object.entries(item).map(([attr, val], attrIdx) => (
                            <p key={attrIdx}><strong>{attr}</strong>: {val}</p>
                          )))
                        }</td>
                        <td>{postMigration}</td>
                      </tr>
                    ))}
                  </>
              </tbody>
            </table>
          </div>
      ))}
      </CardBody>
    </Card>
  )
}

ServerMapping.propTypes = {
  title: PropTypes.string.isRequired,
  servers: PropTypes.arrayOf(PropTypes.shape({
    ServerName: PropTypes.string.isRequired,
    OperatingSystem: PropTypes.string.isRequired,
    ServerMapping: PropTypes.arrayOf(PropTypes.shape({
      Attribute: PropTypes.string.isRequired,
      PostMigration: PropTypes.string.isRequired,
      PreMigration: PropTypes.oneOfType([
        PropTypes.arrayOf(PropTypes.oneOfType([
          PropTypes.string,
          PropTypes.object
        ])),
        PropTypes.string
      ])
    }))
  }))
}

export default ServerMapping;
