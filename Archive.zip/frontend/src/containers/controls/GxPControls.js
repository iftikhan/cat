import React, { useEffect, useState, useCallback } from 'react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router';

import {
  Row, Col, Form, Button, Card, CardHeader, CardBody,
  Input,
} from 'reactstrap';

import { FaPlusCircle } from 'react-icons/fa';
import Select2 from "react-select2-wrapper";

import API from 'helpers/api';
import LoadingModal from 'components/modals/Loading';
import { fetchLzAccountsRequest } from 'containers/infrastructure/actions';
import SearchTable from 'components/tables/SearchTable';
import ConfirmModal from 'components/modals/ConfirmModal';
import { AwsServices, ComplianceStandards } from 'utils/constants';

const GxPControls = ({
  infras, fetchingInfras, fetchLzAccountsRequest,
}) => {
  const [landingZones, setLandingZones] = useState([]);
  const [curLandingZoneId, setCurLandingZoneId] = useState(null);
  const [accounts, setAccounts] = useState([]);
  const [managedRules, setManagedRules] = useState([]);
  const [filteredRules, setFilteredRules] = useState([]);
  const [selectedAwsService, setSelectedAwsService] = useState('');
  const [selectedStandard, setSelectedStandard] = useState('');

  const [selectedRules, setSelectedRules] = useState([]);
  const [selectedAccounts, setSelectedAccounts] = useState([]);

  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const history = useHistory();

  const onSelectRule = useCallback((ruleId: Number, selected: Boolean) => {
    if (selected) {
      setSelectedRules([
        ...selectedRules,
        ruleId,
      ])
    } else {
      setSelectedRules(selectedRules.filter(item => item !== ruleId))
    }
  }, [
    selectedRules,
  ])

  const onSelectAccount = useCallback((accountId: Number, selected: Boolean) => {
    if (selected) {
      setSelectedAccounts([
        ...selectedAccounts,
        accountId,
      ])
    } else {
      setSelectedAccounts(selectedAccounts.filter(item => item !== accountId))
    }
  }, [
    selectedAccounts,
  ])

  const onSelectAllRule = useCallback((checked) => {
    if (checked) {
      setSelectedRules(managedRules.map(({id}) => id));
    } else {
      setSelectedRules([]);
    }
  }, [setSelectedRules, managedRules])

  const onSelectAllAccount = useCallback((checked) => {
    if (checked) {
      setSelectedAccounts(accounts.map(({id}) => id));
    } else {
      setSelectedAccounts([]);
    }
  }, [setSelectedAccounts, accounts])

  const getLandingZones = useCallback(() => {
    API.infrastructure.getLandingZones().then(({landing_zones: items}) => {
      setLandingZones(items);
      if (items.length === 0) {
        history.push('/gxp-infra/admin');
      } else {
        const [{id: landingZoneId}] = items;
        setCurLandingZoneId(JSON.stringify(landingZoneId));
      }
    }).catch(err => {
      console.error(err);
      alert('Failed to fetch landing zones')
    }).finally(() => {
      console.log('Done: Fetching landing zones')
    })
  }, [setLandingZones, setCurLandingZoneId, history])

  useEffect(() => {
    getLandingZones()
  }, [getLandingZones])

  useEffect(() => {
    API.controls.getManagedRules().then(({status, managed_rules: rules}) => {
      if (status) {
        setManagedRules(rules)
      }
    }).catch(err => {
      console.error(err);
    })
  }, [setManagedRules]);

  const fetchLandingZoneAccounts = useCallback(() => {
    if (!!curLandingZoneId) {
      API.fetchLandingZoneAccounts(curLandingZoneId).then((response: {
        accounts: Array<Object>
      }) => {
        const { accounts, status } = response;
  
        if (status) {
          setAccounts(accounts)
        } else {
          setAccounts([])
        }
      }).catch(() => {
        alert('something went wrong!');
      })
    }
  }, [setAccounts, curLandingZoneId])

  useEffect(() => {
    if (curLandingZoneId) {
      fetchLandingZoneAccounts()
    }
  }, [
    curLandingZoneId, fetchLandingZoneAccounts,
  ]);

  const onApplyRulesToAccounts = () => {
    API.controls.applyManagedRulesToAccountsInBatch(selectedRules, selectedAccounts)
    .then(({status}) => {
      if (status) {
        setSelectedAccounts([]);
        setSelectedRules([]);
        fetchLandingZoneAccounts();
        setShowConfirmModal(false);
      }
    }).catch(err => {
      console.error(err);
    })
  }

  const managedRuleColumns = [
    {
      dataField: 'select',
      text: '',
      headerFormatter: (col, colIndex, components) => {
        return (
          <div className="custom-control custom-checkbox">
            <input
              className="custom-control-input"
              id={`managed-rule-table-check-all`}
              disabled={!!selectedAwsService || !!selectedStandard}
              onClick={(event) => {onSelectAllRule(event.target.checked)}}
              defaultChecked={managedRuleColumns.length === selectedRules.length}
              type="checkbox"
            />
            <label
              className="custom-control-label"
              htmlFor={`managed-rule-table-check-all`}
            />
          </div>
        )
      },
    }, {
      dataField: 'name',
      text: 'Managed Rule Name',
      sort: true,
    }, {
      dataField: 'description',
      text: 'Description',
    }
  ]

  const accountColumns = [
    {
      dataField: 'select',
      text: '',
      headerFormatter: (col, colIndex, components) => {
        return (
          <div className="custom-control custom-checkbox">
            <input
              className="custom-control-input"
              id={`managed-account-table-check-all`}
              onChange={(event) => {onSelectAllAccount(event.target.checked)}}
              checked={accounts.length === selectedAccounts.length}
              type="checkbox"
            />
            <label
              className="custom-control-label"
              htmlFor={`managed-account-table-check-all`}
            />
          </div>
        )
      },
    }, {
      dataField: 'organization_unit',
      text: 'Organization Unit',
      sort: true,
    }, {
      dataField: 'name',
      text: 'Account Name',
      sort: true,
    }, {
      dataField: 'account_id',
      text: 'Account Number',
      align: 'right',
      headerStyle: {width: '120px'},
      sort: true,
    }, {
      dataField: 'number_of_rules',
      text: 'Number of Rules',
      align: 'right',
      headerStyle: {width: '180px',},
      sort: true,
    }, {
      dataField: '',
      text: '',
      headerStyle: {width: '56px'},
      formatter: (value, row) => {
        const {id: accountId} = row;
        return (
          <Button
            className={'btn-sm'}
            onClick={() => history.push(`/gxp-control/controls/${curLandingZoneId}/accounts/${accountId}`)}>
            <FaPlusCircle />
          </Button>
        )
      }
    },
  ];

  useEffect(() => {
    setFilteredRules(managedRules.filter(({tags, name, description}) => {
      if (!!selectedAwsService) {
        if (tags.filter(item => item.toLowerCase() === selectedAwsService.toLowerCase()).length === 0) {
          return false
        }
      }

      if (!!selectedStandard) {
        return (
          description.toLowerCase().indexOf(selectedStandard.toLowerCase()) >=0 ||
          name.toLowerCase().indexOf(selectedStandard.toLowerCase()) >=0
        )
      }
      return true
    }))
  }, [selectedAwsService, selectedStandard, setFilteredRules, managedRules])

  return (
    <>
      <Row>
        <Col size='auto'></Col>
        <Col sm={4} md={3}>
          <h3 className='mt-2'>
          Select Landing Zone
          </h3>
        </Col>
        <Col>
          <Form>
            <Select2
              className="form-control"
              defaultValue={curLandingZoneId}
              onChange={e => setCurLandingZoneId(e.target.value)}
              options={{
                placeholder: "Select",
              }}
              data={landingZones.map(({id, name}) => ({id, text: name}))}
            />
          </Form>
        </Col>
      </Row>
      <Card className='mt-3'>
        <CardHeader>Select Controls to be applied.</CardHeader>
        <CardBody>
          <Row className='mb-3'>
            <Col lg={2}>
              <Input
                className="form-control-sm"
                type='select' value={selectedAwsService}
                onChange={(event) => setSelectedAwsService(event.target.value)}
              >
                <option value={''}>AWS Service</option>
                {AwsServices.map((item, idx) => (
                  <option key={idx} value={item}>{item.toUpperCase()}</option>
                ))}
              </Input>
            </Col>
            <Col lg={3}>
              <Input
                className="form-control-sm"
                type='select' value={selectedStandard}
                onChange={(event) => setSelectedStandard(event.target.value)}
              >
                <option value={''}>Compliance Standard</option>
                {ComplianceStandards.map((item, idx) => (
                  <option key={idx} value={item}>{item}</option>
                ))}
              </Input>
            </Col>
          </Row>
          <SearchTable
            columns={managedRuleColumns} keyField='id'
            enableSearch={false}
            data={filteredRules.map((rule, idx) => ({
              ...rule,
              select: (
                <div className="custom-control custom-checkbox" key={idx}>
                  <input
                    className="custom-control-input"
                    id={`managed-rule-table-check-${rule.id}`}
                    onChange={(event) => {onSelectRule(rule.id, event.target.checked)}}
                    checked={selectedRules.indexOf(rule.id) >= 0}
                    type="checkbox"
                  />
                  <label
                    className="custom-control-label"
                    htmlFor={`managed-rule-table-check-${rule.id}`}
                  />
              </div>)
            }))}
            entryNamePlural='rules'
            noDataIndication={'No managed rule'}
            />
        </CardBody>
      </Card>
      <Card>
        <CardHeader>Select Accounts</CardHeader>
        <CardBody>
          <SearchTable
            columns={accountColumns} keyField='id'
            data={accounts.map((account, idx) => ({
              ...account,
              select: (
                <div className="custom-control custom-checkbox" key={idx}>
                  <input
                    className="custom-control-input"
                    id={`managed-account-table-check-${account.id}`}
                    onChange={(event) => {onSelectAccount(account.id, event.target.checked)}}
                    checked={selectedAccounts.indexOf(account.id) >= 0}
                    type="checkbox"
                  />
                  <label
                    className="custom-control-label"
                    htmlFor={`managed-account-table-check-${account.id}`}
                  />
              </div>)
            }))}
            entryNamePlural='accounts'
            noDataIndication='No account.'
            />
        </CardBody>
      </Card>
      <Card>
        <CardBody>
          <Button
            color="primary" className='float-right'
            disabled={selectedRules.length === 0 || selectedAccounts.length === 0}
            onClick={() => {setShowConfirmModal(true)}}>
            Apply
          </Button>
        </CardBody>
      </Card>
      <ConfirmModal
        title='Confirm!'
        description={`Are you sure to apply ${selectedRules.length} rules to ${selectedAccounts.length} accounts?`}
        onCancel={() => setShowConfirmModal(false)}
        show={showConfirmModal}
        onOkay={onApplyRulesToAccounts}
        />
      <LoadingModal show={false} />
    </>
  )
}

const mapStateToProps = (state) => ({
});

const mapDispatchToProps = (dispatch) => ({
  fetchLzAccountsRequest: () => dispatch(fetchLzAccountsRequest()),
})

export default connect(mapStateToProps, mapDispatchToProps)(GxPControls);
