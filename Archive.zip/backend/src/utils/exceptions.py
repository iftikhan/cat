from typing import Any, MethodDescriptorType


class ApplicationLogicException(Exception):
    """
    This exception is a parent exception for application logic exceptions.
    Exceptions of this type should be thrown,
    when something goes wrong against of application logic.
    """
    def __init__(self, message):
        super().__init__(message or 'Application logic error!')


class ArgumentTypeException(TypeError):
    """ Specific TypeError for method arguments """

    def __init__(
        self, method_object: MethodDescriptorType, argument_name: str, argument_value: Any
    ):
        super().__init__(
            '{0} {1} expects {2}, {3} is given!'.format(
                method_object.__qualname__,
                argument_name,
                method_object.__annotations__.get(argument_name, '???'),
                type(argument_value).__qualname__
            )
        )


class ArgumentCannotBeEmptyException(ValueError):
    def __init__(self, method_object: MethodDescriptorType, argument_name: str):
        super().__init__(
            '{0} {1} cannot be empty!'.format(method_object.__qualname__, argument_name))


class ArgumentUnexpectedValueException(ValueError):
    """ Specific ValueError, which should be thrown,
    when some value is out of range of known values """

    def __init__(self, value: Any, supported_values: tuple):
        super().__init__(
            '{0} is out of range of known values: {1}!'.format(value, supported_values))


class AWSResourceNotFoundException(ValueError):
    def __init__(self, resource_name: str, identifier: str, *args):
        self.resource_name = resource_name
        self.identifier = identifier
        super().__init__(*args)


class NoSuchBucketException(ValueError):
    def __init__(self, bucket_name: str, *args):
        super().__init__(f'Bucket not found - {bucket_name}!')


class IncorrectCrossAccountRoleException(Exception):
    pass


class InvalidCmefTokenException(Exception):
    pass
