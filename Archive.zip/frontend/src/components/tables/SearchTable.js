import React from 'react';
import PropTypes from 'prop-types';

import { Row } from 'reactstrap';

import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from "react-bootstrap-table2-paginator";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";

const SearchTable = ({
  data, keyField, columns, entryName, entryNamePlural,
  pageSizeOptions, noDataIndication, customSearchBar,
  enableSearch, ...others
}) => {
  const { SearchBar } = Search;
  const pagination = paginationFactory({
    page: 1,
    alwaysShowAllBtns: true,
    showTotal: true,
    withFirstAndLast: false,
    sizePerPageRenderer: ({ options, currSizePerPage, onSizePerPageChange }) => (
      <div className="dataTables_length" id="datatable-basic_length">
        <label>
          Show{" "}
          {
            <select
              name="datatable-basic_length"
              aria-controls="datatable-basic"
              className="form-control form-control-sm"
              onChange={e => onSizePerPageChange(e.target.value)}
            >
              {pageSizeOptions.map((item, idx) => (
                <option key={idx} value={item}>{item}</option>
              ))}
            </select>
          }{" "}
          {entryNamePlural}.
        </label>
      </div>
    )
  });

  return (
    <ToolkitProvider
      data={data}
      keyField={keyField}
      columns={columns}
      search
    >
      {props => (
        <div className="">
          {enableSearch && <Row>
            <div
              id="datatable-basic_filter"
              className="dataTables_filter px-4 pb-1"
            >
              {customSearchBar ? customSearchBar : (
              <label>
                Search:
                <SearchBar
                  className="form-control-sm"
                  placeholder=""
                  {...props.searchProps}
                />
              </label>)}
            </div>
          </Row>}
          <BootstrapTable
            classes='align-items-center'
            {...props.baseProps}
            bootstrap4={true}
            pagination={data.length > pageSizeOptions[0] ? pagination : null}
            bordered={false}
            headerClasses='thead-dark'
            noDataIndication={noDataIndication ? noDataIndication : `Loading ${entryNamePlural}...`}
            {...others}
          />
        </div>
      )}
    </ToolkitProvider>
  )
}

SearchTable.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object).isRequired,
  keyField: PropTypes.string.isRequired,
  columns: PropTypes.arrayOf(PropTypes.object).isRequired,
  entryName: PropTypes.string,
  entryNamePlural: PropTypes.string,
  pageSizeOptions: PropTypes.arrayOf(PropTypes.number),
  noDataIndication: PropTypes.string,
  customSearchBar: PropTypes.node,
  enableSearch: PropTypes.bool,
}

SearchTable.defaultProps = {
  entryName: 'entry',
  entryNamePlural: 'entries',
  pageSizeOptions: [10, 20, 50],
  noDataIndication: null,
  customSearchBar: null,
  enableSearch: true,
}

export default SearchTable;
