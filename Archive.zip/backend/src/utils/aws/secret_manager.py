import json
import boto3


class SecretManager:
    def __init__(self) -> None:
        self.__client = boto3.client('secretsmanager')

    def create_secret(self, name: str, credentials: dict, description: str = None):
        return self.__client.create_secret(
            Name=name,
            Description=description,
            SecretString=json.dumps(credentials),
        )

    def update_secret_value(self, name: str, credentials: dict, description: str = None):
        return self.__client.update_secret(
            SecretId=name,
            SecretString=json.dumps(credentials),
            Description=description,
        )

    def retrieve_secret_value(self, name: str) -> dict:
        response = self.__client.get_secret_value(SecretId=name)
        return json.loads(response['SecretString'])
