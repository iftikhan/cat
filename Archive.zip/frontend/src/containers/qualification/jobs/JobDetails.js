import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { useParams } from 'react-router-dom';
import {
  Button,
  Card, CardBody, CardHeader,
} from 'reactstrap';

import API from 'helpers/api';

import { fetchJobDetailsRequest } from '../actions';

import ValidationConfiguration from './reports/ValidationConfiguration'
import ReportDetailsLandingZone from './reports/ReportDetailsLandingZone';
import ReportDetailsCEMF from './reports/ReportDetailsCEMF';
import WaveInfo from './reports/WaveInfo';
import LandingZoneInfo from './reports/LandingZoneInfo';
import { QUALIFICATION_TYPE_CLOUDENDURE_MIGRATION_FACTORY } from 'utils/constants';

const JobDetails = ({
  job, fetchJobDetailsRequest,
  isLoading,
}) => {
  const { jobId } = useParams();
  const {
    project, qualification_type: qualificationType,
    qualification_type_id: qualificationTypeId,
    id, run_method: runMethod,
    status, ended_at: endedAt,
    reports,
    report_details: reportDetails,
    // reports,
    created_by: createdBy,
  } = job || {};

  const [isDownloading, setIsDownloading] = useState(false);
  const [details] = reportDetails || [];

  useEffect(() => {
    fetchJobDetailsRequest(jobId)
  }, [fetchJobDetailsRequest, jobId]);

  const onDownloadClicked = () => {
    const [url] = reports;
    setIsDownloading(true)
    API.downloadReport(jobId, url).then(() => {
      setIsDownloading(false);
    }).catch(() => {
      setIsDownloading(false);
    })
  }
  return (
    <>
      <Card>
        <CardHeader className="d-flex align-items-center">
          <div className="d-flex align-items-center">
            <div className="mx-3">
              <a
                className="text-dark font-weight-600 text-bg"
                href="#pablo"
                onClick={(e) => e.preventDefault()}
              >
                {
                  qualificationTypeId === QUALIFICATION_TYPE_CLOUDENDURE_MIGRATION_FACTORY
                  ? `Post Migration Test Report ${jobId}`
                  : `Landing Zone Qualification Report ${jobId}`
                }
              </a>
              <small className="d-block text-muted">{endedAt}</small>
            </div>
          </div>
          <div className="text-right ml-auto">
            <Button
              className="btn-icon"
              color="primary"
              type="button"
              onClick={onDownloadClicked}
            >
              <span className="btn-inner--icon mr-1">
                <i className="ni ni-cloud-download-95" />
              </span>
              <span className="btn-inner--text">{isDownloading ? 'Downloading...' : 'Download Report'}</span>
            </Button>
          </div>
        </CardHeader>
        {job && !isLoading && (
          <CardBody>
            <ValidationConfiguration
              title='Test Configuration'
              data={{
                project, qualificationType, runMethod, id,
                status, endedAt, createdBy,
              }}
              />
          </CardBody>
        )}
      </Card>

      {job && !isLoading && (
        <>
          {details && (
            <>
              <br />
              {qualificationTypeId === QUALIFICATION_TYPE_CLOUDENDURE_MIGRATION_FACTORY
              ? <WaveInfo data={details} createdAt={endedAt} />
              : <LandingZoneInfo data={details} createdAt={endedAt} />}
            </>
          )}

          {qualificationTypeId === QUALIFICATION_TYPE_CLOUDENDURE_MIGRATION_FACTORY
          ? <ReportDetailsCEMF
              details={details}
              isLoading={isLoading}
              isDownloading={isDownloading}
              onDownload={onDownloadClicked} />
          : <ReportDetailsLandingZone
            details={details}
            isLoading={isLoading}
            isDownloading={isDownloading}
            onDownload={onDownloadClicked} />}
        </>
      )}

    </>
  );
}

JobDetails.propTypes = {
  job: PropTypes.shape({
    id: PropTypes.number.isRequired,
    project: PropTypes.string.isRequired,
    s3_input_url: PropTypes.string.isRequired,
    s3_report_url: PropTypes.string,
    started_at: PropTypes.string.isRequired,
    ended_at: PropTypes.string.isRequired,
    status: PropTypes.string.isRequired,
    qualification_type: PropTypes.string.isRequired,
    run_method: PropTypes.string.isRequired,
    reports: PropTypes.arrayOf(PropTypes.string).isRequired,
    report_details: PropTypes.arrayOf(PropTypes.object),
  }),
  isLoading: PropTypes.bool.isRequired,
  fetchJobDetailsRequest: PropTypes.func.isRequired,
}

const mapStateToProps = state => ({
  job: state.qualifications.job,
  isLoading: state.qualifications.fetchingJobDetails,
})

const mapDispatchToProps = dispatch => ({
  fetchJobDetailsRequest: (jobId: Number) => dispatch(fetchJobDetailsRequest({ jobId })),
})

export default connect(mapStateToProps, mapDispatchToProps)(JobDetails);
