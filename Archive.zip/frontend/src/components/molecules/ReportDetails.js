import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { useParams, useHistory } from 'react-router-dom';

import {
  Button, Row, Col, DropdownButton, Dropdown, ButtonGroup,
} from 'reactstrap';

import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';
import paginationFactory, {
  PaginationProvider, PaginationTotalStandalone,
  PaginationListStandalone, SizePerPageDropdownStandalone,
} from 'react-bootstrap-table2-paginator';

import SubTitle from 'components/common/SubTitle';

const ReportDetails = ({
  details, loadDetails, onDownload, isLoading,
}) => {
  const history = useHistory();
  const params = useParams();
  const { jobId, ruleId } = params;

  const [isDownloading, setIsDownloading] = useState(false);

  const columns = [
    {
      dataField: 'domain',
      text: 'Domain',
      filter: textFilter(),
      headerStyle: {
        width: '150px'
      }
    }, {
      dataField: 'record_number',
      text: 'Record',
      filter: textFilter(),
      headerStyle: {
        width: '80px'
      },
      style: {
        textAlign: 'right'
      }
    }, {
      dataField: 'variable_names',
      text: 'Variables',
      filter: textFilter(),
      headerStyle: {
        width: '150px'
      },
      formatter: (cel, row, rowIndex) => {
        if (Array.isArray(cel)) {
          return <code key={rowIndex}>{cel.join(', ')}</code>
        } else {
          return cel
        }
      },
    }, {
      dataField: 'variable_values',
      text: 'Values',
      filter: textFilter(),
      headerStyle: {
        width: '90px'
      },
      formatter: (cel, row, rowIndex) => {
        if (Array.isArray(cel)) {
          return <code key={rowIndex}>{cel.join(', ')}</code>
        } else {
          return cel
        }
      },
    }, {
      dataField: 'rule_id',
      text: 'Rule ID',
      filter: textFilter(),
      headerStyle: {
        width: 80
      }
    }, {
      dataField: 'message',
      text: 'Message',
      filter: textFilter(),
    }, {
      dataField: 'category',
      text: 'Category',
      filter: textFilter(),
      headerStyle: {
        width: '150px'
      },
    }, {
      dataField: 'severity',
      text: 'Severity',
      filter: textFilter(),
      headerStyle: {
        width: '90px'
      }
    },
  ];

  useEffect(() => {
    loadDetails(jobId, ruleId)
  }, [jobId, ruleId, loadDetails]);

  const onClickDownload = (mode) => {
    setIsDownloading(true)
    onDownload(jobId, mode, () => {
      setIsDownloading(false)
    }).then(() => setIsDownloading(false)).catch(err => {
      setIsDownloading(false);
      alert('Failed to create report.')
    });
  }

  const paginationOptions = {
    custom: true,
    totalSize: details.length,
    nextPageText: 'Next',
    prePageText: 'Prev',
    firstPageText: 'First',
    lastPageText: 'Last',
  }

  return (
    <>
      <br />
      <Row>
        <Col>
          <DropdownButton
            color='primary' as={ButtonGroup} disabled={isDownloading}
            title={isDownloading ? 'Downloading...' : 'Download Report'}>
            <Dropdown.Item eventKey='pdf' onClick={() => onClickDownload('pdf')}>PDF</Dropdown.Item>
            <Dropdown.Item eventKey='xlsx' onClick={() => onClickDownload('xlsx')}>XLSX</Dropdown.Item>
          </DropdownButton>
        </Col>
        <Col style={{textAlign: 'right'}}>
          <Button onClick={() => history.push(`/gxp-qualification/jobs/${jobId}/compare`)}>View Summary Report</Button>
        </Col>
      </Row>

      <SubTitle title={`Detailed Report for JOB ID: ${jobId}`} />

      <PaginationProvider
        pagination={paginationFactory(paginationOptions)}>
        {
          ({
            paginationProps,
            paginationTableProps
          }) => (
            <div>
              <SizePerPageDropdownStandalone
                { ...paginationProps }
              />
              <PaginationTotalStandalone
                { ...paginationProps }
              />
              <PaginationListStandalone
                { ...paginationProps }
              />
              <BootstrapTable
                keyField='id' data={ details } columns={ columns }
                filter={filterFactory()}
                noDataIndication={isLoading ? 'Loading...' : 'No details yet.'}
                pagination={ paginationFactory(paginationOptions) }
                {...paginationTableProps}
                />
            </div>
          )
        }
      </PaginationProvider>
    </>
  );
}

ReportDetails.propTypes = {
  details: PropTypes.arrayOf(PropTypes.shape({
    domain: PropTypes.string.isRequired,
  })).isRequired,
  loadDetails: PropTypes.func.isRequired,
  onDownload: PropTypes.func.isRequired,
  isLoading: PropTypes.bool.isRequired,
}

export default ReportDetails;
