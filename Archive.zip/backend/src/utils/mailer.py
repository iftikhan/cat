import boto3
from typing import List
from botocore.exceptions import ClientError
from src.config import settings
from .exceptions import ArgumentTypeException


class MailMessage:
    dummy_mail_template = """<html>
        <head></head>
        <body>
        <h1>{subject}</h1>
        <p>{content}</p>
        </body>
        </html>"""

    # TODO: We may need to integrate better email templating later
    mail_template_filename: str = None

    def __init__(self, to_emails: List[str], subject: str, body: str):
        # TODO: Need to validate email with regex later
        if any(not isinstance(x, str) or not x for x in to_emails):
            raise ArgumentTypeException(self.__init__, 'to_emails', to_emails)

        if not isinstance(subject, str):
            raise ArgumentTypeException(self.__init__, 'subject', subject)

        if not isinstance(body, str):
            raise ArgumentTypeException(self.__init__, 'body', body)

        self.__to_emails = to_emails
        self.__subject = subject
        self.__body = body

    @property
    def destination(self) -> List[str]:
        return self.__to_emails

    @property
    def subject(self) -> str:
        return self.__subject

    @property
    def text_body(self) -> str:
        return self.__body

    @property
    def html_body(self) -> str:
        lines = self.text_body.split('\n')
        return self.dummy_mail_template.format(
            subject=self.subject,
            content="".join([f"<p>{line}</p>" for line in lines])
        )


class MailerAbstract:
    def send(self, message: MailMessage):
        NotImplementedError()


class SesMailer(MailerAbstract):
    CHARSET = "UTF-8"
    CONFIGURATION_SET = "ConfigSet"

    def __init__(self):
        self.__sender = f'EtherealRisk Admin <{settings.SES_SENDER_EMAIL}>'
        self.__client = boto3.client('ses', region_name='us-east-1')

    def send(self, message: MailMessage):
        try:
            self.__client.send_email(
                Destination={
                    'ToAddresses': message.destination
                },
                Message={
                    'Body': {
                        'Html': {
                            'Charset': self.CHARSET,
                            'Data': message.html_body,
                        },
                        'Text': {
                            'Charset': self.CHARSET,
                            'Data': message.text_body,
                        },
                    },
                    'Subject': {
                        'Charset': self.CHARSET,
                        'Data': message.subject,
                    },
                },
                Source=self.__sender,
                # If you are not using a configuration set, comment or delete the
                # following line
                # ConfigurationSetName=self.CONFIGURATION_SET,
            )
        # Display an error if something goes wrong.
        except ClientError as e:
            print(e.response['Error']['Message'])
