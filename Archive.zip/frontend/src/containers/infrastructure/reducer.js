import createReducer from 'redux/helpers/createReducer';

import {
  namespace,
  fetchLzAccountsRequest, fetchLzAccountsSuccess, fetchLzAccountsFailure,
  retrieveLzAccountRequest, retrieveLzAccountSuccess, retrieveLzAccountFailure,
} from './actions';

const defaultState = {
  fetchingInfras: false,
  infras: [],
  retrievingInfraDetails: false,
  accountDetails: null,

  landingZones: [],
}

const reducer = createReducer(namespace, defaultState, {
  [fetchLzAccountsRequest.Type]: (state, action) => ({
    ...state,
    fetchingInfras: true,
    infras: [],
  }),
  [fetchLzAccountsSuccess.Type]: (state, action: { payload: { infras: Array<Object> }}) => ({
    ...state,
    fetchingInfras: false,
    infras: action.payload.infras,
  }),
  [fetchLzAccountsFailure.Type]: (state, action) => ({
    ...state,
    fetchingInfras: false,
  }),
  [retrieveLzAccountRequest.Type]: (state, action) => ({
    ...state,
    retrievingInfraDetails: true,
  }),
  [retrieveLzAccountSuccess.Type]: (state, action: { payload: { accountDetails: {
    id: Number, name: String, accountId: String, resources: Array<Object>,
  } }}) => ({
    ...state,
    retrievingInfraDetails: false,
    accountDetails: action.payload.accountDetails,
  }),
  [retrieveLzAccountFailure.Type]: (state, action) => ({
    ...state,
    retrievingInfraDetails: false,
  }),
});

export default reducer;
export { namespace };
