from typing import List, Optional
from datetime import datetime

from sqlalchemy import UniqueConstraint, and_
from sqlalchemy.dialects.postgresql import insert

from src.utils.model import ModelBase
from src.utils.pgsql import PG_DB_TABLE
from src.utils.constants import PROJECT_STATUS
from src.models.parameters import ParameterEntry, SettingEntry


class ProjectSettingEntry(SettingEntry):
    setting_id: int
    value: str
    updated_at: Optional[datetime]

    def __init__(
        self, setting_id: int, name: str, description: str, value: str,
        id: int = None, updated_at: Optional[datetime] = None
    ) -> None:
        super().__init__(id, name, description)
        self.setting_id = setting_id
        self.value = value
        self.updated_at = updated_at

    def to_dict(self) -> dict:
        return dict(
            setting_id=self.setting_id,
            value=self.value,
            updated_at=self.updated_at,
            **super().to_response()
        )


class ProjectParameterEntry(ParameterEntry):
    parameter_id: int
    updated_at: Optional[datetime]

    def __init__(
        self, parameter_id: int, resource_type: str, expected_variable: str,
        expected_value: str, include: bool, section: str, section_description: str,
        id: int = None, updated_at: Optional[datetime] = None
    ) -> None:
        super().__init__(
            id, resource_type, expected_variable, expected_value,
            include, section, section_description
        )
        self.parameter_id = parameter_id
        self.updated_at = updated_at

    def to_dict(self) -> dict:
        return dict(
            parameter_id=self.parameter_id,
            **super().to_response()
        )


class ProjectEntry:
    qualification_type_id: int
    landing_zone_id: int
    id: int
    name: str
    description: str
    status: str
    created_by: int
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    parameters: List[ProjectParameterEntry]
    settings: List[ProjectSettingEntry]

    def __init__(
        self, qualification_type_id: int, name: str,
        status: str, created_by: int,
        id: int = None,
        description: Optional[str] = None,
        created_at: Optional[datetime] = None,
        updated_at: Optional[datetime] = None,
        landing_zone_id: Optional[int] = None,
    ) -> None:
        self.id = id
        self.qualification_type_id = qualification_type_id
        self.name = name
        self.status = status
        self.created_by = created_by
        self.description = description
        self.created_at = created_at
        self.updated_at = updated_at
        self.landing_zone_id = landing_zone_id

        self.parameters = []
        self.settings = []

    @property
    def setting(self) -> dict:
        return dict([
            (item.name, item.value) for item in self.settings
        ])

    def to_dict(self) -> dict:
        result = {
            'qualification_type_id': self.qualification_type_id,
            'landing_zone_id': self.landing_zone_id,
            'name': self.name,
            'status': self.status,
            'created_by': self.created_by,
            'description': self.description,
        }

        if self.id:
            result.update({
                'id': self.id,
                'created_at': self.created_at,
                'updated_at': self.updated_at,
            })

        if self.settings:
            result['settings'] = [item.to_dict() for item in self.settings]

        if self.parameters:
            result['parameters'] = [item.to_dict() for item in self.parameters]

        return result


class ProjectModel(ModelBase):
    def list_projects(self, page: int = 1, size: int = 30) -> List[ProjectEntry]:
        stmt = PG_DB_TABLE.projects.select().offset(size * (page - 1)).limit(size)
        rows = self.connection.execute(stmt).fetchall()
        return [ProjectEntry(**row) for row in rows]

    def create(
        self, name: str, qualification_type_id: int, landing_zone_id: int,
        created_by: int, settings: List[dict], parameters: List[dict],
        description: str = None, status: str = PROJECT_STATUS.default
    ) -> int:
        project = ProjectEntry(
            qualification_type_id,
            landing_zone_id=landing_zone_id,
            name=name, status=status,
            created_by=created_by,
            description=description
        )
        project_create_stmt = PG_DB_TABLE.projects.insert().values(
            **project.to_dict()).returning(PG_DB_TABLE.projects.c.id)

        @self.db_manager.get_transaction_scope(self.connection)
        def __transaction():
            row = self.connection.execute(project_create_stmt).fetchone()
            project.id = row.id

            setting_objects = [
                ProjectSettingEntry(
                    setting_id=item.pop('id'),
                    **item
                ) for item in settings]

            insert_settings_stmt = PG_DB_TABLE.project_settings.insert().values(
                [{
                    'project_id': project.id,
                    'setting_id': item.setting_id,
                    'value': item.value,
                } for item in setting_objects]
            )
            self.connection.execute(insert_settings_stmt)

            parameter_objects = [
                ProjectParameterEntry(
                    parameter_id=item.pop('id'),
                    **item
                ) for item in parameters]
            insert_parameters_stmt = PG_DB_TABLE.project_parameters.insert().values(
                [{
                    'project_id': project.id,
                    'parameter_id': item.parameter_id,
                    'expected_variable': item.expected_variable,
                    'expected_value': item.expected_value,
                    'include': item.include,
                    'section': item.section,
                    'section_description': item.section_description,
                } for item in parameter_objects]
            )
            self.connection.execute(insert_parameters_stmt)
            return project.id

        return __transaction()

    def get(self, project_id: int) -> Optional[ProjectEntry]:
        stmt = PG_DB_TABLE.projects.select().where(
            PG_DB_TABLE.projects.c.id == project_id
        )
        row = self.connection.execute(stmt).fetchone()
        return ProjectEntry(**row) if row else None

    def get_detail(self, project_id: int) -> ProjectEntry:
        project = self.get(project_id)
        settings_query = f"""
            select
                ps.id, s.id as setting_id,
                s."name" as "name", s.description as description,
                ps.value, ps.updated_at
            from settings s join project_settings ps on s.id = ps.setting_id
            where ps.project_id = {project.id}"""
        rows = self.connection.execute(settings_query).fetchall()
        project.settings = [ProjectSettingEntry(**row) for row in rows]

        parameters_query = f"""
            select
                pp.id, pp.parameter_id, p.resource_type, pp.expected_variable,
                pp.expected_value, pp."include", pp."section",
                pp.section_description, pp.updated_at
            from parameters p join project_parameters pp on p.id = pp.parameter_id
            where pp.project_id = {project.id};"""
        rows = self.connection.execute(parameters_query).fetchall()
        project.parameters = [ProjectParameterEntry(**row) for row in rows]

        return project

    def update_project_settings(self, project_id: int, settings: List[dict]) -> bool:
        settings: List[ProjectSettingEntry] = [ProjectSettingEntry(**item) for item in settings]
        delete_stmt = PG_DB_TABLE.project_settings.delete().where(and_(
            PG_DB_TABLE.project_settings.c.project_id == project_id,
            PG_DB_TABLE.project_settings.c.setting_id.not_in([
                item.setting_id for item in settings
            ])
        ))
        insert_stmt = insert(PG_DB_TABLE.project_settings).values([{
            'project_id': project_id,
            'setting_id': item.setting_id,
            'value': item.value
        } for item in settings])
        update_on_conflict = insert_stmt.on_conflict_do_update(
            constraint=UniqueConstraint(
                PG_DB_TABLE.project_settings.c.project_id,
                PG_DB_TABLE.project_settings.c.setting_id,
            ),
            set_={
                'value': insert_stmt.excluded.value,
                'updated_at': datetime.utcnow(),
            }
        )

        @self.db_manager.get_transaction_scope(self.connection)
        def __transaction():
            self.connection.execute(delete_stmt)
            response = self.connection.execute(update_on_conflict)

            return response.rowcount > 0

        return __transaction()

    def update_project_parameters(self, project_id: int, parameter_id: int, params: dict):
        stmt = PG_DB_TABLE.project_parameters.update().where(and_(
            PG_DB_TABLE.project_parameters.c.project_id == project_id,
            PG_DB_TABLE.project_parameters.c.parameter_id == parameter_id
        )).values(params)

        @self.db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)
            return response.rowcount == 1

        return __transaction()

    def update(self, project_id: int, **kwargs) -> bool:
        permitted_columns = ['name', 'qualification_type_id', 'landing_zone_id', 'settings', 'parameters', ]
        params = dict([
            (attr, value) for attr, value in kwargs.items() if attr in permitted_columns
        ])

        parameters = params.pop('parameters', {})
        status = False
        if parameters:
            for parameter_id, mapping in parameters.items():
                status = self.update_project_parameters(project_id, parameter_id, mapping)

        if not params:
            return status

        settings = params.pop('settings', [])

        stmt = PG_DB_TABLE.projects.update().where(
            PG_DB_TABLE.projects.c.id == project_id
        ).values(**params)

        @self.db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)

            if settings:
                self.update_project_settings(project_id, settings)

            # if parameters:
            #     self.update_project_settings(parameters)

            return response.rowcount == 1

        return __transaction()

    def delete(self, project_id: str):
        stmt = PG_DB_TABLE.projects.delete().where(PG_DB_TABLE.projects.c.id == project_id)

        @self.db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)
            return response.rowcount > 0

        return __transaction()
