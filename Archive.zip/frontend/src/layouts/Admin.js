/*!

=========================================================
* Argon Dashboard PRO React - v1.2.1
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-dashboard-pro-react
* Copyright 2021 Creative Tim (https://www.creative-tim.com)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
import React from "react";
// import classnames from "classnames";

// react library for routing
import {
  useLocation, Route, Switch, Redirect,
  // useHistory
} from "react-router-dom";

import {
  Container, Row, Card, CardBody,
  // CardHeader, Nav, NavItem, NavLink,
} from 'reactstrap';

// core components
import AdminFooter from "components/Footers/AdminFooter.js";
import Sidebar from "components/Sidebar/Sidebar.js";
import AdminHeader from "components/Headers/AdminHeader";

import routes from "routes.js";

function Admin() {
  const [sidenavOpen, setSidenavOpen] = React.useState(true);
  // const history = useHistory()
  const location = useLocation();
  const mainContentRef = React.useRef(null);
  const { pathname } = location;

  const segs = pathname.split('/').filter(item => !!item);
  let selected = 'landing-zone';

  if (segs.length > 1) {
    selected = ['landing-zone', 'projects', 'create', 'jobs'].indexOf(segs[1]) >= 0 ? segs[1] : 'landing-zone';
  }

  React.useEffect(() => {
    document.documentElement.scrollTop = 0;
    document.scrollingElement.scrollTop = 0;
    mainContentRef.current.scrollTop = 0;
  }, [location]);
  const getRoutes = (routes) => {
    return routes.map((prop, key) => {
      if (prop.collapse) {
        return getRoutes(prop.views);
      }
      if (prop.layout === "/admin") {
        return (
          <Route
            path={prop.layout + prop.path}
            component={prop.component}
            key={key}
          />
        );
      } else {
        return null;
      }
    });
  };
  // const getBrandText = (path) => {
  //   for (let i = 0; i < routes.length; i++) {
  //     if (location.pathname.indexOf(routes[i].layout + routes[i].path) !== -1) {
  //       return routes[i].name;
  //     }
  //   }
  //   return "Brand";
  // };
  // toggles collapse between mini sidenav and normal
  const toggleSidenav = (e) => {
    if (document.body.classList.contains("g-sidenav-pinned")) {
      document.body.classList.remove("g-sidenav-pinned");
      document.body.classList.add("g-sidenav-hidden");
    } else {
      document.body.classList.add("g-sidenav-pinned");
      document.body.classList.remove("g-sidenav-hidden");
    }
    setSidenavOpen(!sidenavOpen);
  };
  // const getNavbarTheme = () => {
  //   return location.pathname.indexOf("admin/alternative-dashboard") === -1
  //     ? "dark"
  //     : "light";
  // };

  return (
    <>
      <Sidebar
        routes={routes}
        toggleSidenav={toggleSidenav}
        sidenavOpen={sidenavOpen}
        logo={{
          innerLink: "/",
          imgSrc: require("assets/img/brand/logo.png").default,
          imgAlt: "...",
        }}
      />
      <div className="main-content table-card-effect" ref={mainContentRef}>
        <AdminHeader name={selected} parentName="Qualification" />
        <Container className="mt--6" fluid>
          <Row>
            <div className="col">
              <div className="card-wrapper">
                <Card>
                  {/* <CardHeader>
                    <Nav
                        className="nav-fill flex-column flex-md-row"
                        id="tabs-icons-text"
                        pills
                        role="tablist"
                      >
                      <NavItem>
                        <NavLink
                          aria-selected={selected === 'create'}
                          className={classnames("mb-sm-3 mb-md-0", {
                            active: selected === 'create'
                          })}
                          onClick={() => history.push('/gxp-qualification/create')}
                          href="#pablo"
                          role="tab"
                        >
                          <i className="ni ni-bell-55 mr-2" />
                          Create Job
                        </NavLink>
                      </NavItem>
                      <NavItem>
                        <NavLink
                          aria-selected={selected === 'jobs'}
                          className={classnames("mb-sm-3 mb-md-0", {
                            active: selected === 'jobs'
                          })}
                          onClick={() => history.push('/gxp-qualification/jobs')}
                          href="#pablo"
                          role="tab"
                        >
                          <i className="ni ni-bell-55 mr-2" />
                          View Jobs
                        </NavLink>
                      </NavItem>
                      <NavItem>
                        <NavLink
                          aria-selected={selected === 'dashboard'}
                          className={classnames("mb-sm-3 mb-md-0", {
                            active: selected === 'dashboard'
                          })}
                          onClick={() => history.push('/gxp-qualification/dashboard')}
                          href="#pablo"
                          role="tab"
                        >
                          <i className="ni ni-cloud-upload-96 mr-2" />
                          Dashboard
                        </NavLink>
                      </NavItem>
                      <NavItem>
                        <NavLink
                          aria-selected={selected === 'projects'}
                          className={classnames("mb-sm-3 mb-md-0", {
                            active: selected === 'projects'
                          })}
                          onClick={() => history.push('/gxp-qualification/projects')}
                          href="#pablo"
                          role="tab"
                        >
                          <i className="ni ni-calendar-grid-58 mr-2" />
                          Admin
                        </NavLink>
                      </NavItem>
                    </Nav>
                  </CardHeader> */}
                  <CardBody>
                    <Switch>
                      {getRoutes(routes)}
                      <Redirect from="*" to="/admin/landing-zone" />
                    </Switch>
                  </CardBody>
                </Card>
              </div>
            </div>
          </Row>
          <br />
        </Container>
        <AdminFooter />
      </div>
      {sidenavOpen ? (
        <div className="backdrop d-xl-none" onClick={toggleSidenav} />
      ) : null}
    </>
  );
}

export default Admin;
