export const QUALIFICATION_TYPE_CLOUDENDURE_MIGRATION_FACTORY = 1
export const QUALIFICATION_TYPE_LANDING_ZONE = 2

export const infraResourceTypes = [
    {name: 'S3', value: 's3'},
    {name: 'EC2', value: 'ec2'},
];

export const awsRegions = [
    'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
];

export const InfraOptions = {
  s3: {
    serverSideEncriptionOptions: [
      {name: 'S3-SSE', value: 'AES256'},
      {name: 'AWS KMS', value: 'aws:kms'}
    ],
    predefinedACLs: [
      'None', 'LogDeliveryWrite', 'Private', 'PublicRead', 'PublicReadWrite', 'AuthenticatedRead',
      'AwsExecRead', 'BucketOwnerRead', 'BucketOwnerFullControl',
    ]
  }
};

export const CloudingProviders = [
  'aws', 'gcp', 'azure', 'alibaba',
];

export const AwsServices = [
  's3', 'ec2', 'ebs', 'api gateway', 'iam',
];

export const GcpServices = [
  'vm',
];

export const AzureServices = [
  'storage',
];

export const AlibabaServices = [
  'vpc',
]

export const CloudServices = {
  aws: AwsServices,
  gcp: GcpServices,
  azure: AzureServices,
  alibab: AlibabaServices,
};

export const ComplianceStandards = [
  'FedRAMP', 'CMMC', 'HIPAA',
]