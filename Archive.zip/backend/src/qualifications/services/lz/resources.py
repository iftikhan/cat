from src.models.jobs import JobEntry
import boto3
from typing import Dict, List, Tuple

from src.config import settings
from src.utils.logger import Logger
from src.utils.aws.root import Organization, AwsRoot, AwsAccount
from src.utils.aws.s3 import S3Util
from src.utils.aws.ec2 import EC2
from src.models.parameters import ParameterEntry
from src.qualifications.services.core import ResourceCollectorBase
from src.qualifications.services.lz.entires import LandingZoneEntry


class LandingZoneResourceCollector(ResourceCollectorBase):
    def __init__(self) -> None:
        self.__s3_util = S3Util()

        self.__logger = Logger()
        self.__root_helper = Organization()
        self.__ec2_helper = EC2()

    def get_header(self, account_id: str, root_id: str, job_id: int, created_by: str):
        return {
            'Source': 'LZ_EXCEL',
            'RootId': root_id,
            'RunNumber': job_id,
            'AccountNumber': account_id,
            'CreatedBy': created_by,
            'ApplicationName': 'AWS Control Tower',
            'Criticality': 'SOFY score: 100'
        }

    def make_input_json(
        self, entries: List[LandingZoneEntry], supported_resources: List[str]
    ) -> Dict[str, Dict[str, Dict[str, Dict[str, Dict[str, Dict[str, List[LandingZoneEntry]]]]]]]:
        self.__logger.log_info("NOTE: Parsing Expected Value Input JSON and creating hierarchial output")
        response = {}

        for entry in entries:
            if entry.resource_type.lower() not in supported_resources:
                continue

            if entry.account_number not in response:
                response[entry.account_number] = {}

            current_account = response[entry.account_number]

            if entry.role_name not in current_account:
                current_account[entry.role_name] = {}

            current_role = current_account[entry.role_name]

            if entry.region not in current_role:
                current_role[entry.region] = {}

            current_region = current_role[entry.region]
            if entry.app_id not in current_region:
                current_region[entry.app_id] = {}

            current_app = current_region[entry.app_id]
            if entry.resource_type not in current_app:
                current_app[entry.resource_type] = {}

            current_resource_type = current_app[entry.resource_type]
            if entry.resource_id not in current_resource_type:
                current_resource_type[entry.resource_id] = []

            current_resource_type[entry.resource_id].append(entry)
        return response

    def run_resource_collector(
        self, job: JobEntry, entries: List[LandingZoneEntry], parameters: List[ParameterEntry],
        expected_build_source, output_folder_name,
        supported_resources, master_account_number
    ) -> Tuple[List[str], List[Dict]]:

        # Step 1 - Parse input XLSX file and make a hierarchical expected value JSON File
        grouped_entries = self.make_input_json(entries, supported_resources)

        output_files = []
        results = []

        # Step 3 - Run the report for every Account/Region combination
        for account_number, roles in grouped_entries.items():
            self.__logger.log_info(f'Checking for {account_number} account...')

            for role_name, regions in roles.items():
                self.__logger.log_info(f'Checking with {role_name} role...')

                # if Account ID is missing, then launch LZ qualification for Root, OU, Account
                for region, apps in regions.items():
                    self.__logger.log_info(f'Checking in {region} region...')

                    for app_id, resource_types in apps.items():
                        self.__logger.log_info(f'Checking {app_id} app...')

                        final_output = {}
                        all_resources = []
                        all_build_spec = []
                        all_post_build_spec = []
                        test_summary = []

                        expected_org_units = resource_types.get('ou', {}).keys()
                        expected_accounts = resource_types.get('account', {}).keys()

                        root = self.__root_helper.get_all_provisions(
                            master_account_number, role_name,
                            expected_org_units=expected_org_units,
                            expected_accounts=expected_accounts)

                        accounts: List[AwsAccount] = []
                        if expected_accounts:
                            # Retrieve account details only when we need to check account
                            for org in root.organizational_units:
                                for acc in org.accounts:
                                    acc.regions = self.get_account_details(
                                        acc.account_id, role_name)
                                    accounts.append(acc)

                        for resource_type, resource_ids in resource_types.items():

                            ##############################################################
                            #           Qualify Root                 ##########
                            ##############################################################
                            if resource_type.lower() == "root":
                                root_sort_number = 0
                                root_build_specs, root_post_specs = self.get_root_spec_metadata(
                                    root_sort_number, root, expected_build_source,
                                    resource_ids, parameters)

                                all_resources.append(root.resource_metadata)
                                for all_build_spec_root in root_build_specs:
                                    all_build_spec.append(dict(all_build_spec_root).copy())
                                for all_post_build_spec_root in root_post_specs:
                                    all_post_build_spec.append(dict(all_post_build_spec_root).copy())

                            ##########################################################
                            #            Qualify OU                 ##########
                            ##############################################################
                            elif resource_type.lower() == "ou":
                                org_unit_sort_num = 1
                                ou_build_specs, ou_post_build_specs = self.get_org_unit_spec_metadata(
                                    root, resource_ids, parameters,
                                    org_unit_sort_num, expected_build_source)

                                for idx, org in enumerate(root.organizational_units):
                                    all_resources.append(org.get_resource_metadata(org_unit_sort_num, idx))
                                for all_build_spec_ou in ou_build_specs:
                                    all_build_spec.append(dict(all_build_spec_ou).copy())
                                for all_post_build_spec_ou in ou_post_build_specs:
                                    all_post_build_spec.append(dict(all_post_build_spec_ou).copy())

                            ##############################################################
                            #            Qualify Account              ##########
                            ##############################################################
                            elif resource_type.lower() == "account":
                                account_sort_num = 2
                                build_specs, build_post_specs = self.get_account_spec_metadata(
                                    accounts, resource_ids, parameters,
                                    expected_build_source, account_sort_num,)

                                for idx, account in enumerate(accounts):
                                    if account.account_id not in resource_ids:
                                        continue

                                    all_resources.append(account.get_resource_metadata(account_sort_num, idx))
                                for all_build_spec_account in build_specs:
                                    all_build_spec.append(dict(all_build_spec_account).copy())
                                for all_post_build_spec_account in build_post_specs:
                                    all_post_build_spec.append(dict(all_post_build_spec_account).copy())

                        # Get CreatedBy
                        username = None
                        current_account = None
                        try:
                            iam = boto3.client('iam')
                            username = iam.get_user()["User"]["UserName"]
                        except iam.exceptions.ClientError as e:
                            username = e.response["Error"]["Message"].split(" ")[-1]

                        current_account = boto3.client('sts').get_caller_identity().get('Account')
                        CreatedBy = f'{username}@{current_account}'
                        header = self.get_header(master_account_number, root.id, job.id, CreatedBy)

                        # Create Test Summary
                        test_summary = self.make_test_summary(all_build_spec, all_post_build_spec)

                        # Sort All Resources
                        all_resources = sorted(all_resources, key=lambda k: (k["Sort"], k["SubSort"]))
                        all_build_spec = sorted(all_build_spec, key=lambda k: (k["Sort"], k["SubSort"]))
                        all_post_build_spec = sorted(all_post_build_spec, key=lambda k: (k["Sort"], k["SubSort"]))

                        # Step 5 - Create Final Output
                        final_output = header
                        final_output["Resources"] = all_resources
                        final_output["build_spec"] = all_build_spec
                        final_output["post_build_spec"] = all_post_build_spec
                        final_output["test_summary"] = test_summary

                        # Upload final_output to S3 Bucket
                        output_file_name = f"LZ-Qualification-Run-{job.id}.json"
                        self.__s3_util.upload_dict_object_to_s3(
                            final_output, settings.STORAGE_BUCKET, output_folder_name, output_file_name)

                        output_files.append(f'{output_folder_name}/{output_file_name}')
                        results.append(final_output)

            return output_files, results

    def get_root_spec_metadata(
        self, root_sort_number: int, root: AwsRoot,
        expected_build_source: str,
        resource_ids: Dict[str, List[LandingZoneEntry]], parameters: List[ParameterEntry]
    ):
        self.__logger.log_info("NOTE: Printing Root Build Specifications")

        print_all_root_build_spec = []
        print_all_root_post_build_spec = []

        # Step 2.1 Get all expected values from DynamoDB
        all_root_expected_varval = []

        # Repeat Config Parameters from DynamoDB for every OU. Put expected values from DynamodB/XLSX.
        for resource_id, entries in resource_ids.items():
            for parameter in parameters:
                if parameter.resource_type.lower() == "root":
                    all_root_expected_varval_dic = {
                        'ResourceName': root.id,
                        'ResourceType': parameter.resource_type,
                        'ExpectedVariable': parameter.expected_variable,
                        'ExpectedValue': parameter.expected_value,
                        'Section': parameter.section,
                        'SectionDescription': parameter.section_description,
                    }

                    # If expected value is defined in XLSX then use that one.
                    for entry in entries:
                        if entry.expected_variable.lower() == parameter.expected_variable.lower():
                            all_root_expected_varval_dic["ExpectedValue"] = entry.expected_value

                    all_root_expected_varval.append(all_root_expected_varval_dic)

        # Match Expected Values with Actual Values. Determine Pass/Fail
        root_build_spec, root_post_build_spec = self.__root_helper.make_spec(
            [root.metadata], all_root_expected_varval)

        for index, expected_ou_list in enumerate(resource_ids.values()):

            if len(root_build_spec) > 0:
                print_root_build_spec = {
                    'Sort': root_sort_number,
                    'SubSort': index,
                    'ResourceType': "Root Account",
                    'ResourceName': f'{root.id}@{root.account.account_id}',
                    'ExpectedBuildSource': expected_build_source,
                    'Spec': root_build_spec,
                }

                print_all_root_build_spec.append(print_root_build_spec)

            if len(root_post_build_spec) > 0:
                print_root_post_build_spec = {
                    'Sort': root_sort_number,
                    'SubSort': index,
                    'ResourceType': "Root Account",
                    'ResourceName': f'{root.id}@{root.account.account_id}',
                    'ExpectedPostBuildSource': 'Project Configuration Settings for AutoGxP',
                    'Spec': root_post_build_spec,
                }

                print_all_root_post_build_spec.append(print_root_post_build_spec)

        return print_all_root_build_spec, print_all_root_post_build_spec

    def get_org_unit_spec_metadata(
        self, root: AwsRoot, expected_ou_details: Dict[str, List[LandingZoneEntry]],
        parameters: List[ParameterEntry], ou_sort_num: int, expected_build_source: str,
    ):
        self.__logger.log_info("NOTE: Printing OU Build Specifications")
        print_all_ou_build_spec = []
        print_all_ou_post_build_spec = []

        # Step 2.1 Get all expected values from DynamoDB
        all_ou_expected_varval = []

        # Repeat Config Parameters from DynamoDB for every OU. Put expected values from DynamodB/XLSX.
        for resource_id, entries in expected_ou_details.items():
            for parameter in parameters:
                if parameter.resource_type.lower() != "ou":
                    continue

                all_ou_expected_varval_dic = {
                    'ResourceName': resource_id,
                    'ResourceType': parameter.resource_type,
                    'ExpectedVariable': parameter.expected_variable,
                    'ExpectedValue': parameter.expected_value,
                    'Section': parameter.section,
                    'SectionDescription': parameter.section_description,
                }

                for entry in entries:
                    if entry.expected_variable.lower() == parameter.expected_variable.lower():
                        all_ou_expected_varval_dic["ExpectedValue"] = entry.expected_value

                all_ou_expected_varval.append(all_ou_expected_varval_dic)

        # Match Expected Values with Actual Values. Determine Pass/Fail
        ou_build_spec, ou_post_build_spec = self.__root_helper.make_spec(
            [ou.metadata for ou in root.organizational_units], all_ou_expected_varval)

        for index, resource_id in enumerate(expected_ou_details.keys()):

            if len(ou_build_spec) > 0:
                print_all_ou_build_spec.append({
                    'Sort': ou_sort_num,
                    'SubSort': index,
                    'ResourceType': "Organization Unit",
                    'ResourceName': resource_id,
                    'ExpectedBuildSource': expected_build_source,
                    'Spec': [
                        x for x in ou_build_spec
                        if x['ResourceName'] == resource_id]
                })

            if len(ou_post_build_spec) > 0:
                print_all_ou_post_build_spec.append({
                    'Sort': ou_sort_num,
                    'SubSort': index,
                    'ResourceType': "Organization Unit",
                    'ResourceName': resource_id,
                    'ExpectedPostBuildSource': 'Project Configuration Settings for AutoGxP',
                    'Spec': [
                        x for x in ou_post_build_spec if x['ResourceName'] == resource_id]
                })

        return print_all_ou_build_spec, print_all_ou_post_build_spec

    def get_account_spec_metadata(
        self,
        accounts: List[AwsAccount], account_ids: Dict[str, List[LandingZoneEntry]],
        parameters: List[ParameterEntry], expected_build_source: str, sort_num: int,
    ):
        self.__logger.log_info("NOTE: Printing Account Build Specifications")

        expected_postbuild_source = 'RDS Postgres'
        build_specs = []
        post_build_specs = []

        all_account_expected_varval = []

        # Repeat Config Parameters from DynamoDB for every Account. Put expected values from DynamodB/XLSX.
        for account_id, entries in account_ids.items():
            for parameter in parameters:
                if parameter.resource_type.lower() == "account":
                    all_account_expected_varval_dic = {
                        'ResourceName': account_id,
                        'ResourceType': parameter.resource_type,
                        'ExpectedVariable': parameter.expected_variable,
                        'ExpectedValue': parameter.expected_value,
                        'Section': parameter.section,
                        'SectionDescription': parameter.section_description,
                    }

                    # If expected value is defined in XLSX then use that one.
                    for entry in entries:
                        if entry.expected_variable.lower() == parameter.expected_variable.lower():
                            all_account_expected_varval_dic["ExpectedValue"] = entry.expected_value

                    all_account_expected_varval.append(all_account_expected_varval_dic)

        # Match Expected Values with Actual Values. Determine Pass/Fail
        account_build_spec, account_post_build_spec = self.__ec2_helper.make_spec(
            [acc.metadata for acc in accounts if acc.account_id in account_ids],
            all_account_expected_varval)

        for index, account_id in enumerate(account_ids.keys()):
            if len(account_build_spec) > 0:
                print_account_build_spec = {}
                print_account_build_spec["Sort"] = sort_num
                print_account_build_spec["SubSort"] = index
                print_account_build_spec["ResourceType"] = "Account"
                print_account_build_spec["ResourceName"] = account_id
                print_account_build_spec["ExpectedBuildSource"] = expected_build_source
                print_account_build_spec["Spec"] = [
                    x for x in account_build_spec
                    if x['ResourceName'] == account_id]
                build_specs.append(dict(print_account_build_spec).copy())

            if len(account_post_build_spec) > 0:
                print_account_post_build_spec = {}
                print_account_post_build_spec["Sort"] = sort_num
                print_account_post_build_spec["SubSort"] = index
                print_account_post_build_spec["ResourceType"] = "Account"
                print_account_post_build_spec["ResourceName"] = account_id
                print_account_post_build_spec["ExpectedPostBuildSource"] = expected_postbuild_source
                print_account_post_build_spec["Spec"] = [
                    x for x in account_post_build_spec
                    if x['ResourceName'] == account_id]
                post_build_specs.append(dict(print_account_post_build_spec).copy())

        return build_specs, post_build_specs

    def get_account_details(self, account_id: str, cross_account_role: str, region_name: str = None):
        self.__logger.log_info(f"NOTE: Retrieving details of account {account_id}...")

        return self.__ec2_helper.get_regions(account_id, cross_account_role, with_details=True)
