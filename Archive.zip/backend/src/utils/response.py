import json
import decimal
from datetime import datetime
from uuid import UUID

from src.utils.constants import DATETIME_FORMAT


class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, decimal.Decimal):
            return int(obj)

        if isinstance(obj, datetime):
            return obj.strftime(DATETIME_FORMAT)

        if isinstance(obj, UUID):
            return str(obj)

        return super(DecimalEncoder, self).default(obj)


def build_response(body: dict, status_code: int = 200) -> dict:
    return {
        'statusCode': status_code,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': True,
        },
        'body': json.dumps(body, cls=DecimalEncoder, indent=2)
    }
