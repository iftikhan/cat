import React from 'react';
import PropTypes from 'prop-types';

import ResourceDetails from './ResourceDetails';
import SummaryTable from './SummaryTable'

const LandingZoneInfo = ({
  data, createdAt,
}) => {
  const {
    ApplicationName: applicationName,
    Criticality: criticality,
    RunNumber: runNumber,
    CreatedBy: createdBy,
    Resources: resources,
    test_summary: testSummary,
  } = data;
  return (
    <>
      <h4>Landing Zone Information</h4>
      <table className='table'>
        <tbody>
          <tr>
            <td>Application Name</td>
            <td>{applicationName}</td>
          </tr>
          <tr>
            <td>Criticality</td>
            <td>{criticality}</td>
          </tr>
          <tr>
            <td>Run Number</td>
            <td>{runNumber}</td>
          </tr>
          <tr>
            <td>Report Created By</td>
            <td>{createdBy}</td>
          </tr>
          <tr>
            <td>Created Data</td>
            <td>{createdAt}</td>
          </tr>
        </tbody>
      </table>
      <hr />
      <br />

      {testSummary &&
        <SummaryTable testSummary={testSummary} />}

      {resources.length > 0 && (
        <>
          <br />
          <ResourceDetails
            title={'Landing Zone Resource Details'}
            records={resources} />
          <br />
          <hr />
        </>
      )}
    </>
  )
}

LandingZoneInfo.propTypes = {
  data: PropTypes.shape({
    ApplicationName: PropTypes.string.isRequired,
    Criticality: PropTypes.string.isRequired,
    RunNumber: PropTypes.number.isRequired,
    CreatedBy: PropTypes.string.isRequired,
    Resources: PropTypes.arrayOf(PropTypes.object).isRequired,
  }).isRequired,
  createdAt: PropTypes.string.isRequired,
}

export default LandingZoneInfo;
