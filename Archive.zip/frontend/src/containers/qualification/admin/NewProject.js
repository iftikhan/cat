import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import classnames from 'classnames';

import {
  Row, Col, FormGroup, Button, Input,
  Card, CardHeader, CardBody,
} from 'reactstrap';
import cellEditFactory from 'react-bootstrap-table2-editor';

import API from 'helpers/api';

import {
  setProjectDraft, fetchParameterRequest,
} from 'containers/qualification/actions';
import SearchTable from 'components/tables/SearchTable';

const NewProject = ({
  projectDraft, setProjectDraft, fetchingParameter,
  fetchParameterRequest, parameters, qualificationTypes,
  landingZones,
}) => {
  const [projectName, setProjectName] = useState('');
  const [qualificationType, setQualificationType] = useState(null);
  const [selectedLandingZone, setSelectedLandingZone] = useState('');
  const [projectSettings, setProjectSettings] = useState([]);
  const [projectParameters, setProjectParameters] = useState([]);
  const history = useHistory();

  useEffect(() => {
    fetchParameterRequest()
  }, [fetchParameterRequest]);

  useEffect(() => {
    setQualificationType(qualificationTypes[0])
  }, [qualificationTypes, setQualificationType]);

  useEffect(() => {
    setProjectSettings(qualificationType?.settings || []);
  }, [qualificationType, setProjectSettings]);

  useEffect(() => {
    setProjectParameters(parameters);
  }, [parameters, setProjectParameters]);

  useEffect(() => {
    if (landingZones.length > 0) {
      const [first] = landingZones;
      setSelectedLandingZone(first.id);
    }
  }, [landingZones, setSelectedLandingZone]);

  const onSelectQualificationType = (qualificationTypeId: Number) => {
    const [selected] = qualificationTypes.filter(item => item.id === parseInt(qualificationTypeId));
    if (selected) {
      setQualificationType(selected);
    }
  }

  const onChangeSettingValue = (settingId: Number, value: String) => {
    setProjectSettings(projectSettings.map(setting => (
      setting.id === settingId ? {...setting, value: value} : setting))
    )
  }

  const onChangeParameterValue = (parameterId: Number, attr: String, value: any) => {
    setProjectParameters(
      projectParameters.map(item => item.id === parameterId ? {...item, [attr]: value} : item)
    )
  }

  const columns = [
    {
      dataField: 'resource_type',
      text: 'Resource Type',
      // filter: textFilter(),
      headerStyle: {width: '140px'},
      editable: false,
    }, {
      dataField: 'expected_variable',
      text: 'Expected Variable',
      // filter: textFilter(),
      // headerStyle: {width: '120px'},
      editable: true,
    }, {
      dataField: 'expected_value',
      text: 'Expected Value',
      // filter: textFilter(),
      headerStyle: {width: '120px'},
      editable: true,
    }, {
      dataField: 'include',
      text: 'Include',
      // filter: textFilter(),
      headerStyle: {width: '80px'},
      editable: false,
      formatter: (cel, row, rowIndex) => {
        return (
          <select
            defaultValue={row.include ? '1' : '0'}
            onChange={(event) => onChangeParameterValue(row.id, 'include', !!parseInt(event.target.value))}
          >
            <option value='1'>True</option>
            <option value='0'>False</option>
          </select>
        )
      },
    }, {
      dataField: 'section',
      text: 'Section',
      // filter: textFilter(),
      headerStyle: {width: '120px'},
      editable: true,
    }, {
      dataField: 'section_description',
      text: 'Description',
      // filter: textFilter(),
      editable: true,
    },
  ];

  const afterSaveCell = (oldValue, newValue, row, column) => {
    console.log(row.id, column.dataField, newValue);
  }

  const onCreate = () => {
    API.createProject(
      projectName, qualificationType.id, selectedLandingZone,
      projectSettings, projectParameters
    ).then(() => {
      history.push('/gxp-qualification/admin');
    }).catch(() => {
      alert('Something went wrong!');
    })
  }

  return (
    <>
      <FormGroup className="mb-3" disabled={fetchingParameter}>
        <Row>
          <Col sm="3" xs={6}>
            <label className='mt-2'>Project Name</label>
          </Col>
          <Col sm="5" xs={6}>
            <Input
              type='text'
              value={projectName}
              onChange={e => setProjectName(e.target.value)} />
          </Col>
        </Row>
      </FormGroup>
      <FormGroup className="mb-3" disabled={fetchingParameter}>
        <Row>
          <Col sm="3" xs={6}>
            <label className='mt-2'>Qualification Type</label>
          </Col>
          <Col sm="5" xs={6}>
            <Input
              type="select" value={qualificationType?.id || ''}
              onChange={e => onSelectQualificationType(e.target.value)}>
              {qualificationTypes.map(({id, name}, idx) => (
                <option key={idx} value={id}>{name}</option>
              ))}
            </Input>
          </Col>
        </Row>
      </FormGroup>
      <hr />

      <Card>
        <CardHeader>Project Settings - {qualificationType?.name}</CardHeader>
        <CardBody>
          <FormGroup className="mb-3">
            <Row>
              <Col sm="3" xs={6}>
                <label className='mt-2'>Landing Zone</label>
              </Col>
              <Col sm="5" xs={6}>
                <Input
                  type='select'
                  value={selectedLandingZone}
                  onChange={e => setSelectedLandingZone(e.target.value)}>
                  {landingZones.map(({id, name}, idx) => (
                    <option key={idx} value={id}>{name}</option>
                  ))}
                </Input>
              </Col>
            </Row>
          </FormGroup>
          {projectSettings.length > 0 && (
          <>
            <hr />
            {projectSettings.map(({id, name, description, value}, idx) => (
              <FormGroup className="mb-3" key={idx} disabled={fetchingParameter}>
                <Row>
                  <Col sm="3" xs={6}>
                    <label className='mt-2'>{description}</label>
                  </Col>
                  <Col sm="5" xs={6}>
                    <Input
                      type='text'
                      value={value || ''}
                      onChange={e => onChangeSettingValue(id, e.target.value)} />
                  </Col>
                </Row>
              </FormGroup>
            ))}
          </>)}
        </CardBody>
      </Card>

      {projectParameters && (<Card>
        <CardHeader>Project Configuration</CardHeader>
        <CardBody>
          <SearchTable
            keyField='id' data={projectParameters} columns={columns}
            noDataIndication={'No parameter.'}
            cellEdit={ cellEditFactory({ mode: 'click', afterSaveCell }) }
            />
        </CardBody>
      </Card>)}
      <Row>
        <Col>
          <Button
            color="primary" className={classnames('float-right')} onClick={onCreate}>
            Create now
          </Button>
        </Col>
      </Row>
      <br />
    </>
  )
};

NewProject.propTypes = {
  projectDraft: PropTypes.object.isRequired,
  setProjectDraft: PropTypes.func.isRequired,
  fetchingParameter: PropTypes.bool.isRequired,
  parameters: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number.isRequired,
    expected_variable: PropTypes.string.isRequired,
    expected_value: PropTypes.string.isRequired,
    include: PropTypes.bool.isRequired,
    resource_type: PropTypes.string.isRequired,
    section: PropTypes.string.isRequired,
    section_description: PropTypes.string.isRequired,
  })),
  qualificationTypes: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
    description: PropTypes.string,
    settings: PropTypes.arrayOf(PropTypes.shape({
      id: PropTypes.number.isRequired,
      name: PropTypes.string.isRequired,
      description: PropTypes.string,
    }))
  }))
};

const mapStateToProps = state => ({
  projectDraft: state.qualifications.projectDraft,
  parameters: state.qualifications.parameters,
  qualificationTypes: state.qualifications.qualificationTypes,
  landingZones: state.qualifications.landingZones,
  fetchingParameter: state.qualifications.fetchingParameter,
});

const mapDispatchToProps = dispatch => ({
  setProjectDraft: payload => dispatch(setProjectDraft(payload)),
  fetchParameterRequest: () => dispatch(fetchParameterRequest()),
});

NewProject.propTypes = {
  landingZones: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
  })).isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(NewProject);
