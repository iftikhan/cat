import re
from typing import Dict, List, Tuple
from copy import deepcopy

from src.utils.aws.ec2 import EC2, Ec2Reservation
from src.utils.aws.common import RESOURCE_TYPE
from src.qualifications.services.cemf.api import CemfProject
from src.qualifications.services.cemf.entries import Application
from src.models.parameters import ParameterEntry


class CemfEc2(EC2):
    def create_spec(self, actual_values: Dict[str, str], expected_values: List[Dict[str, str]]):
        self.log_info("NOTE: Printing Build/Post-Build Specifications")
        all_build_spec = []
        all_post_build_spec = []

        actual_val = deepcopy(dict(actual_values))
        expected_val = deepcopy(expected_values)

        # Convert Expected True/False values coming from DynamoDB from String to Boolean
        for item in expected_val:
            if item.get('ExpectedValue', '').lower() == 'true':
                item['ExpectedValue'] = True
            elif item.get('ExpectedValue', '').lower() == 'false':
                item['ExpectedValue'] = False

        # Make Special Arrangement for EBS. In DynamoDB EBS Expected Values are written just once
        # but there can be multiple EBS volumes
        # Therefore, for every EBS parameter that is checked in DynamoDB, repeat that DynamoDB expected value
        # with VolumeID appended
        # Also append the volume id for that paraneter in Actual Value
        # For example - If DynamoDB checks - Ebs_Encrypted = True and there are 2 volumes
        # with Ebs_Encrypted true & false respectively. Then do the following -
        # Make Ebs_Encrypted: Volume1 = True and Ebs_Encrypted: Volume2 = True and append it to Expected Values
        # Make Ebs_Encrypted: Volume1 = True and Ebs_Encrypted: Volume2 = False and append it to Actual Values
        for all_expected in expected_val:
            if all_expected.get("ResourceType", '').lower() == "ebs":
                for actual_ebs in actual_val.get('BlockDeviceMappings', []):
                    if str(actual_ebs.get(all_expected.get('ExpectedVariable', ''))) != "":
                        additional_ebs_expected = {}
                        device_name = actual_ebs.get("DeviceName")
                        additional_ebs_expected['ResourceType'] = 'EC2'
                        additional_ebs_expected['ExpectedVariable'] = all_expected['ExpectedVariable'] +\
                            ': ' + device_name
                        additional_ebs_expected['ExpectedValue'] = all_expected['ExpectedValue']
                        additional_ebs_expected['Section'] = all_expected['Section']
                        additional_ebs_expected['SectionDescription'] = all_expected['SectionDescription']
                        expected_val.append(dict(additional_ebs_expected).copy())

                        actual_val[f"{all_expected['ExpectedVariable']}: {device_name}"] = actual_ebs.get(
                            all_expected.get('ExpectedVariable', ''))

        # Bring out all EBS Sizes from BlockDeviceMappings in Actual Values to outside
        for actual_ebs in actual_val.get('BlockDeviceMappings', []):
            actual_val[f"Ebs_Size: {actual_ebs.get('DeviceName')}"] = actual_ebs.get("Ebs_Size")

        # Rename Expected Disk Names in Expected Values with Actual Disk Names (Match using Sequential ID)
        for expected_ebs in expected_val:
            if expected_ebs.get("ExpectedVariable", '')[0:8].upper() == "EBS_SIZE":
                variable_name = expected_ebs.get("ExpectedVariable")
                if re.search(r'\d+?', variable_name):
                    disk_no = int(re.search(r'\d+?', variable_name).group())
                else:
                    disk_no = 1
                try:
                    expected_ebs['ResourceType'] = 'EC2'
                    expected_ebs["ExpectedVariable"] =\
                        f"Ebs_Size: {actual_val.get('BlockDeviceMappings')[disk_no - 1]['DeviceName']}"
                except IndexError:
                    pass

        # Since EBS parameters have been renamed, pop the original EBS parameters
        expected_val = [e for e in expected_val if e.get('ResourceType', '').lower() != 'ebs']

        for expected in expected_val:
            build_spec = {}
            post_build_spec = {}
            expected_variable = expected.get("ExpectedVariable", '').lower()

            # Make Special Arrangement for Tags
            if expected_variable.startswith('tag:'):
                tag_value = actual_val.get(expected['ExpectedVariable'], '')
                expected["SectionDescription"] = " ".join(expected["SectionDescription"].replace(
                    "with Value:{Value}", f"with Value: {tag_value}" if tag_value != "" else "").split())
                if expected['ExpectedVariable'] in actual_val.keys():
                    actual_val[expected['ExpectedVariable']] = expected.get("ExpectedValue")
                else:
                    actual_val[expected['ExpectedVariable']] = f'Not {expected.get("ExpectedValue")}'

            # Make Special Arrangement for SecurityGroups
            elif expected_variable == "securitygroups":
                if expected['ExpectedVariable'] in actual_val.keys():
                    actual_sg_ids = ""
                    for sg in actual_val.get(expected['ExpectedVariable'], []):
                        actual_sg_ids = actual_sg_ids + "," + sg.get("GroupId")
                    actual_sg_ids = actual_sg_ids[1:]
                    actual_sg_ids = ",".join(sorted(actual_sg_ids.split(',')))
                    expected_sg_ids = expected.get("ExpectedValue", '').replace(" ", "").replace(";", ",")
                    expected_sg_ids = ",".join(sorted(expected_sg_ids.split(',')))

                    actual_val[expected['ExpectedVariable']] = actual_sg_ids
                    expected["ExpectedValue"] = expected_sg_ids

            # Make Special Arrangement for PublicIPAddress
            elif expected_variable == "publicipaddress":
                if expected.get("ExpectedVariable") in actual_val:
                    if actual_val.get(expected['ExpectedVariable']) == "":
                        actual_val[expected['ExpectedVariable']] = True
                    else:
                        actual_val[expected['ExpectedVariable']] = False

            if expected["Section"].lower() == "build":
                build_spec["Parameter"] = expected['ExpectedVariable']
                build_spec["ExpectedValue"] = expected['ExpectedValue']
                build_spec["ActualValue"] = actual_val.get(expected['ExpectedVariable'])
                build_spec["Drift"] = (build_spec["ExpectedValue"] != build_spec["ActualValue"])

                all_build_spec.append(dict(build_spec).copy())

            elif expected["Section"].lower() == "post-build":
                post_build_spec["Parameter"] = expected['ExpectedVariable']
                post_build_spec["SectionDescription"] = expected['SectionDescription']
                post_build_spec["ExpectedValue"] = expected['ExpectedValue']
                post_build_spec["ActualValue"] = actual_val.get(expected['ExpectedVariable'])
                post_build_spec["Drift"] = (post_build_spec["ExpectedValue"] != post_build_spec["ActualValue"])

                all_post_build_spec.append(dict(post_build_spec).copy())

        return all_build_spec, all_post_build_spec

    def make_all_cemf_ec2_resource_metadata(
        self, account_id: str, wave_id: str, applications: Tuple[Application], reservations: List[Ec2Reservation]
    ) -> List[dict]:
        ec2_raw_instances = []
        reservation_dictionary = dict([(item.name, item.instances) for item in reservations])
        for app in applications:
            for project in app.projects:
                for server in project.servers:
                    if server.name in reservation_dictionary:
                        for instance in reservation_dictionary[server.name]:
                            ec2_raw_instances.append({
                                'Server Name': server.name,
                                'Server OS': server.os,
                                'Server FQDN': server.fqdn,
                                'Account ID': account_id,
                                'Wave ID': wave_id,
                                'App ID': app.name,
                                'Project ID': project.name,
                                # 'instances': reservation_dictionary[server.name],
                                **instance.to_dict(),
                            })
                    else:
                        ec2_raw_instances.append({
                            'Server Name': server.name,
                            'Server OS': server.os,
                            'Server FQDN': server.fqdn,
                            'Account ID': account_id,
                            'Wave ID': wave_id,
                            'App ID': app.name,
                            'Project ID': project.name,
                            # 'instances': [],
                            'Sever Existence': 'Server Not Found'
                        })
                        self.log_info(f"NOTE: Expected Server Not Found {server.name} in Account({account_id})")

        return ec2_raw_instances

    def print_cemf_ec2_resource_metadata(self, ec2_instances: List[dict]):
        ec2_resources = []
        for ec2 in ec2_instances:
            self.log_info(f"NOTE: Printing EC2 Resource Metadata for Server: {ec2.get('Server Name')}")
            ec2_resources.append({
                'ResourceName': ec2.get("Server Name"),
                'ResourceOS': ec2.get("Server OS"),
                'ResourceType': RESOURCE_TYPE.ec2_instance,
                'Metadata': ec2.copy()
            })

        return ec2_resources

    def print_cemf_ec2_spec_metadata(
        self,
        account_id, wave_id, ec2_instances: List[dict], applications: Tuple[Application],
        parameters: List[ParameterEntry], expected_val_source
    ):
        self.log_info("NOTE: Printing CEMF EC2 Build & Post Build Specifications")

        print_all_root_build_spec = []
        print_all_root_post_build_spec = []

        # Step 5 - Loop through expected values of Input CSV JSON file and match them with Raw Resource Metadata.
        # Determine Pass/Fail
        for app in applications:
            for project in app.projects:
                for server in project.servers:
                    # Update Server Details - Add all Expected Variables from DynamoDB Table
                    server_expected_val = []

                    for parameter in parameters:
                        if parameter.resource_type in ['EC2', 'EBS']:

                            server_expected_var_info = {}

                            # Make Special provision for Ebs_Size expected Valued:
                            if not parameter.expected_variable.lower().startswith('ebs_size'):
                                server_expected_var_info.update({
                                    "ResourceType": parameter.resource_type,
                                    "ExpectedVariable": parameter.expected_variable,
                                    "ExpectedValue": parameter.expected_value,
                                    "Section": parameter.section,
                                    "SectionDescription": parameter.section_description,
                                })
                                server_expected_val.append(dict(server_expected_var_info).copy())

                            else:
                                for setting in server.settings:
                                    if setting.variable.lower().startswith("ebs_size"):
                                        server_expected_var_info.update({
                                            "ResourceType": parameter.resource_type,
                                            "ExpectedVariable": setting.variable,
                                            "ExpectedValue": setting.value,
                                            "Section": parameter.section,
                                            "SectionDescription": parameter.section_description,
                                        })
                                        server_expected_val.append(dict(server_expected_var_info).copy())

                    # Update Server Details - Add values of Expected Variables specified from CMEF CSV File
                    for setting in server.settings:
                        for all_expected_var in server_expected_val:
                            if all_expected_var.get("ExpectedVariable") == setting.variable:
                                all_expected_var["ExpectedValue"] = setting.value

                    cemf_ec2_found = False

                    for actual_server in ec2_instances:
                        if server.name == actual_server.get("Server Name") and\
                                account_id == actual_server.get("Account ID") and\
                                wave_id == actual_server.get("Wave ID") and\
                                app.name == actual_server.get("App ID") and\
                                project.name == actual_server.get("Project ID"):
                            cemf_ec2_found = True
                            cemf_ec2_build_spec_print = {}
                            cemf_ec2_post_build_spec_print = {}
                            cemf_ec2_build_spec, cemf_ec2_post_build_spec = self.create_spec(
                                actual_server, server_expected_val)

                            if len(cemf_ec2_build_spec) > 0:
                                cemf_ec2_build_spec_print["ResourceType"] = RESOURCE_TYPE.ec2_instance
                                cemf_ec2_build_spec_print["ResourceName"] = server.name
                                cemf_ec2_build_spec_print["ResourceOS"] = server.os
                                cemf_ec2_build_spec_print["Source"] = expected_val_source
                                cemf_ec2_build_spec_print["Spec"] = cemf_ec2_build_spec

                                print_all_root_build_spec.append(cemf_ec2_build_spec_print)

                            if len(cemf_ec2_post_build_spec) > 0:
                                cemf_ec2_post_build_spec_print["ResourceType"] = RESOURCE_TYPE.ec2_instance
                                cemf_ec2_post_build_spec_print["ResourceName"] = server.name
                                cemf_ec2_post_build_spec_print["ResourceOS"] = server.os
                                cemf_ec2_post_build_spec_print["Source"] = expected_val_source
                                cemf_ec2_post_build_spec_print["Spec"] = cemf_ec2_post_build_spec

                                print_all_root_post_build_spec.append(cemf_ec2_post_build_spec_print)

                            break

                    if not cemf_ec2_found:
                        self.log_info(f"ERROR: Expected CMEF EC2 not found in AWS. Server Name: {server.name}")

        return print_all_root_build_spec, print_all_root_post_build_spec

    def print_cemf_server_mapping(self, cemf_projects: List[CemfProject], parsed_ec2_metadata):
        print_all_cemf_server_mapping = []
        for actual_server in parsed_ec2_metadata:
            actual_server_name = actual_server.get('Server Name')
            actual_server_os = actual_server.get('Server OS')
            actual_server_fqdn = actual_server.get('Server FQDN')
            actual_project_name = actual_server.get('Project ID')
            for project in cemf_projects:
                if actual_project_name == project.project_name:
                    for server in project.servers:
                        if actual_server_name == server.server_name:
                            cemf_server_mapping = {
                                'ServerName': actual_server_name,
                                'ServerOS': actual_server_os,
                                'OperatingSystem': server.server_os,
                                'Memory': server.memory,
                            }
                            # installed_applications = ""
                            # for installed_app in find_key(cemf_machine,'server_details')[0]["installedApplications"]:
                            #     installed_applications = ', '.join([
                            #       installed_applications,installed_app['applicationName']])
                            # cemf_server_mapping["InstalledApplications"] = installed_applications[2:]

                            cemf_server_mapping_details = [
                                {
                                    'Attribute': 'CPU',
                                    'PreMigration': [cpu.to_dict() for cpu in server.cpus],
                                    'PostMigration': (
                                        f"{actual_server.get('InstanceType')} "
                                        f"(Architecture: {actual_server.get('Architecture')})"
                                    )
                                }, {
                                    'Attribute': 'FQDN/IP Address',
                                    'PreMigration': f"Server FQDN: {actual_server_fqdn}",
                                    'PostMigration': f"Private IP Address: {actual_server.get('PrivateIpAddress')}"
                                }
                            ]

                            cemf_server_mapping["ServerMapping"] = cemf_server_mapping_details

                            print_all_cemf_server_mapping.append(dict(cemf_server_mapping).copy())

        return print_all_cemf_server_mapping

    def cemf_metadata(
        self,
        cemf_projects: List[CemfProject], account_id, wave_id, applications: Tuple[Application], default_region,
        parameters: List[ParameterEntry], default_cross_account_role, expected_val_source="cemf_csv"
    ):
        # NOTE: Step 1- Find EC2 Metadata for All EC2 instances for Accounts listed in Expected CMEF CSV File
        reservations = self.get_all_provisions(account_id, default_cross_account_role, region=default_region)

        # NOTE: Step 2 - Find all EC2 Metadata of Expected Instances
        parsed_ec2_metadata = self.make_all_cemf_ec2_resource_metadata(
            account_id, wave_id, applications, reservations)

        # NOTE: Step 4 - Make CEMF Server Mapping
        cemf_server_mapping = self.print_cemf_server_mapping(cemf_projects, parsed_ec2_metadata)

        # NOTE: Step 4 - Print Resource Metadata
        cemf_resource_metadata_print = self.print_cemf_ec2_resource_metadata(parsed_ec2_metadata)

        # NOTE: Step 5 - Print Build Spec Metadata
        print_all_cemf_build_spec, print_all_cemf_post_build_spec = self.print_cemf_ec2_spec_metadata(
            account_id, wave_id, parsed_ec2_metadata, applications,
            parameters, expected_val_source)

        return (
            cemf_resource_metadata_print, cemf_server_mapping,
            print_all_cemf_build_spec, print_all_cemf_post_build_spec
        )
