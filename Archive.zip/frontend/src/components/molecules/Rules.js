import React from 'react';

import PropTypes from 'prop-types';

import BootstrapTable from 'react-bootstrap-table-next';
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';

const Rules = ({
  rules, isLoading,
}) => {
  const columns = [{
    dataField: 'rule_id',
    text: 'Rule ID',
    filter: textFilter(),
    headerStyle: {width: 80},
  }, {
    dataField: 'publisher_id',
    text: 'Publisher ID',
    filter: textFilter(),
    headerStyle: {width: 100},
  }, {
    dataField: 'message',
    text: 'Message',
    filter: textFilter(),
  }, {
    dataField: 'description',
    text: 'Description',
    filter: textFilter(),
  }, {
    dataField: 'category',
    text: 'Category',
    filter: textFilter(),
    headerStyle: {width: 150},
  }, {
    dataField: 'severity',
    text: 'Severity',
    filter: textFilter(),
    headerStyle: {width: 80},
  }, {
    dataField: 'type',
    text: 'Type',
    filter: textFilter(),
    headerStyle: {width: 120},
  }];

  return (<>
    <br />
    <BootstrapTable
      keyField='rule_id' data={ rules } columns={ columns }
      filter={filterFactory()}
      noDataIndication={isLoading ? 'Loading Rules...' : "No rule yet."}
      />
  </>)
}

Rules.propTypes = {
  rules: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number.isRequired,
    rule_id: PropTypes.string.isRequired,
    publisher_id: PropTypes.string.isRequired,
    message: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    severity: PropTypes.string.isRequired,
    category: PropTypes.string.isRequired,
    type: PropTypes.string.isRequired,
  })).isRequired,
  isLoading: PropTypes.bool.isRequired,
}

export default Rules;
