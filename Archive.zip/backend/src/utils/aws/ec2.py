import json
from datetime import datetime
from typing import Dict, List, Tuple

from src.config import settings
from src.utils.aws.common import CrossAccountClientBase


class Ec2Volume:
    device_name: str
    volume_id: str
    status: str
    encrypted: bool
    state: str
    iops: int
    delete_on_termination: bool
    attached_at: datetime
    volume_type: str
    size: int

    def __init__(
        self,
        device_name: str,
        volume_id: str,
        status: str,
        encrypted: bool,
        state: str,
        iops: int,
        delete_on_termination: bool,
        attached_at: datetime,
        volume_type: str,
        size: int,
    ) -> None:
        self.device_name = device_name
        self.volume_id = volume_id
        self.status = status
        self.encrypted = encrypted
        self.state = state
        self.iops = iops
        self.delete_on_termination = delete_on_termination
        self.attached_at = attached_at
        self.volume_type = volume_type
        self.size = size

    def __str__(self) -> str:
        return f'{self.volume_id}: {self.device_name}({self.sizegib})'

    def __repr__(self) -> str:
        return f'<Ec2Volume({self.volume_id}): {self.size}({self.status})>'

    @property
    def sizegib(self) -> str:
        return f'{self.size} GB'

    def to_dict(self) -> dict:
        return {
            'DeviceName': self.device_name,
            'Ebs_VolumeId': self.volume_id,
            # 'AttachTime': self.attached_at.strftime(DATETIME_FORMAT),
            'Ebs_DeleteOnTermination': self.delete_on_termination,
            'Ebs_Status': self.status,
            'Ebs_Encrypted': self.encrypted,
            'Ebs_Size': self.size,
            'Ebs_State': self.state,
            'Ebs_Iops': self.size,
            'Ebs_VolumeType': self.volume_type,
        }


class Ec2SecurityGroup:
    group_id: str
    group_name: str

    def __init__(
        self,
        group_id: str,
        group_name: str,
    ) -> None:
        self.group_id = group_id
        self.group_name = group_name

    def __str__(self) -> str:
        return f'{self.group_id}: {self.group_name}'

    def __repr__(self) -> str:
        return f'<SecurityGroup({self.group_id}): {self.group_name}>'

    def to_dict(self) -> dict:
        return {
            'GroupId': self.group_id,
            'GroupName': self.group_name,
        }


class Ec2Instance:
    """
    ec2_metadata['BlockDeviceMappings'] = All_BlockDeviceMappings
    ec2_metadata['SecurityGroups'] = All_SecurityGroups
    """
    image_id: str
    instance_id: str
    instance_type: str
    monitoring_state: int
    placement_availablity_zone: str
    private_dns_name: str
    private_ip_address: str
    public_dns_name: str
    public_ip_address: str
    state: str
    vpc_id: str
    subnet_id: str
    architecture: str
    ebs_optimized: bool
    hypervisor: str
    source_dest_check: bool

    __volumes: List[Ec2Volume]
    security_groups: List[Ec2SecurityGroup]
    instance_statuses: List[dict]
    tags: Dict[str, str]

    def __init__(
        self,
        image_id: str,
        instance_id: str,
        instance_type: str,
        monitoring_state: int,
        placement_availablity_zone: str,
        private_dns_name: str,
        private_ip_address: str,
        public_dns_name: str,
        public_ip_address: str,
        state: str,
        vpc_id: str,
        subnet_id: str,
        architecture: str,
        ebs_optimized: bool,
        hypervisor: str,
        source_dest_check: bool,
        volumes: List[dict] = [],
        security_groups: List[dict] = [],
        instance_statuses: List[dict] = [],
        tags: List[Dict[str, str]] = [],
    ) -> None:
        self.image_id = image_id
        self.instance_id = instance_id
        self.instance_type = instance_type
        self.monitoring_state = monitoring_state
        self.placement_availablity_zone = placement_availablity_zone
        self.private_dns_name = private_dns_name
        self.private_ip_address = private_ip_address
        self.public_dns_name = public_dns_name
        self.public_ip_address = public_ip_address
        self.state = state
        self.vpc_id = vpc_id
        self.subnet_id = subnet_id
        self.architecture = architecture
        self.ebs_optimized = ebs_optimized
        self.hypervisor = hypervisor
        self.source_dest_check = source_dest_check

        self.__volumes = volumes
        self.security_groups = security_groups
        self.instance_statuses = instance_statuses
        self.tags = dict((item['Key'], item['Value']) for item in tags)

    def __str__(self) -> str:
        return self.instance_id

    def __repr__(self) -> str:
        return f'<Ec2Instance({self.image_id}): {self.instance_id}>'

    def add_volume(self, volume: Ec2Volume):
        self.__volumes = sorted(self.__volumes + [volume], key=lambda vol: vol.size)

    @property
    def volumes(self) -> Tuple[Ec2Volume]:
        return self.__volumes

    def to_dict(self) -> dict:
        response = {
            'InstanceId': self.instance_id,
            'ImageId': self.image_id,
            'InstanceType': self.instance_type,
            'Monitoring_State': self.monitoring_state,
            'Placement_AvailabilityZone': self.placement_availablity_zone,
            'PrivateDnsName': self.private_dns_name,
            'PrivateIpAddress': self.private_ip_address,
            'PublicDnsName': self.public_dns_name,
            'PublicIpAddress': self.public_ip_address,
            'State_Name': self.state,
            'SubnetId': self.subnet_id,
            'VpcId': self.vpc_id,
            'Architecture': self.architecture,
            'BlockDeviceMappings': [vol.to_dict() for vol in self.volumes],
            'EbsOptimized': self.ebs_optimized,
            'Hypervisor': self.hypervisor,
            'SecurityGroups': [sg.to_dict() for sg in self.security_groups],
            'SourceDestCheck': self.source_dest_check,
            **dict([(f'Tag: {key}', value) for key, value in self.tags.items()])
        }

        for status in self.instance_statuses:
            for item in status['InstanceStatus'].get('Details', []):
                response[f"Instance_{item.get('Name')}"] = item.get('Status')

            for item in status['SystemStatus'].get('Details', []):
                response[f"System_{item.get('Name')}"] = item.get('Status')

        return response


class Ec2Reservation:
    reservation_id: str
    owner_id: str
    name: str
    instances: List[Ec2Instance]

    def __init__(self, reservation_id: str, owner_id: str) -> None:
        self.reservation_id = reservation_id
        self.owner_id = owner_id

        self.instances = []

    def __str__(self) -> str:
        return f'{self.reservation_id}: {self.name}'

    def __repr__(self) -> str:
        return f'<Reservation({self.reservation_id}): {self.name}>'


class AvailabilityZone:
    state: str
    zone_id: str
    name: str

    def __init__(self, zone_id: str, name: str, state: str) -> None:
        self.zone_id = zone_id
        self.name = name
        self.state = state

    def __repr__(self) -> str:
        return f'<AZ({self.zone_id}): {self.name}>'

    def __str__(self) -> str:
        return self.name


class AwsSubNet:
    subnet_id: str
    vpc_id: str
    subnet_arn: str
    az_id: str
    cidr_block: str
    state: str

    def __init__(
        self,
        subnet_id: str,
        vpc_id: str,
        subnet_arn: str,
        az_id: str,
        cidr_block: str,
        state: str,
    ) -> None:
        self.subnet_id = subnet_id
        self.vpc_id = vpc_id
        self.subnet_arn = subnet_arn
        self.az_id = az_id
        self.cidr_block = cidr_block
        self.state = state

    def __repr__(self) -> str:
        return f'<Subnet({self.subnet_id}): {self.cidr_block}>'

    def __str__(self) -> str:
        return f'{self.subnet_id}({self.cidr_block})'

    def to_dict(self) -> dict:
        return {
            'SubnetId': self.subnet_id,
            'VpcId': self.vpc_id,
            'CidrBlock': self.cidr_block,
            'State': self.state,
            'AvailabilityZoneId': self.az_id,
        }


class RouteTable:
    route_table_id: str
    vpc_id: str
    routes: List[dict]

    def __init__(self, route_table_id: str, vpc_id: str, routes: List[dict]) -> None:
        self.route_table_id = route_table_id
        self.vpc_id = vpc_id
        self.routes = routes

    def __repr__(self) -> str:
        return f'<RouteTable({self.vpc_id}): {self.route_table_id}>'

    def __str__(self) -> str:
        return self.route_table_id

    def to_dict(self) -> dict:
        return {
            'RouteTableId': self.route_table_id,
            'VpcId': self.vpc_id,
            'Routes': self.routes,
        }


class NACL:
    nacl_id: str
    vpc_id: str
    is_default: bool
    tags: list

    def __init__(self, nacl_id: str, vpc_id: str, is_default: bool) -> None:
        self.nacl_id = nacl_id
        self.vpc_id = vpc_id
        self.is_default = is_default

    def __repr__(self) -> str:
        return f'<NACL({self.vpc_id}): {self.nacl_id}>'

    def __str__(self) -> str:
        return self.nacl_id

    def to_dict(self) -> dict:
        return {
            'NetworkAclId': self.nacl_id,
            'VpcId': self.vpc_id,
            'IsDefault': self.is_default,
        }


class InternetGateway:
    id: str
    attachments: List[dict]

    def __init__(self, id: str, attachments: List[dict]) -> None:
        self.id = id
        self.attachments = attachments

    def __repr__(self) -> str:
        return f'<InternetGateway: {self.id}>'

    def __str__(self) -> str:
        return self.id

    def to_dict(self) -> dict:
        return {
            'InternetGatewayId': self.id,
            'Attachments': self.attachments,
        }


class VPNGateway:
    def __init__(self) -> None:
        pass

    def to_dict(self) -> dict:
        return {}


class AwsVPC:
    vpc_id: str
    cidr_block: str
    state: str
    is_default: bool

    def __init__(
        self, vpc_id: str, cidr_block: str, state: str, is_default: bool,
    ) -> None:
        self.vpc_id = vpc_id
        self.cidr_block = cidr_block
        self.state = state
        self.is_default = is_default

    def __repr__(self) -> str:
        return f'<VPC({self.vpc_id}): {self.state})'

    def to_dict(self) -> dict:
        return {
            'VpcId': self.vpc_id,
            'CidrBlock': self.cidr_block,
            'State': self.state,
            'IsDefault': self.is_default,
        }


class AwsRegion:
    endpoint: str
    name: str
    opt_in_status: str

    zones: List[AvailabilityZone]
    vpcs: List[AwsVPC]
    subnets: List[AwsSubNet]
    route_tables: List[RouteTable]
    nacls: List[NACL]
    security_groups: List[Ec2SecurityGroup]
    internet_gateways: List[InternetGateway]
    vpn_gateways: List[VPNGateway]

    def __init__(self, name: str, endpoint: str, opt_in_status) -> None:
        self.name = name
        self.endpoint = endpoint
        self.opt_in_status = opt_in_status

        self.zones = []
        self.vpcs = []
        self.subnets = []
        self.route_tables = []
        self.nacls = []
        self.security_groups = []
        self.internet_gateways = []
        self.vpn_gateways = []

    def __repr__(self) -> str:
        return f'<AwsRegion: {self.name}>'

    def __str__(self) -> str:
        return self.name

    def to_dict(self) -> dict:
        return {
            'Endpoint': self.endpoint,
            'RegionName': self.name,
            'OptInStatus': self.opt_in_status,
        }

    @property
    def metadata(self) -> dict:
        return {
            'Region': self.name,
            'AvailabilityZoneDetails': [az.name for az in self.zones],
            'VPCDetails': [vpc.to_dict() for vpc in self.vpcs],
            'SubnetDetails': [sn.to_dict() for sn in self.subnets],
            'RouteTableDetails': [item.to_dict() for item in self.route_tables],
            'NACLDetails': [item.to_dict() for item in self.nacls],
            'SecurityGroupDetails': [item.to_dict() for item in self.security_groups],
            'InternetGatewayDetails': [item.to_dict() for item in self.internet_gateways],
            'VPNGatewayDetails': [item.to_dict() for item in self.vpn_gateways]
        }


class EC2(CrossAccountClientBase):
    client_name = 'ec2'

    def get_all_provisions(self, account_id: str, cross_role: str, region: str = None) -> List[Ec2Reservation]:
        """
        This function reads the Account IDs specified in the expected CMEF CSV file
        and finds out all EC2s in those accounts
        """
        self.refresh_client(account_id, cross_role, region)

        reservations = []

        all_ec2 = self.client.describe_instances()
        for reservation in all_ec2["Reservations"]:
            reservation_obj = Ec2Reservation(reservation['ReservationId'], reservation['OwnerId'])

            for item in reservation.get("Instances", []):
                instance = Ec2Instance(
                    item['ImageId'], item['InstanceId'], item['InstanceType'],
                    item['Monitoring']['State'], item['Placement']['AvailabilityZone'],
                    item['PrivateDnsName'], item['PrivateIpAddress'],
                    item['PublicDnsName'], item.get('PublicIpAddress'),
                    item['State']['Name'], item['VpcId'], item['SubnetId'],
                    item['Architecture'], item['EbsOptimized'],
                    item['Hypervisor'], item['SourceDestCheck'],
                    tags=item['Tags']
                )

                # Append Instance Status
                instance.instance_statuses = self.client.describe_instance_status(
                    InstanceIds=[instance.instance_id],
                    IncludeAllInstances=True
                )['InstanceStatuses']

                # Fetch all blocks in a single request.
                volumes = self.client.describe_volumes(
                    VolumeIds=[item['Ebs']['VolumeId'] for item in item.get("BlockDeviceMappings", [])])
                volumes_dictionary = dict([
                    (volume['VolumeId'], volume) for volume in volumes['Volumes']
                ])
                for device in item.get("BlockDeviceMappings", []):
                    attached_volume = volumes_dictionary.get(device['Ebs']['VolumeId'], {})
                    instance.add_volume(Ec2Volume(
                        device['DeviceName'],
                        device['Ebs']['VolumeId'], device['Ebs']['Status'],
                        attached_volume.get('Encrypted'),
                        attached_volume.get('State'),
                        attached_volume.get('Iops'),
                        device['Ebs']['DeleteOnTermination'],
                        device['Ebs']['AttachTime'], attached_volume.get('VolumeType'),
                        attached_volume.get('Size'),
                    ))

                instance.security_groups = [
                    Ec2SecurityGroup(item['GroupId'], item['GroupName'])
                    for item in item['SecurityGroups']]

                for tag in item.get("Tags", []):
                    if tag.get("Key", '').lower() == "name":
                        reservation_obj.name = tag.get("Value")

                reservation_obj.instances.append(instance)

            reservations.append(reservation_obj)

        return reservations

    def get_regions(self, account_id: str, cross_account_role: str, with_details: bool = False) -> List[AwsRegion]:
        self.refresh_client(account_id, cross_account_role)
        regions_response = self.client.describe_regions()['Regions']
        regions = [
            AwsRegion(region['RegionName'], region['Endpoint'], region['OptInStatus'])
            for region in regions_response]

        if with_details:
            self.log_info(f'Starting to fetch details for every region of account {account_id}...')
            for region in (regions[:1] if settings.IS_LOCAL else regions):
                self.log_info(f'Fetching details in {region.name} region...')
                self.refresh_client(account_id, cross_account_role, region.name)
                region.vpn_gateways = self.get_vpn_gateways()
                region.internet_gateways = self.get_internet_gateways()
                region.security_groups = self.get_security_groups()
                region.nacls = self.get_network_acls()
                region.route_tables = self.get_route_tables()
                region.subnets = self.get_subnets()
                region.vpcs = self.get_vpcs()
                region.zones = self.get_available_zones()

        return regions

    def get_available_zones(
        self, account_id: str = None, cross_account_role: str = None, region_name: str = None
    ) -> List[AvailabilityZone]:
        if account_id and cross_account_role:
            self.refresh_client(account_id, cross_account_role, region_name)

        zones = self.client.describe_availability_zones()['AvailabilityZones']
        return [AvailabilityZone(az['ZoneId'], az['ZoneName'], az['State']) for az in zones]

    def get_vpcs(
        self, account_id: str = None, cross_account_role: str = None, region_name: str = None
    ) -> List[AwsVPC]:
        if account_id and cross_account_role:
            self.refresh_client(account_id, cross_account_role, region_name)

        response = []

        vpc_paginator = self.client.get_paginator('describe_vpcs')
        vpc_page_iterator = vpc_paginator.paginate()
        for vpc_page in vpc_page_iterator:
            response += [
                AwsVPC(item['VpcId'], item['CidrBlock'], item['State'], item['IsDefault'])
                for item in vpc_page['Vpcs']]

        return response

    def get_subnets(
        self, account_id: str = None, cross_account_role: str = None, region_name: str = None
    ) -> List[AwsSubNet]:
        if account_id and cross_account_role:
            self.refresh_client(account_id, cross_account_role, region_name)

        response = []

        subnet_paginator = self.client.get_paginator('describe_subnets')
        subnet_page_iterator = subnet_paginator.paginate()
        for subnet_page in subnet_page_iterator:
            response += [
                AwsSubNet(
                    sn['SubnetId'], sn['VpcId'], sn['SubnetArn'],
                    sn['AvailabilityZoneId'], sn['CidrBlock'], sn['State']
                ) for sn in subnet_page['Subnets']
            ]

        return response

    def get_route_tables(
        self, account_id: str = None, cross_account_role: str = None, region_name: str = None
    ) -> List[RouteTable]:
        if account_id and cross_account_role:
            self.refresh_client(account_id, cross_account_role, region_name)

        response = []

        route_table_paginator = self.client.get_paginator('describe_route_tables')
        route_table_page_iterator = route_table_paginator.paginate()
        for route_table_page in route_table_page_iterator:
            response += [
                RouteTable(item['RouteTableId'], item['VpcId'], item['Routes'])
                for item in route_table_page['RouteTables']
            ]

        return response

    def get_network_acls(
        self, account_id: str = None, cross_account_role: str = None, region_name: str = None
    ) -> List[NACL]:
        if account_id and cross_account_role:
            self.refresh_client(account_id, cross_account_role, region_name)

        network_acls = self.client.describe_network_acls()['NetworkAcls']
        return [NACL(item['NetworkAclId'], item['VpcId'], item['IsDefault']) for item in network_acls]

    def get_security_groups(
        self, account_id: str = None, cross_account_role: str = None, region_name: str = None
    ) -> List[Ec2SecurityGroup]:
        if account_id and cross_account_role:
            self.refresh_client(account_id, cross_account_role, region_name)

        response = []

        sg_paginator = self.client.get_paginator('describe_security_groups')
        sg_page_iterator = sg_paginator.paginate()
        for sg_page in sg_page_iterator:
            response += [
                Ec2SecurityGroup(item['GroupId'], item['GroupName'])
                for item in sg_page['SecurityGroups']]

        return response

    def get_internet_gateways(
        self, account_id: str = None, cross_account_role: str = None, region_name: str = None
    ) -> List[InternetGateway]:
        if account_id and cross_account_role:
            self.refresh_client(account_id, cross_account_role, region_name)

        internet_gateways = self.client.describe_internet_gateways()['InternetGateways']
        return [InternetGateway(item['InternetGatewayId'], item['Attachments']) for item in internet_gateways]

    def get_vpn_gateways(
        self, account_id: str = None, cross_account_role: str = None, region_name: str = None
    ) -> List[VPNGateway]:
        if account_id and cross_account_role:
            self.refresh_client(account_id, cross_account_role, region_name)

        vpn_gateways = self.client.describe_vpn_gateways()['VpnGateways']

        # TODO: Need to convert to VPNGateway
        if vpn_gateways:
            self.log_info(f'INFO: VPN Found: {vpn_gateways[0]}')
            self.log_exception(Exception(json.dumps(vpn_gateways)))
        return [VPNGateway(**item) for item in vpn_gateways]
