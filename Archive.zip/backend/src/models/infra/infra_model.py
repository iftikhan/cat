from datetime import datetime
from typing import List, Optional
from src.utils.constants import InfraResourceStatus

from src.config import settings
from src.utils.pgsql import PgsqlManager, PG_DB_TABLE, Connection
from .entries import LandingZoneAccountEntry, InfraResourceEntry, LandingZoneEntry


class InfraModel:
    __connection: Optional[Connection] = None

    def __init__(self, db_manager: PgsqlManager = None) -> None:
        if isinstance(db_manager, PgsqlManager):
            self.__db_manager = db_manager
        else:
            self.__db_manager = PgsqlManager()

    @property
    def connection(self) -> Connection:
        if not isinstance(self.__connection, Connection):
            self.__connection = self.__db_manager.get_db_connection()

        return self.__connection

    def list_lz_accounts(self, landing_zone_id: int) -> List[LandingZoneAccountEntry]:
        # stmt = PG_DB_TABLE.lz_accounts.select().where(
        #     PG_DB_TABLE.lz_accounts.c.landing_zone_id == landing_zone_id
        # )
        stmt = f"""
            SELECT
                lzi.number_of_resources,
                acr.number_of_rules,
                lza.*
            FROM
                landing_zone_accounts lza
                LEFT JOIN (
                    SELECT account_id, count(*) as number_of_resources
                    FROM landing_zone_infrastructures
                    GROUP BY account_id
                ) lzi ON lza.id = lzi.account_id
                LEFT JOIN (
                    SELECT landing_zone_account_id, count(*) as number_of_rules
                    FROM account_config_rules
                    GROUP BY landing_zone_account_id
                ) acr ON lza.id = acr.landing_zone_account_id
            WHERE lza.landing_zone_id = {landing_zone_id}
            ;"""
        rows = self.connection.execute(stmt)
        return [
            LandingZoneAccountEntry(
                row.landing_zone_id, row.organization_unit,
                row.name, row.account_id, row.cross_account_role_name,
                row.created_by, row.description, row.id,
                row.created_at, row.updated_at, row.status,
                number_of_resources=row.number_of_resources,
                number_of_rules=row.number_of_rules,
            ) for row in rows]

    def create_lz_account(
        self, landing_zone_id: int, name: str, account_id: str, cross_account_role_name: str,
        created_by: str, description: str = None, organization_unit: str = None,
    ) -> bool:
        stmt = PG_DB_TABLE.lz_accounts.insert().values(
            landing_zone_id=landing_zone_id,
            name=name, account_id=account_id,
            cross_account_role_name=cross_account_role_name,
            description=description,
            created_by=created_by,
            organization_unit=organization_unit,
        )

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)
            return response.rowcount > 0

        return __transaction()

    def retrieve_lz_account(self, landing_zone_id: int, id: int) -> Optional[LandingZoneAccountEntry]:
        stmt = PG_DB_TABLE.lz_accounts.select().where(
            PG_DB_TABLE.lz_accounts.c.landing_zone_id == landing_zone_id,
            PG_DB_TABLE.lz_accounts.c.id == id
        )
        row = self.connection.execute(stmt).fetchone()

        if not row:
            return None

        account = LandingZoneAccountEntry(
            landing_zone_id=row.landing_zone_id,
            organization_unit=row.organization_unit,
            name=row.name, account_id=row.account_id,
            cross_account_role_name=row.cross_account_role_name,
            created_by=row.created_by, description=row.description,
            id=row.id, created_at=row.created_at,
            updated_at=row.updated_at, status=row.status
        )

        stmt = PG_DB_TABLE.lz_infrastructures.select().where(
            PG_DB_TABLE.lz_infrastructures.c.account_id == account.id
        )
        rows = self.connection.execute(stmt).fetchall()
        account.resources = [InfraResourceEntry(**row) for row in rows]

        return account

    def update_lz_account(self, id: int, **kwargs):
        permitted_attrs = ['name', 'organization_unit', 'account_id', 'cross_account_role_name', 'description']
        params = {}
        for attr in permitted_attrs:
            if attr in kwargs:
                params.update({attr: kwargs[attr]})

        if not params:
            return False

        stmt = PG_DB_TABLE.lz_accounts.update().where(PG_DB_TABLE.lz_accounts.c.id == id).values(**params)

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)
            return response.rowcount > 0

        return __transaction()

    def create_resource(
        self, account_id: int, name: str, resource_type: str, properties: dict,
        created_by: str, description: str = None,
    ) -> int:
        resource = InfraResourceEntry(
            account_id, resource_type, name, properties, description=description,
            created_by=created_by)
        stmt = PG_DB_TABLE.lz_infrastructures.insert().values(
            **resource.to_dict()
        ).returning(PG_DB_TABLE.lz_infrastructures.c.id)

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)
            [resource_id] = response.fetchone()
            return resource_id

        return __transaction()

    def retrieve_resource(self, resource_id: int) -> Optional[InfraResourceEntry]:
        stmt = PG_DB_TABLE.lz_infrastructures.select().where(
            PG_DB_TABLE.lz_infrastructures.c.id == resource_id
        )
        row = self.connection.execute(stmt).fetchone()
        return InfraResourceEntry(**row) if row else None

    def update_resource_attributes(self, resource_id: int, **kwargs) -> bool:
        permitted_attrs = ['name', 'status', 'stack_id', 'properties', 'description']
        params = {}
        for attr, value in kwargs.items():
            if attr not in permitted_attrs:
                continue

            params[attr] = value

        if not params:
            return False

        stmt = PG_DB_TABLE.lz_infrastructures.update().where(
            PG_DB_TABLE.lz_infrastructures.c.id == resource_id
        ).values(**params)

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)
            return response.rowcount > 0

        return __transaction()

    def update_resource_status(self, resource_id: int, status: InfraResourceStatus) -> bool:
        return self.update_resource_attributes(resource_id, status=status.value)

    def update_resource(self, resource_id: int, name: str, properties: dict, description: str = None) -> bool:
        resource = self.retrieve_resource(resource_id)

        if resource.status == InfraResourceStatus.provisioning:
            if not settings.IS_LOCAL:
                raise ValueError('resource can not be updated in provisioning status.')

        return self.update_resource_attributes(
            resource_id, name=name, description=description,
            properties=properties, status=InfraResourceStatus.initiated.value
        )

    def delete_resource(self, resource_id: int):
        stmt = PG_DB_TABLE.lz_infrastructures.delete().where(PG_DB_TABLE.lz_infrastructures.c.id == resource_id)

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            self.connection.execute(stmt)

        __transaction()

    def get_status(self, resource_ids: List[int]) -> List[dict]:
        conn = self.__db_manager.get_db_connection()
        _table = PG_DB_TABLE.lz_infrastructures
        stmt = _table.select().where(_table.c.id.in_(resource_ids)).with_only_columns(
            [_table.c.id, _table.c.status]
        )
        rows = conn.execute(stmt).fetchall()
        return [dict(
            resource_id=row.id,
            status=InfraResourceStatus(row.status).value,
        ) for row in rows]

    def list_landing_zones(self) -> List[LandingZoneEntry]:
        stmt = PG_DB_TABLE.landing_zones.select().order_by(PG_DB_TABLE.landing_zones.c.id)
        rows = self.connection.execute(stmt).fetchall()
        return [LandingZoneEntry(**row) for row in rows]

    def create_landing_zone(self, name: str) -> bool:
        stmt = PG_DB_TABLE.landing_zones.insert().values(name=name)

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)
            return response.rowcount > 0

        return __transaction()

    def update_landing_zone(self, landing_zone_id: int, name: str) -> bool:
        stmt = PG_DB_TABLE.landing_zones.update().where(
            PG_DB_TABLE.landing_zones.c.id == landing_zone_id,
        ).values(
            name=name,
            updated_at=datetime.utcnow()
        )

        @self.__db_manager.get_transaction_scope(self.connection)
        def __transaction():
            response = self.connection.execute(stmt)
            return response.rowcount > 0

        return __transaction()
