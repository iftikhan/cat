import createAction from 'redux/helpers/createAction';

export const namespace = 'admin';

export const fetchAccountsRequest = createAction(namespace, 'FETCH_ACCOUNTS_REQUEST');
export const fetchAccountsSuccess = createAction(namespace, 'FETCH_ACCOUNTS_SUCCESS');
export const fetchAccountsFailure = createAction(namespace, 'FETCH_ACCOUNTS_FAILURE');

export const fetchUsersRequest = createAction(namespace, 'FETCH_USERS_REQUEST');
export const fetchUsersSuccess = createAction(namespace, 'FETCH_USERS_SUCCESS');
export const fetchUsersFailure = createAction(namespace, 'FETCH_USERS_FAILURE');
