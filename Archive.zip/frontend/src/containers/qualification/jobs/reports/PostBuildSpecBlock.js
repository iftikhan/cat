import React from 'react';
import PropTypes from 'prop-types';

import { Card, CardHeader, CardBody } from 'reactstrap';
import PassFailBadge from 'components/molecules/badges/PassFailBadge';

const PostBuildSpecBlock = ({
  title,
  items,
}) => {
  return (
    <Card>
      <CardHeader>{title}</CardHeader>
      <CardBody className='react-bootstrap-table'>
        <table className='table'>
          <thead className='thead-dark'>
            <tr>
              <th>S.N</th>
              <th>Parameter</th>
              <th>Expected Value</th>
              <th>Actual Value</th>
              <th>Pass/Fail</th>
            </tr>
          </thead>
          <tbody>
            {items.map(({ResourceType: resourceType, ResourceName: resourceName, Spec: specs}, idx) => (
              <React.Fragment key={idx}>
                <tr key={`spec-${idx}`}><td colSpan={5}>{`${resourceType} : ${resourceName}`}</td></tr>
                {specs.map(({
                  Parameter: parameter, Drift: drift,
                  ActualValue: actualValue, ExpectedValue: expectedValue,
                }, specIdx) => (
                  <tr key={`${idx}-${specIdx}`}>
                    <td>{specIdx + 1}</td>
                    <td>{parameter}</td>
                    <td>{expectedValue.toString()}</td>
                    <td>{actualValue === undefined || actualValue === null ? 'Null' : actualValue.toString()}</td>
                    <td>{<PassFailBadge status={drift ? 'Fail' : 'Pass'} />}</td>
                  </tr>
                ))}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </CardBody>
    </Card>
  )
};

PostBuildSpecBlock.propTypes = {
  title: PropTypes.string.isRequired,
  items: PropTypes.arrayOf(PropTypes.shape({
    ResourceName: PropTypes.string.isRequired,
    ResourceOS: PropTypes.string,
    ResourceType: PropTypes.string.isRequired,
    Spec: PropTypes.arrayOf(PropTypes.shape({
      ActualValue: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
      Drift: PropTypes.bool.isRequired,
      ExpectedValue: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]).isRequired,
      Parameter: PropTypes.string.isRequired,
    })).isRequired,
  }))
}

export default PostBuildSpecBlock;
