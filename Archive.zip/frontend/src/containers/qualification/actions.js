import createAction from 'redux/helpers/createAction';

export const namespace = 'qualifications';

export const fetchParameterRequest = createAction(namespace, 'FETCH_PARAMETER_REQUEST');
export const fetchParameterSuccess = createAction(namespace, 'FETCH_PARAMETER_SUCCESS');
export const fetchParameterFailure = createAction(namespace, 'FETCH_PARAMETER_FAILURE');

export const uploadGxPRequest = createAction(namespace, 'UPLOAD_GXP_REQUEST');
export const uploadGxPSuccess = createAction(namespace, 'UPLOAD_GXP_SUCCESS');
export const uploadGxPFailure = createAction(namespace, 'UPLOAD_GXP_FAILURE');
export const setUploadProgress = createAction(namespace, 'SET_UPLOAD_PROGRESS');

export const fetchJobsRequest = createAction(namespace, 'FETCH_JOBS_REQUEST');
export const fetchJobsSuccess = createAction(namespace, 'FETCH_JOBS_SUCCESS');
export const fetchJobsFailure = createAction(namespace, 'FETCH_JOBS_FAILURE');

export const fetchJobDetailsRequest = createAction(namespace, 'FETCH_JOB_DETAILS_REQUEST');
export const fetchJobDetailsSuccess = createAction(namespace, 'FETCH_JOB_DETAILS_Success');
export const fetchJobDetailsFailure = createAction(namespace, 'FETCH_JOB_DETAILS_FAILURE');

export const setProjectDraft = createAction(namespace, 'SET_PROJECT_DRAFT');

export const fetchProjectsRequest = createAction(namespace, 'FETCH_PROJECT_REQUEST');
export const fetchProjectsSuccess = createAction(namespace, 'FETCH_PROJECT_SUCCESS');
export const fetchProjectsFailure = createAction(namespace, 'FETCH_PROJECT_FAILURE');
