from datetime import datetime
from src.utils.logger import Logger
from src.utils.constants import JOB_STATUS
from typing import Dict

from src.config import settings
from src.utils.constants import QUALIFICATION_TYPE
from src.utils.pgsql import PgsqlManager
from src.models.jobs import JobsModel
from src.models.admin.projects import ProjectModel

from .cemf.base import CEMFService
from .lz.base import LandingZoneService


class JobsLibrary:
    def __init__(self) -> None:
        self.__db_manager = PgsqlManager()

        self.__job_model = JobsModel(self.__db_manager)
        self.__project_model = ProjectModel(self.__db_manager)

    def init_job(self, job_id: int):
        job_entry = self.__job_model.get_job(job_id)

        if job_entry.qualification_type_id == QUALIFICATION_TYPE.cemf:
            service = CEMFService()
        elif job_entry.qualification_type_id == QUALIFICATION_TYPE.landing_zone:
            service = LandingZoneService()
        else:
            raise NotImplementedError()

        try:
            collected_files, report_details = service.collect_resource(job_entry)
            report_paths = []
            for collect_file_key_path in collected_files:
                report_path = service.generate_report(job_entry, collect_file_key_path)
                if report_path:
                    report_paths.append(report_path)

            job_entry.details.update({
                'reports': report_paths,
                'report_details': report_details,
            })

            self.__job_model.update(
                job_id, 'details', job_entry.details,
                status=JOB_STATUS.success,
                ended_at=datetime.now())
        except Exception as e:
            job_entry.details.update({
                'error': str(e)
            })
            self.__job_model.update(
                job_id, 'status', JOB_STATUS.error,
                details=job_entry.details
            )

            if settings.IS_LOCAL:
                raise e
            else:
                Logger().log_exception(e)

        return None

    def validate(self, project_id: int, key_path: str, run_method: str) -> Dict[str, bool]:
        project = self.__project_model.get(project_id)

        if project.qualification_type_id == QUALIFICATION_TYPE.cemf:
            service = CEMFService()
        elif project.qualification_type_id == QUALIFICATION_TYPE.landing_zone:
            service = LandingZoneService()
        else:
            raise NotImplementedError()

        return service.validate(project_id, key_path, run_method)
