from typing import List, Optional

from src.utils.pgsql import PgsqlManager, PG_DB_TABLE


class ReportDetailsEntry:
    id: int
    domain: str
    record_number: Optional[int] = None
    variable_names: List[str]
    variable_values: List[str]
    rule_id: str
    publisher_id: str
    message: str
    category: str
    severity: str

    def __init__(
        self, id: int, domain: str, record_number: Optional[int],
        variable_names: List[str], variable_values: List[str],
        rule_id: str, publisher_id: str, message: str,
        category: str, severity: str
    ) -> None:
        self.id = id
        self.domain = domain
        self.record_number = record_number
        self.variable_names = variable_names
        self.variable_values = variable_values
        self.rule_id = rule_id
        self.publisher_id = publisher_id
        self.message = message
        self.category = category
        self.severity = severity

    def to_response(self) -> dict:
        return {
            'id': self.id,
            'domain': self.domain,
            'record_number': self.record_number,
            'variable_names': self.variable_names,
            'variable_values': self.variable_values,
            'rule_id': self.rule_id,
            'message': self.message,
            'category': self.category,
            'severity': self.severity,
        }


class ReportDetailsModel:
    def __init__(self, db_manager: Optional[PgsqlManager] = None) -> None:
        if isinstance(db_manager, PgsqlManager):
            self.__db_manager = db_manager
        else:
            self.__db_manager = PgsqlManager()

    def bulk_insert(self, items: List[dict]) -> bool:
        _table = PG_DB_TABLE.report_details
        stmt = _table.insert().values(items)
        conn = self.__db_manager.get_db_connection()

        @self.__db_manager.get_transaction_scope(conn)
        def __transaction():
            response = conn.execute(stmt)
            return response.rowcount > 0

        return __transaction()

    def get_by_job(self, job_id: int, rule_id: str = None) -> List[ReportDetailsEntry]:
        conn = self.__db_manager.get_db_connection()
        rule_condition = f"AND rs.rule_id = '{rule_id}'" if rule_id else ''
        query = f"""
            SELECT
                rd.id, d."name" as domain, rd.record_number,
                rd.variable_names, rd.variable_values, rs.rule_id,
                r.publisher_id, r.message, r.category, r.severity
            FROM report_details rd
                JOIN report_summaries rs ON rd.report_summary_id = rs.id
                JOIN jobs j ON j.id = rs.job_id
                JOIN datasets d ON j.dataset_id = d.id
                JOIN rules r ON rs.rule_id = r.rule_id
            WHERE rs.job_id = {job_id} {rule_condition}
            ORDER BY r.rule_id, rd.record_number ;
        """
        rows = conn.execute(query)
        return [ReportDetailsEntry(**row) for row in rows]
