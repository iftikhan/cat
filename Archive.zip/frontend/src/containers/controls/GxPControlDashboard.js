import React, { useEffect, useState, useCallback } from 'react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router';
import { AwsServices, ComplianceStandards } from 'utils/constants';

import {
  Row, Col, Form, Button, Input,
  Card, CardHeader, CardBody,
} from 'reactstrap';

import { FaPlusCircle } from 'react-icons/fa';
import Select2 from "react-select2-wrapper";

import API from 'helpers/api';
import LoadingModal from 'components/modals/Loading';
import { fetchLzAccountsRequest } from 'containers/infrastructure/actions';
import SearchTable from 'components/tables/SearchTable';

const GxPControlDashboard = ({
  infras, fetchingInfras, fetchLzAccountsRequest,
}) => {
  const [landingZones, setLandingZones] = useState([]);
  const [curLandingZoneId, setCurLandingZoneId] = useState(null);
  const [accounts, setAccounts] = useState([]);
  const [managedRules, setManagedRules] = useState([]);
  const [filteredRules, setFilteredRules] = useState([]);
  const [selectedAwsService, setSelectedAwsService] = useState('');
  const [selectedStandard, setSelectedStandard] = useState('');

  const history = useHistory();

  const getLandingZones = useCallback(() => {
    API.infrastructure.getLandingZones().then(({landing_zones: items}) => {
      setLandingZones(items);
      if (items.length === 0) {
        history.push('/gxp-infra/admin');
      } else {
        const [{id: landingZoneId}] = items;
        setCurLandingZoneId(landingZoneId);
      }
    }).catch(err => {
      console.error(err);
      alert('Failed to fetch landing zones')
    }).finally(() => {
      console.log('Done: Fetching landing zones')
    })
  }, [setLandingZones, setCurLandingZoneId, history])

  useEffect(() => {
    getLandingZones()
  }, [getLandingZones])

  const fetchLandingZoneAccounts = useCallback(() => {
    API.fetchLandingZoneAccounts(curLandingZoneId).then((response: {
      accounts: Array<Object>
    }) => {
      setAccounts(response.accounts);
    }).catch(() => {
      alert('something went wrong!');
    })
  }, [setAccounts, curLandingZoneId]);

  const fetchManagedRules = useCallback(() => {
    return API.controls.getManagedRulesPerLandingZone(curLandingZoneId)
    .then(({managed_rules: rules, status}) => {
      if (status) {
        setManagedRules(rules);
      }
    }).catch(err => {
      console.error(err);
    })
  }, [curLandingZoneId, setManagedRules]);

  useEffect(() => {
    if (curLandingZoneId) {
      fetchLandingZoneAccounts()
    }
  }, [
    curLandingZoneId, fetchLandingZoneAccounts,
  ]);

  useEffect(() => {
    if (curLandingZoneId) {
      fetchManagedRules()
    }
  }, [
    curLandingZoneId, fetchManagedRules,
  ]);

  const columns = [
    {
      dataField: 'organization_unit',
      text: 'Organization Unit',
      sort: true,
    }, {
      dataField: 'name',
      text: 'Account Name',
      sort: true,
    }, {
      dataField: 'account_id',
      text: 'Account Number',
      align: 'right',
      headerStyle: {width: '120px'},
      sort: true,
    }, {
      dataField: 'number_of_rules',
      text: 'Number of Rules',
      align: 'right',
      headerStyle: {width: '180px',},
      sort: true,
    }, {
      dataField: '',
      text: '',
      headerStyle: {width: '56px'},
      formatter: (value, row) => {
        const {id: accountId} = row;
        return (
          <Button
            className={'btn-sm'}
            onClick={() => history.push(`/gxp-control/controls/${curLandingZoneId}/accounts/${accountId}`)}>
            <FaPlusCircle />
          </Button>
        )
      }
    },
  ];

  const managedRuleColumns = [
    {
      dataField: 'name',
      text: 'Managed Rule Name',
      sort: true,
    }, {
      dataField: 'number_of_accounts_applied',
      text: 'Applied Accounts',
      style: {textAlign: 'right'},
      formatter: (value, row, rowIndex) => {
        const {id: ruleId} = row;
        return <a href={`/gxp-control/controls/${curLandingZoneId}/rules/${ruleId}`}>{value}</a>
      }
    }, {
      dataField: 'description',
      text: 'Description',
    },
  ]

  useEffect(() => {
    setFilteredRules(managedRules.filter(({tags, name, description}) => {
      if (!!selectedAwsService) {
        if (tags.filter(item => item.toLowerCase() === selectedAwsService.toLowerCase()).length === 0) {
          return false
        }
      }

      if (!!selectedStandard) {
        return (
          description.toLowerCase().indexOf(selectedStandard.toLowerCase()) >=0 ||
          name.toLowerCase().indexOf(selectedStandard.toLowerCase()) >=0
        )
      }
      return true
    }))
  }, [selectedAwsService, selectedStandard, setFilteredRules, managedRules])

  return (
    <>
      <Row>
        <Col size='auto'></Col>
        <Col sm={4} md={3}>
          <h3 className='mt-2'>
          Select Landing Zone
          </h3>
        </Col>
        <Col>
          <Form>
            <Select2
              className="form-control"
              defaultValue={curLandingZoneId}
              onChange={e => setCurLandingZoneId(e.target.value)}
              options={{
                placeholder: "Select",
              }}
              data={landingZones.map(({id, name}) => ({id, text: name}))}
            />
          </Form>
        </Col>
      </Row>
      <Card className='mt-3'>
        <CardHeader>Accounts</CardHeader>
        <CardBody>
          <SearchTable
            keyField='id' columns={columns} data={accounts}
            entryNamePlural='accounts' noDataIndication='No account.' />
        </CardBody>
      </Card>
      <Card>
        <CardHeader>Controls</CardHeader>
        <CardBody>
          <Row className='mb-3'>
            <Col lg={2}>
              <Input
                className="form-control-sm"
                type='select' value={selectedAwsService}
                onChange={(event) => setSelectedAwsService(event.target.value)}
              >
                <option value={''}>AWS Service</option>
                {AwsServices.map((item, idx) => (
                  <option key={idx} value={item}>{item.toUpperCase()}</option>
                ))}
              </Input>
            </Col>
            <Col lg={3}>
              <Input
                className="form-control-sm"
                type='select' value={selectedStandard}
                onChange={(event) => setSelectedStandard(event.target.value)}
              >
                <option value={''}>Compliance Standard</option>
                {ComplianceStandards.map((item, idx) => (
                  <option key={idx} value={item}>{item}</option>
                ))}
              </Input>
            </Col>
          </Row>
          <SearchTable
            columns={managedRuleColumns} keyField='id'
            enableSearch={false}
            data={filteredRules.map((rule, idx) => ({
              ...rule,
            }))}
            entryNamePlural='rules'
            noDataIndication={'No managed rule'}
            />
        </CardBody>
      </Card>
      <LoadingModal show={false} />
    </>
  )
}

const mapStateToProps = (state) => ({
});

const mapDispatchToProps = (dispatch) => ({
  fetchLzAccountsRequest: () => dispatch(fetchLzAccountsRequest()),
})

export default connect(mapStateToProps, mapDispatchToProps)(GxPControlDashboard);
