from typing import Tuple

from src.utils.logger import Logger


class Ec2PermissionValidator:
    def __init__(self) -> None:
        self.__logger = Logger()

    def run(self) -> bool:
        self.__logger.log_info('Not implemented yet. Do not forget to complete EC2 validator')
        return True


class FileValidatorInterface:
    def run(self, project_id: int, key_path: str, run_method: str) -> Tuple[bool, dict]:
        raise NotImplementedError()


class IAMValidator:
    def __init__(self) -> None:
        self.__logger = Logger()

    def run(self) -> bool:
        self.__logger.log_info('Not implemented yet. Do not forget to complete IAMValidator')
        return True
