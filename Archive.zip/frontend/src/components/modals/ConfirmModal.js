import React from 'react';
import PropTypes from 'prop-types';

import {
  Modal, ModalHeader, ModalBody, ModalFooter, Button, FormGroup,
} from 'reactstrap';

const ConfirmModal = ({
  show, onOkay, onCancel, title, subTitle, description, okayText, cancelText,
}) => {
  return (
    <Modal isOpen={show} toggle={onCancel}>
      <ModalHeader>
        {title}
      </ModalHeader>
      <ModalBody>
        <FormGroup>
          <p>{description}</p>
        </FormGroup>
      </ModalBody>
      <ModalFooter>
        <Button color="secondary" onClick={onCancel}>
          {cancelText}
        </Button>
        <Button color="primary" className={'float-right'} onClick={onOkay}>
          {okayText}
        </Button>
      </ModalFooter>
    </Modal>
  )
}

ConfirmModal.propTypes = {
  title: PropTypes.string.isRequired,
  subTitle: PropTypes.string,
  description: PropTypes.string.isRequired,
  show: PropTypes.bool.isRequired,
  onOkay: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
  okayText: PropTypes.string,
  cancelText: PropTypes.string,
}

ConfirmModal.defaultProps = {
  subTitle: null,
  okayText: 'Okay',
  cancelText: 'Cancel',
}

export default ConfirmModal;
