from typing import Optional
import boto3

from src.utils.logger import Logger
from src.utils.exceptions import IncorrectCrossAccountRoleException


class STS(object):
    def __init__(self) -> None:
        self.__client = boto3.client("sts")

        self.__logger = Logger()

    def get_assume_role_credentials(self, arn: str) -> Optional[dict]:
        self.__logger.log_info(f'Getting STS Token for ARN: {arn}...')

        try:
            assumed_role_object = self.__client.assume_role(
                RoleArn=arn,
                RoleSessionName="AssumeRoleSession"
            )
            return assumed_role_object["Credentials"]
        except Exception as e:
            self.__logger.log_info(f"ERROR: Cannot get STS token for ARN : {arn}. Exception: {e}")
            return None

    def get_assume_role_client(
        self, account_id: str, cross_account_role: str, client_name: str,
        region_name: str = None,
    ):
        if client_name not in ['iam', 'ec2', 'organizations', 'cloudformation']:
            raise NotImplementedError(f'Not implemented client - {client_name}')

        params = {}
        if region_name:
            params['region_name'] = region_name

        current_account = self.__client.get_caller_identity().get('Account')

        if (int(account_id) == int(current_account)):
            assume_role_client = boto3.client(client_name, **params)
        else:
            arn = "arn:aws:iam::" + str(account_id) + ":role/" + cross_account_role
            credentials = self.get_assume_role_credentials(arn)

            if credentials is None:
                raise IncorrectCrossAccountRoleException()

            params.update(dict(
                aws_access_key_id=credentials["AccessKeyId"],
                aws_secret_access_key=credentials["SecretAccessKey"],
                aws_session_token=credentials["SessionToken"]
            ))

            assume_role_client = boto3.client(client_name, **params)

        return assume_role_client

    def get_account_name(self, account_id, cross_account_role) -> Optional[str]:
        account_client = self.get_assume_role_client(account_id, cross_account_role, 'iam')

        self.__logger.log_info(f'Getting alias of account {account_id}...')
        aliases = account_client.list_account_aliases()['AccountAliases']

        if aliases:
            return aliases[0].upper()
        else:
            self.__logger.log_info(f'Alais not found for account {account_id}! Just returning account ID')
            return str(account_id)
