import { call, put, takeEvery } from 'redux-saga/effects';

import API from 'helpers/api';
import {
  fetchParameterRequest, fetchParameterSuccess, fetchParameterFailure,
  fetchJobsRequest, fetchJobsSuccess, fetchJobsFailure,
  fetchJobDetailsRequest, fetchJobDetailsSuccess, fetchJobDetailsFailure,

  fetchProjectsRequest, fetchProjectsSuccess, fetchProjectsFailure,
} from './actions';

function* fetchProjects() {
  try {
    const { projects } = yield call(API.getProjects);
    yield put(fetchProjectsSuccess({ projects }));
  } catch (e) {
    yield put(fetchProjectsFailure());
  }
}

function* fetchParameter() {
  try {
    const {
      parameters, qualification_types: qualificationTypes, landing_zones: landingZones,
    } = yield call(API.getParameters);

    yield put(fetchParameterSuccess({
      parameters, qualificationTypes, landingZones,
    }));
  } catch (e) {
    yield put(fetchParameterFailure({error: e}))
  }  
}

function* fetchJobs() {
  try {
    const { jobs } = yield call(API.getJobs);

    yield put(fetchJobsSuccess({jobs}));
  } catch (e) {
    yield put(fetchJobsFailure({error: e}))
  }  
}

function* fetchJobDetails({ payload }) {
  const { jobId } = payload;
  try {
    const { job } = yield call(API.retrieveJobDetails, jobId);

    yield put(fetchJobDetailsSuccess({job}));
  } catch (e) {
    yield put(fetchJobDetailsFailure({error: e}))
  }  
}

export const qualificationSagas = [
  takeEvery(fetchProjectsRequest.Type, fetchProjects),
  takeEvery(fetchParameterRequest.Type, fetchParameter),
  takeEvery(fetchJobsRequest.Type, fetchJobs),
  takeEvery(fetchJobDetailsRequest.Type, fetchJobDetails),
];
