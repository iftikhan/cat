import React, { useEffect, useState, useCallback } from 'react';
import { connect } from 'react-redux';
import { useHistory } from 'react-router';

import {
  FormGroup, Input, Button, Row,
  Modal, ModalHeader, ModalBody, ModalFooter,
} from 'reactstrap';

import API from 'helpers/api';
import LoadingModal from 'components/modals/Loading';
import { fetchLzAccountsRequest } from './actions';

const GxPCreateInfra = ({
  infras, fetchingInfras, fetchLzAccountsRequest,
}) => {
  const [landingZones, setLandingZones] = useState([]);
  const [curLandingZoneId, setCurLandingZoneId] = useState(null);
  const [accounts, setAccounts] = useState([]);
  const [curAccountId, setCurAccountId] = useState(null);

  const history = useHistory();

  const getLandingZones = useCallback(() => {
    API.infrastructure.getLandingZones().then(({landing_zones: items}) => {
      setLandingZones(items);
      if (items.length === 0) {
        history.push('/gxp-infra/admin');
      } else {
        const [{id: landingZoneId}] = items;
        setCurLandingZoneId(landingZoneId);
      }
    }).catch(err => {
      console.error(err);
      alert('Failed to fetch landing zones')
    }).finally(() => {
      console.log('Done: Fetching landing zones')
    })
  }, [setLandingZones, setCurLandingZoneId, history])

  useEffect(() => {
    getLandingZones()
  }, [getLandingZones])

  const fetchLandingZoneAccounts = useCallback(() => {
    API.fetchLandingZoneAccounts(curLandingZoneId).then((response: {
      accounts: Array<Object>
    }) => {
      setAccounts(response.accounts);
    }).catch(() => {
      alert('something went wrong!');
    })
  }, [setAccounts, curLandingZoneId])

  useEffect(() => {
    if (curLandingZoneId) {
      fetchLandingZoneAccounts()
    }
  }, [
    curLandingZoneId, fetchLandingZoneAccounts,
  ]);

  useEffect(() => {
    if (accounts.length > 0) {
      const [{id: accountId}] = accounts;
      setCurAccountId(accountId);
    } else {
      setCurAccountId(null);
    }
  }, [accounts, setCurAccountId])

  return (
    <>
      <br />
      <LoadingModal show={false} />
      <Modal isOpen={true} toggle={() => {history.push(`/gxp-infra/dashboard`)}}>
        <ModalHeader>
          <span>Select Landing Zone and Account</span>
        </ModalHeader>
        <ModalBody>
          <FormGroup>
            <h6>Select Landing Zone</h6>
            <Input
              type="select" value={curLandingZoneId ? curLandingZoneId : ''}
              onChange={e => setCurLandingZoneId(e.target.value)}>
              {landingZones.map((lz, idx) => {
                const {name, id} = lz;
                return <option key={idx} value={id}>{name}</option>
              })}
            </Input>
          </FormGroup>
          <FormGroup>
            <h6>Select Account</h6>
            <Input
              type="select" value={curAccountId ? curAccountId : ''}
              onChange={e => setCurAccountId(e.target.value)}>
              {accounts.map((lz, idx) => {
                const {name, id} = lz;
                return <option key={idx} value={id}>{name}</option>
              })}
            </Input>
          </FormGroup>
        </ModalBody>
        <ModalFooter>
          <Row>
              <Button
                color="secondary" disabled={!curAccountId}
                onClick={() => {history.push(`/gxp-infra/dashboard`)}}>
                Back to Dashboard
              </Button>
              <Button
                color="primary" disabled={!curAccountId}
                onClick={() => {history.push(`/gxp-infra/create/${curLandingZoneId}/accounts/${curAccountId}/resources`)}}>
                Manage Resources
              </Button>
          </Row>
        </ModalFooter>
      </Modal>
    </>
  )
}

const mapStateToProps = (state) => ({
});

const mapDispatchToProps = (dispatch) => ({
  fetchLzAccountsRequest: () => dispatch(fetchLzAccountsRequest()),
})

export default connect(mapStateToProps, mapDispatchToProps)(GxPCreateInfra);
