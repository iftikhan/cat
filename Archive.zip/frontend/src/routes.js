/*!

=========================================================
* Argon Dashboard PRO React - v1.2.1
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-dashboard-pro-react
* Copyright 2021 Creative Tim (https://www.creative-tim.com)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/

import GxPInfraDashboard from "containers/infrastructure/GxPInfraDashboard";
import GxPResourceList from "containers/infrastructure/GxPResourceList";
import GxPCreateInfra from "containers/infrastructure/GxPCreateInfra";
import ResourceDetails from "containers/infrastructure/ResourceDetails";
import LandingZoneAdmin from "containers/infrastructure/LandingZoneAdmin";

import CreateJob from "containers/qualification/jobs/CreateJob";
import JobList from "containers/qualification/jobs/JobList";
import JobDetails from "containers/qualification/jobs/JobDetails";
import QualificationDashboard from "containers/qualification/QualificationDashboard";
import QualificationUpdateProject from "containers/qualification/admin/UpdateProject";
import QualificationNewProject from "containers/qualification/admin/NewProject";

import GxPControlDashboard from "containers/controls/GxPControlDashboard";

import SettingsPage from "containers/settings/Settings";
import GxPControls from "containers/controls/GxPControls";
import GxPControlAccountRules from "containers/controls/GxPControlAccountRules";
import GxPControlRuleAccounts from "containers/controls/GxPControlRuleAccounts";
import GxPControlManagement from "containers/controls/GxPControlManagement";
import GxPControlRuleUpdate from "containers/controls/GxPControlRuleUpdate";

const routes = [
  {
    collapse: true,
    name: "Gxp Infrastructure",
    icon: "ni ni-shop text-primary",
    state: "infrastructureCollapse",
    views: [
      {
        path: "/dashboard",
        name: "Dashboard",
        miniName: "D",
        component: GxPInfraDashboard,
        // component: Dashboard,
        layout: "/gxp-infra",
      },
      {
        path: "/create/:landingZoneId/accounts/:accountId/resources/:resourceId",
        name: "Infrastructure",
        miniName: "I",
        component: ResourceDetails,
        layout: "/gxp-infra",
        redirect: true,
      },
      {
        path: "/create/:landingZoneId/accounts/:accountId/resources",
        name: "Infrastructure",
        miniName: "I",
        component: GxPResourceList,
        layout: "/gxp-infra",
        redirect: true,
      },
      {
        path: "/create",
        name: "Infrastructure",
        miniName: "I",
        component: GxPCreateInfra,
        layout: "/gxp-infra",
      },
    ],
  },
  {
    collapse: true,
    name: "GxP Qualification",
    icon: "ni ni-ungroup text-orange",
    state: "qualificationCollapse",
    views: [
      {
        path: "/create",
        name: "Create Job",
        miniName: "J",
        component: CreateJob,
        layout: "/gxp-qualification",
      },
      {
        path: "/jobs/:jobId",
        name: "View Jobs",
        miniName: "V",
        component: JobDetails,
        layout: "/gxp-qualification",
        redirect: true,
      },
      {
        path: "/jobs",
        name: "View Jobs",
        miniName: "V",
        component: JobList,
        layout: "/gxp-qualification",
      },
      {
        path: "/dashboard",
        name: "Dashboard",
        miniName: "Q",
        component: QualificationDashboard,
        layout: "/gxp-qualification",
      },
      {
        path: "/projects/new",
        name: "Projects",
        miniName: "M",
        component: QualificationNewProject,
        layout: "/gxp-qualification",
        redirect: true,
      },
      {
        path: "/projects",
        name: "Projects",
        miniName: "M",
        component: QualificationUpdateProject,
        layout: "/gxp-qualification",
      },
    ],
  },
  {
    collapse: true,
    name: "GxP Controls",
    icon: "ni ni-controller text-blue",
    state: "controlCollapse",
    views: [
      {
        path: "/dashboard",
        name: "Dashboard",
        miniName: "D",
        component: GxPControlDashboard,
        layout: "/gxp-control",
      },
      {
        path: "/manage/:ruleId",
        name: "Manage Controls",
        miniName: "M",
        component: GxPControlRuleUpdate,
        layout: "/gxp-control",
        redirect: true,
      },
      {
        path: "/manage",
        name: "Manage Controls",
        miniName: "M",
        component: GxPControlManagement,
        layout: "/gxp-control",
      },
      {
        path: "/controls/:landingZoneId/accounts/:accountId",
        name: "Account Rules",
        miniName: "L",
        component: GxPControlAccountRules,
        layout: "/gxp-control",
        redirect: true,
      },
      {
        path: "/controls/:landingZoneId/rules/:ruleId",
        name: "Account Rules",
        miniName: "L",
        component: GxPControlRuleAccounts,
        layout: "/gxp-control",
        redirect: true,
      },
      {
        path: "/controls",
        name: "Apply Controls",
        miniName: "A",
        component: GxPControls,
        layout: "/gxp-control",
      },
    ]
  },
  {
    collapse: true,
    name: "Admin",
    icon: "fa fa-cogs text-green",
    state: "adminCollapse",
    views: [
      {
        path: "/landing-zones",
        name: "Landing Zone",
        miniName: "L",
        component: LandingZoneAdmin,
        layout: "/admin",
      },
    ]
  },
  {
    path: "/settings",
    name: "Admin",
    icon: "fa fa-cogs text-green",
    component: SettingsPage,
    redirect: true,
    layout: "/admin",
  },
];

export default routes;
