import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { useHistory } from 'react-router-dom';
import { Button, Badge } from 'reactstrap';
import { BsPlusCircleFill } from 'react-icons/bs';
import { AiFillFilePdf } from 'react-icons/ai';
import Heartbeat from 'react-heartbeat';

import API from 'helpers/api';

import { fetchJobsRequest } from '../actions';

import SearchTable from 'components/tables/SearchTable';

const JobList = ({
  jobs, fetchJobsRequest,
  isLoading,
}) => {
  const history = useHistory();
  const [isDownloading, setIsDownloading] = useState({});
  const [runningJobs, setRunningJobs] = useState([]);

  const onViewClicked = (jobId: Number) => {
    history.push(`/gxp-qualification/jobs/${jobId}`);
  }

  useEffect(() => {
    fetchJobsRequest()
  }, [fetchJobsRequest]);

  useEffect(() => {
    setRunningJobs(jobs.filter(job => job.status === 'Running'))
  }, [jobs, setRunningJobs])

  const checkStatus = () => {
    API.checkStatus(runningJobs.map(item => item.id)).then(({job_status: runningJobs}) => {
      if (runningJobs.filter(job => job.status !== 'Running').length > 0) {
        // setRunningJobs([])
        fetchJobsRequest()
      }
    }).catch(err => {
      console.error(err)
    })
  }

  const onDownloadClicked = (jobId: Number, url: String) => {
    setIsDownloading({
      ...isDownloading,
      [jobId]: true,
    })
    API.downloadReport(jobId, url).then(() => {
      setIsDownloading({...isDownloading, [jobId]: false});
    }).catch(() => {
      setIsDownloading({...isDownloading, [jobId]: false});
    })
  }

  const columns = [{
    dataField: 'id',
    text: 'Job ID',
    headerStyle: { width: '80px', textAlign: 'center' },
    style: { textAlign: 'right' },
  }, {
    dataField: 'created_by',
    text: 'User ID',
    // formatter: (cel: String, row, rowIndex, data) => {
    //   return <span title={cel}>{`${cel.slice(0, 3)}...${cel.slice(cel.length - 3)}`}</span>
    // }
  }, {
    dataField: 'started_at',
    text: 'Started At',
    headerFormatter: (col, colIndex, components) => {
      return <>Started At<br/>Duration</>
    },
    formatter: (value, row, rowIndex) => {
      const { started_at: startedAt, duration } = row;
      return <>{startedAt}<br/>{duration}</>
    },
    headerStyle: {textAlign: 'center'},
    style: {textAlign: 'center'},
  }, {
  //   dataField: 'duration',
  //   text: 'Duration',
  //   headerStyle: { width: '80px' },
  // }, {
  //   dataField: 'project',
  //   text: 'Project',
  // }, {
    dataField: 'qualification_type',
    text: 'Qualification Type',
    headerFormatter: (col, colIndex, components) => (<>Qualification Type<br/>Project</>),
    headerStyle: {textAlign: 'center'},
    style: {textAlign: 'center'},
    formatter: (value, row, rowIndex) => {
      const { qualification_type: qualificationType, project } = row;
      return <>{qualificationType}<br/>{project}</>
    },
  }, {
    dataField: 'run_method',
    text: 'Method',
  }, {
    dataField: 'status',
    text: 'Status',
    formatter: (value, row, rowIndex) => {
      let iconClassName = null;
      if (value === 'Running') {
        iconClassName = 'bg-warning';
      } else if (value === 'Errors') {
        iconClassName = 'bg-danger';
      } else if (value === 'Run Successful') {
        iconClassName = 'bg-success';
      }

      return (
        <Badge color="" className="badge-dot mr-4">
          <i className={iconClassName} />
          <span className="status">{value}</span>
        </Badge>
      )
    },
    headerStyle: { width: '150px', textAlign: 'center' },
  }, {
    dataField: 'action',
    text: 'Action',
    headerStyle: { width: '120px', textAlign: 'center' },
    style: (cel, row, rowIndex) => {
      if (row.status === 'Run Successful') {
        return {
          textAlign: 'center',
          display: 'flex',
          justifyContent: 'space-evenly',
          // border: 'none',
        }
      } else {
        return {}
      }
    },
    formatter: (cel, row, rowIndex) => {
      if (row.status === 'Run Successful') {
        return (<>
          <Button
            title='View Report' color='primary'
            className={classnames('btn-sm')}
            onClick={() => onViewClicked(row.id)}><BsPlusCircleFill /></Button>
          <Button
            title='Download PDF Report' color='danger'
            disabled={!!isDownloading[row.id]}
            className={classnames('btn-sm')}
            onClick={() => onDownloadClicked(row.id, row.reports[0])}><AiFillFilePdf /></Button>
        </>)
      } else {
        return <></>
      }
    },
  }];

  // const tableRowStyle = (row, rowIndex) => {
  //   const { status } = row;
  //   if (status.toLowerCase() === 'run successful') {
  //     return 'table-success'
  //   }
  // }

  return (
    <>
      {jobs.length > 0 &&
      <SearchTable
        keyField='id' data={ jobs } columns={ columns }
        entryName='Job' entryNamePlural='Jobs'
        // rowClasses={tableRowStyle}
        />}
      {runningJobs.length > 0 && <Heartbeat heartbeatFunction={checkStatus} heartbeatInterval={3000} />}
    </>
  );
}

JobList.propTypes = {
  jobs: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number.isRequired,
    project: PropTypes.string.isRequired,
    s3_input_url: PropTypes.string.isRequired,
    s3_report_url: PropTypes.string,
    started_at: PropTypes.string.isRequired,
    ended_at: PropTypes.string.isRequired,
    status: PropTypes.string.isRequired,
    qualification_type: PropTypes.string.isRequired,
    run_method: PropTypes.string.isRequired,
  })).isRequired,
  isLoading: PropTypes.bool.isRequired,
  // onDownload: PropTypes.func.isRequired,
  fetchJobsRequest: PropTypes.func.isRequired,
}

const mapStateToProps = state => ({
  jobs: state.qualifications.jobs,
  isLoading: state.qualifications.fetchingJobs,
})

const mapDispatchToProps = dispatch => ({
  fetchJobsRequest: () => dispatch(fetchJobsRequest()),
})

export default connect(mapStateToProps, mapDispatchToProps)(JobList);
