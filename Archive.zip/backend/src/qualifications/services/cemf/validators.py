import io
import re
import json
from typing import Dict, List, Union, Tuple

import boto3
import pandas as pd

from src.config import settings
from src.utils.constants import DRAFT_FILE_PATTERN
from src.utils.logger import Logger
from src.utils.validators import FileValidatorInterface

from src.utils.exceptions import IncorrectCrossAccountRoleException, InvalidCmefTokenException
from src.qualifications.services.cemf.api import CemfAPI
from src.utils.aws.sts import STS
from src.models.admin.projects import ProjectModel


class AssumeRoleValidator:
    # arn:aws:iam::109928845756:role/autogxp-dev-crossaccount-role

    def __init__(self) -> None:
        self.__sts = STS()
        self.__logger = Logger()

    def get_sts_token(self, arn: str) -> dict:
        return self.__sts.get_assume_role_credentials(arn)

    def run(
        self, project_id: int, key_path: str, data: Dict[str, Union[str, List[dict]]]
    ) -> Tuple[Dict[str, bool], str]:
        pattern = r'^public\/(\d+)\/(.*)\/drafts\/(.*)$'
        match = re.search(pattern, key_path)

        project_id, user_id, input_filename = match.groups()
        output_filename = '.'.join(input_filename.split('.')[:-1] + ['json'])
        output_key_path = f'public/{project_id}/{user_id}/input/{output_filename}'

        # NOTE: This part should be enabled by avoiding hardcode
        project_model = ProjectModel()
        project = project_model.get_detail(project_id)
        token = project.setting['cemf_api_token']

        api = CemfAPI(token)

        try:
            api.authenticate()
        except InvalidCmefTokenException:
            return False, None

        accounts = list(set([
            (item['aws_accountid'], item['default_cross_account_role'])
            for item in data['CEMF_JSON_FileDetails']
        ]))
        result = {}

        for account_id, assume_role_name in accounts:
            try:
                result[account_id] = self.__sts.get_account_name(account_id, assume_role_name)
            except IncorrectCrossAccountRoleException:
                return {}, None

        if all(success for _, success in result.items()):
            s3_client = boto3.client('s3')
            s3_client.put_object(
                Body=str(json.dumps(data, indent=4)),
                Bucket=settings.STORAGE_BUCKET, Key=output_key_path
            )

        return result, output_key_path


class CemfCSVValidator(FileValidatorInterface):
    mandatory_column_list = [
        "wave_id", "app_name", "cloudendure_projectname", "aws_accountid",
        'default_cross_account_role', "server_name",
        "server_os", "server_os_version", "server_fqdn", "server_tier", "server_environment",
        "subnet_IDs", "securitygroup_IDs", "subnet_IDs_test", "securitygroup_IDs_test",
        "instanceType", "tenancy", "private_ips"
    ]
    non_missing_column_list = [
        "wave_id", "app_name", "cloudendure_projectname", "aws_accountid",
        'default_cross_account_role', "server_name",
        "server_os", "server_os_version", "server_fqdn", "server_tier", "server_environment",
        "subnet_IDs", "securitygroup_IDs", "subnet_IDs_test", "securitygroup_IDs_test",
        "instanceType", "tenancy", "private_ips"
    ]

    def __init__(self) -> None:
        self.__logger = Logger()

    def __check_mandatory_columns(self, input_pd_data, mandatory_column_list) -> bool:
        try:
            is_valid = True
            for col in mandatory_column_list:
                if col.lower() not in input_pd_data.columns.str.lower():
                    self.__logger.log_info(f"ERROR: {col} Column Not found in Input Excel File")
                    is_valid = False
        except Exception as e:
            self.__logger.log_exception(e)
            is_valid = False

        return is_valid

    def __check_non_missing_columns(self, input_pd_data, non_missing_column_list):
        try:
            is_valid = True
            for col in non_missing_column_list:
                if (input_pd_data[col] == "").any():
                    self.__logger.log_info(f"ERROR: {col} column have missing values.")
                    is_valid = False
        except Exception as e:
            self.__logger.log_exception(e)
            is_valid = False

        return is_valid

    def __validate_input_cemf_csv(self, input_pd_data: pd.DataFrame) -> bool:
        try:
            self.__logger.log_info("NOTE: Validating input CEMF CSV file...")

            check_mandatory_col = self.__check_mandatory_columns(input_pd_data, self.mandatory_column_list)
            check_non_missing_col = self.__check_non_missing_columns(input_pd_data, self.non_missing_column_list)
            if check_mandatory_col and check_non_missing_col:
                return True
            else:
                return False
        except Exception as e:
            self.__logger.log_exception(e)
            return False

    def run(self, project_id: int, key_path: str, run_method: str) -> Tuple[bool, dict]:
        s3_client = boto3.client('s3')
        match = re.search(DRAFT_FILE_PATTERN, key_path)

        project_id, user_id, input_filename = match.groups()
        output_filename = '.'.join(input_filename.split('.')[:-1] + ['json'])
        output_key_path = f'public/{project_id}/{user_id}/input/{output_filename}'
        object = s3_client.get_object(Bucket=settings.STORAGE_BUCKET, Key=key_path)
        data = object['Body'].read().decode('utf-8')

        def convert_to_aws_account_id(original: float) -> str:
            int_value = int(original)
            missings = 12 - len(str(int_value))
            return ''.join(['0'] * missings) + str(int_value)

        # Read CEMF CSV File
        autoiqoq_cemf_csv = pd.read_csv(
            io.StringIO(data),
        )
        autoiqoq_cemf_csv['aws_accountid'] = autoiqoq_cemf_csv['aws_accountid'].astype(int).apply(
            convert_to_aws_account_id
        )
        autoiqoq_cemf_csv = autoiqoq_cemf_csv.dropna(how='all')
        autoiqoq_cemf_csv = autoiqoq_cemf_csv.fillna('')

        # Validate uploaded file
        validate_input_file = self.__validate_input_cemf_csv(autoiqoq_cemf_csv)
        if not validate_input_file:
            return False, {}

        autoiqoq_cemf_csv = autoiqoq_cemf_csv.rename(columns={
            'private_ips': 'PrivateIpAddress',
            'instanceType': 'InstanceType',
            'subnet_IDs': 'SubnetId',
            'securitygroup_IDs': 'SecurityGroups'
        })

        autoiqoq_cemf_csv_melt = pd.melt(
            autoiqoq_cemf_csv.reset_index(),
            id_vars=[
                "wave_id", "app_name", "cloudendure_projectname", "aws_accountid", 'default_cross_account_role',
                "server_name", "server_os", "server_os_version", "server_fqdn", "server_environment"
            ],
            value_vars=[
                "server_tier", "SubnetId", "SecurityGroups", "subnet_IDs_test",
                "securitygroup_IDs_test", "InstanceType", "tenancy", "PrivateIpAddress"
            ],
            var_name='ExpectedVariable',
            value_name='ExpectedValue'
        )
        autoiqoq_cemf_csv_melt = autoiqoq_cemf_csv_melt.sort_values(
            by=[
                "wave_id", "app_name", "cloudendure_projectname", "aws_accountid",
                'default_cross_account_role', "server_name", "ExpectedVariable"
            ]
        )

        # Write to JSON and store in S3
        autoiqoq_cemf_csv_json_parsed = autoiqoq_cemf_csv_melt.to_dict(orient="records")

        autoiqoq_cemf_csv_json_print = {}
        autoiqoq_cemf_csv_json_print["Source"] = "CEMF"
        autoiqoq_cemf_csv_json_print["CEMF_CSV_S3_Name"] = settings.STORAGE_BUCKET
        autoiqoq_cemf_csv_json_print["CEMF_CSV_S3_Key"] = key_path
        autoiqoq_cemf_csv_json_print["CEMF_CSV_FileName"] = input_filename
        autoiqoq_cemf_csv_json_print["CEMF_JSON_S3_Name"] = settings.STORAGE_BUCKET
        autoiqoq_cemf_csv_json_print["CEMF_JSON_S3_Key"] = output_key_path
        autoiqoq_cemf_csv_json_print["CEMF_JSON_S3_FileName"] = output_filename
        autoiqoq_cemf_csv_json_print["CEMF_JSON_FileDetails"] = autoiqoq_cemf_csv_json_parsed

        return True, autoiqoq_cemf_csv_json_print
