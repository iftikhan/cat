import { call, put, takeEvery } from 'redux-saga/effects';

import API from 'helpers/api';
import {
  fetchAccountsRequest, fetchAccountsSuccess, fetchAccountsFailure,
  fetchUsersRequest, fetchUsersSuccess, fetchUsersFailure,
} from './actions';

function* fetchAccounts() {
  try {
    const { accounts } = yield call(API.getAccounts);

    yield put(fetchAccountsSuccess({
      accounts
    }));
  } catch (e) {
    yield put(fetchAccountsFailure({error: e}))
  }  
}

function* fetchUsers() {
  try {
    const { users } = yield call(API.getUsers);

    yield put(fetchUsersSuccess({
      users
    }));
  } catch (e) {
    yield put(fetchUsersFailure({error: e}))
  }  
}

export const adminSagas = [
  takeEvery(fetchAccountsRequest.Type, fetchAccounts),
  takeEvery(fetchUsersRequest.Type, fetchUsers),
];
