import { all } from 'redux-saga/effects';
import { qualificationSagas } from 'containers/qualification/saga';
import { settingsSagas } from 'containers/settings/saga';
import { adminSagas } from 'containers/admin/saga';
import { infraSagas } from 'containers/infrastructure/saga';
import { controlSagas } from 'containers/controls/saga';

export default function* rootSaga() {
  yield all([
    ...qualificationSagas,
    ...settingsSagas,
    ...adminSagas,
    ...infraSagas,
    ...controlSagas,
  ])
}
