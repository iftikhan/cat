import { combineReducers } from 'redux'
import { connectRouter } from 'connected-react-router'

/**
 * All reducers must be imported here
 */
import * as validations from 'containers/qualification/reducer';
import * as settings from 'containers/settings/reducer';
import * as admin from 'containers/admin/reducer';
import * as infrastructures from 'containers/infrastructure/reducer'
import * as control from 'containers/controls/reducer'

/**
 * current.name is the name defined in the reducer.js
 * current.default is the default export from the reducer file
 */
const allReducers = [
  validations,
  settings,
  admin,
  infrastructures,
  control,
].reduce((all, current) => {
  return Object.assign({}, all, { [current.namespace]: current.default })
}, {})

const rootReducer = history =>
  combineReducers({
    ...allReducers,
    router: connectRouter(history),
  });

export default rootReducer;
