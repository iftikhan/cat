import { API, Auth, Storage } from 'aws-amplify';

import config from 'aws-export';

const apiName = 'ApiGatewayRestApi'


class Infrastructure {
  static async getLandingZones() {
    const path = `/infra/lz`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };

    return API.get(apiName, path, myInit);
  }

  static async createLandingZone(name: String) {
    const path = '/lz';
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        name,
      }
    };
    return API.post(apiName, path, myInit);
  }

  static async updateLandingZone(landingZoneId: Number, name: String) {
    const path = `/infra/lz/${landingZoneId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        name,
      }
    };
    return API.put(apiName, path, myInit);
  }
}

class GxPControl {
  static async getManagedRules(provider: String = '') {
    const path = `/controls/managed_rules?provider=${provider}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };

    return API.get(apiName, path, myInit);
  }

  static async retrieveManagedRule(ruleId: Number) {
    const path = `/controls/managed_rules/${ruleId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };

    return API.get(apiName, path, myInit);
  }

  static async updateManagedRule(ruleId: Number, params: Object) {
    const path = `/controls/managed_rules/${ruleId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: params
    };
  
    return API.put(apiName, path, myInit);
  }

  static async createManagedRule(
    name: String, provider: String, services: Array<String>,
    standards: Array<String>, tags: Array<String>, description: String = ''
  ) {
    const path = `/controls/managed_rules`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        name, provider, services,
        standards, tags, description,
      }
    };
  
    return API.post(apiName, path, myInit);
  }

  static async getManagedRulesPerLandingZone(landingZoneId: Number) {
    const path = `/controls/managed_rules?landing_zone_id=${landingZoneId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };

    return API.get(apiName, path, myInit);
  }

  static async applyManagedRulesToAccountsInBatch(managedRuleIds: Array<Number>, accountIds: Array<Number>) {
    const path = `/controls/apply`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        managed_rule_ids: managedRuleIds,
        account_ids: accountIds,
      }
    };
  
    return API.post(apiName, path, myInit);
  }

  static async getRulesByAccount(accountId: Number) {
    const path = `/controls/accounts/${accountId}/rules`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };

    return API.get(apiName, path, myInit);
  }

  static async updateRulesByAccount(accountId: Number, managedRuleIds: Array<Number>) {
    const path = `/controls/accounts/${accountId}/rules`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        managed_rule_ids: managedRuleIds,
      }
    };
  
    return API.put(apiName, path, myInit);
  }

  static async getAccountsByRule(ruleId: Number, landingZoneId?: Number = null) {
    const path = `/controls/rules/${ruleId}/accounts?landing_zone_id=${landingZoneId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };

    return API.get(apiName, path, myInit);
  }

  static async updateAccountsByRule(ruleId: Number, accountIds: Array<Number>) {
    const path = `/controls/rules/${ruleId}/accounts`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        account_ids: accountIds,
      }
    };
  
    return API.put(apiName, path, myInit);
  }
}

export default class Service {
  static infrastructure = Infrastructure
  static controls = GxPControl
  /**
   * Return Authorized header
   * @returns {Promise}
   */
  static async __getAuthHeader() {
    return { 
      Authorization: `Bearer ${(await Auth.currentSession()).getIdToken().getJwtToken()}`,
    }
  }

  static async __getUserID() {
    const idToken = (await Auth.currentSession()).getIdToken();
    return idToken.payload.sub;
  }

  static async setS3Config(level) {
    return Storage.configure({ 
      bucket: process.env.REACT_APP_STORAGE_BUCKET,
      level: level,
      region: process.env.REACT_APP_REGION,  
      identityPoolId: config.aws_cognito_identity_pool_id
    });
  }

  /**
   * Get parameters including projects, studies, versions and datasets
   * @returns {Promise}
   */
  static async getParameters() {
    const path = '/qua/options';
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };
  
    return API.get(apiName, path, myInit);
  }

  static async getProjects() {
    const path = '/qua/admin/projects';
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };
  
    return API.get(apiName, path, myInit);
  }

  static async createProject(
    name: String, qualificationTypeId: Number, landingZoneId: String,
    settings: Array<Object>, parameters: Array<Object>
  ) {
    const path = '/qua/admin/projects';
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        name,
        qualification_type_id: qualificationTypeId,
        landing_zone_id: landingZoneId,
        settings, parameters,
      }
    };
  
    return API.post(apiName, path, myInit);
  }

  static async retrieveProjectDetail(projectId: Number) {
    const path = `/qua/admin/projects/${projectId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };
  
    return API.get(apiName, path, myInit);
  }

  static async updateProject(
    projectId: Number, name: String, qualificationTypeId: Number,
    landingZoneId: String, settings: Array<Object>) {
    const path = `/qua/admin/projects/${projectId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        name,
        qualification_type_id: qualificationTypeId,
        landing_zone_id: landingZoneId,
        settings,
      }
    };
  
    return API.put(apiName, path, myInit);
  }

  static async updateProjectParameter(projectId: Number, parameterId: Number, attr: String, value: any) {
    const path = `/qua/admin/projects/${projectId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        parameters: {
          [parameterId]: {
            [attr]: value
          }
        }
      }
    };
  
    return API.put(apiName, path, myInit);
  }

  /**
   * Get all the rules
   * @returns {Promise}
   */
  static async getRules() {
    const path = '/rules';
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };
  
    return API.get(apiName, path, myInit);
  }

  static async createJob(projectId: Number, keyPath: String = '', runMethod: String = 'Excel'){
    const path = '/qua/jobs';
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        project_id: projectId,
        key_path: keyPath,
        run_method: runMethod,
      }
    };
  
    return API.post(apiName, path, myInit);
  }

  static async getJobs() {
    const path = '/qua/jobs';
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };
  
    return API.get(apiName, path, myInit);
  }

  static async getJobsDashboard() {
    const path = '/qua/jobs/dashboard';
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };
  
    return API.get(apiName, path, myInit);
  }

  static async retrieveJobDetails(jobId: Number) {
    const path = `/qua/jobs/${jobId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };
  
    return API.get(apiName, path, myInit);
  }

  static async uploadFileToS3(
    projectId: Number, runMethod: String, selectedFile: File, progressCallback: Function = () => {},
  ) {
    const userId = await Service.__getUserID();
    const defaultProgressCallback = (progress) => {};

    return Storage.put(
      `${projectId}/${userId}/drafts/${selectedFile.name}`,
      selectedFile,
      {
        contentType: selectedFile.type,
        progressCallback: progressCallback || defaultProgressCallback,
      }
    )
  }

  static async downloadBlob(fileKey: String, filename: String) {
    const [level, ...others] = fileKey.split('/')

    Service.setS3Config(level)
    const result = await Storage.get(others.join('/'), { download: true });

    const url = URL.createObjectURL(result.Body);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename || 'download';
    const clickHandler = () => {
      setTimeout(() => {
        URL.revokeObjectURL(url);
        a.removeEventListener('click', clickHandler);
      }, 150);
    };
    a.addEventListener('click', clickHandler, false);
    a.click();
    return a;
  }

  static async downloadReport(jobId: Number, url: String, callback: Function = () => {}) {
    const formatDate = () => {
      let d = new Date(),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

      if (month.length < 2) 
        month = '0' + month;
      if (day.length < 2) 
        day = '0' + day;

      return [year, month, day].join('-');
    }

    return Service.downloadBlob(url, `REPORT__${jobId}_${formatDate()}.pdf`)
  }

  static async checkStatus(jobIds: Array<Number>) {
    const path = `/qua/jobs/status`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        job_ids: jobIds,
      }
    };
  
    return API.post(apiName, path, myInit);
  }

  static async getAccounts() {
    const path = `/admin/accounts`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };

    return API.get(apiName, path, myInit);
  }

  static async createAccount(
    accountName: String, accountID: String,
    awsAccessKeyID: String, awsSecretAccessKey: String,
  ) {
    const path = `/admin/accounts`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        account_name: accountName,
        account_id: accountID,
        aws_access_key_id: awsAccessKeyID,
        aws_secret_access_key: awsSecretAccessKey,
      }
    };
  
    return API.post(apiName, path, myInit);
  }

  static async updateAccount(
    id: String,
    accountName: String, accountID: String,
    awsAccessKeyID: String, awsSecretAccessKey: String,
  ) {
    const path = `/admin/accounts/${id}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        account_name: accountName,
        account_id: accountID,
        aws_access_key_id: awsAccessKeyID,
        aws_secret_access_key: awsSecretAccessKey,
      }
    };
  
    return API.put(apiName, path, myInit);
  }

  static async getUsers() {
    const path = `/admin/users`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };

    return API.get(apiName, path, myInit);
  }

  static async inviteUser(
    email: String, role: String
  ) {
    const path = `/admin/users`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: { email, role }
    };
  
    return API.post(apiName, path, myInit);
  }

  static async updateUserRole(
    userId: String, role: String,
  ) {
    const path = `/admin/users/${userId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: { role }
    };
  
    return API.put(apiName, path, myInit);
  }

  static async createLandingZoneAccount(
    landingZoneId: Number, organizationUnit: String, name: String,
    accountId: String, roleName: String, description: String = '',
  ) {
    const path = `/infra/lz/${landingZoneId}/accounts`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        name, account_id: accountId, description,
        organization_unit: organizationUnit,
        cross_account_role_name: roleName,
      }
    };
  
    return API.post(apiName, path, myInit);
  }

  static async updateLandingZoneAccount(
    landingZoneId: Number, id: Number, name: String, accountId: String, roleName: String, description: String = '',
  ) {
    const path = `/infra/lz/${landingZoneId}/accounts/${id}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        name, account_id: accountId, description,
        cross_account_role_name: roleName,
      }
    };
  
    return API.put(apiName, path, myInit);
  }

  static async updateLandingZoneAccountPartial(
    landingZoneId: Number, accountId: String, attr: String, value: any
  ) {
    const path = `/infra/lz/${landingZoneId}/accounts/${accountId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        [attr]: value,
      }
    };
  
    return API.put(apiName, path, myInit);
  }

  static async fetchLandingZoneAccounts(landingZoneId: Number) {
    const path = `/infra/lz/${landingZoneId}/accounts`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };

    return API.get(apiName, path, myInit);
  }

  static async retrieveLandingZoneAccount(landingZoneId: Number, accountId: Number) {
    const path = `/infra/lz/${landingZoneId}/accounts/${accountId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };

    return API.get(apiName, path, myInit);
  }

  static async createInfrastructure(
    landingZoneId: Number, accountId: Number,
    name: String, resourceType: String, properties: Object
  ) {
    const path = `/infra/lz/${landingZoneId}/accounts/${accountId}/resources`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        resource_type: resourceType,
        name, properties,
      }
    };

    return API.post(apiName, path, myInit);
  }

  static async retrieveLzAccountstructure(landingZoneId: Number, accountId: Number, resourceId) {
    const path = `/infra/lz/${landingZoneId}/accounts/${accountId}/resources/${resourceId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };

    return API.get(apiName, path, myInit);
  }

  static async updateInfrastructure(
    landingZoneId: Number, accountId: Number,
    resourceId: Number, name: String, properties: Object
  ) {
    const path = `/infra/lz/${landingZoneId}/accounts/${accountId}/resources/${resourceId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        name, properties,
      }
    };

    return API.put(apiName, path, myInit);
  }

  static async deleteInfrastructure(landingZoneId: Number, accountId: Number, resourceId: Number) {
    const path = `/infra/lz/${landingZoneId}/accounts/${accountId}/resources/${resourceId}`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
    };

    return API.del(apiName, path, myInit);
  }

  static async checkInfrastructureStatus(landingZoneId: Number, accountId: Number, resourceIds: Array<Number>) {
    const path = `/infra/lz/${landingZoneId}/accounts/${accountId}/resources/status`;
    const myInit = { 
      headers: await Service.__getAuthHeader(),
      body: {
        resource_ids: resourceIds,
      }
    };
  
    return API.post(apiName, path, myInit);
  }
}
