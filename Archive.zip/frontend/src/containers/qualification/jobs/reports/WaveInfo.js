import React from 'react';
import PropTypes from 'prop-types';

import { Card, CardHeader, CardBody } from 'reactstrap';

import ApplicationInfo from './ApplicationInfo';
import ServerMapping from './ServerMapping';
import SummaryTable from './SummaryTable'
import ResourceDetails from './ResourceDetails';

const WaveInfo = ({
  data, createdAt,
}) => {
  const {
    AccountFullName: accountName,
    WaveId: waveId,
    RunNumber: runNumber,
    CreatedBy: reportCreatedBy,
    application_info: appInfoItems,
    server_mapping_windows: serverMappingWindows,
    server_mapping_linux: serverMappingLinux,
    resources_windows: resourcesWindows,
    resources_linux: resourcesLinux,
    test_summary: testSummary,
  } = data;
  return (
    <>
      <Card>
        <CardHeader>
          <h4>Wave Information</h4>
        </CardHeader>
        <CardBody>
          <table className='table'>
            <tbody>
              <tr>
                <td>Wave ID</td>
                <td>{waveId}</td>
              </tr>
              <tr>
                <td>Account Number</td>
                <td>{accountName}</td>
              </tr>
              <tr>
                <td>Run Number</td>
                <td>{runNumber}</td>
              </tr>
              <tr>
                <td>Report Created By</td>
                <td>{reportCreatedBy}</td>
              </tr>
              <tr>
                <td>Created Data</td>
                <td>{createdAt}</td>
              </tr>
            </tbody>
          </table>
        </CardBody>
      </Card>

      <ApplicationInfo items={appInfoItems} />
      {testSummary &&
        <SummaryTable testSummary={testSummary} />}
      {!!serverMappingWindows && serverMappingWindows.length > 0 && (<>
        <ServerMapping key={'windows-server-mapping'} title='Server Mapping - Windows' servers={serverMappingWindows} />
      </>)}
      {!!serverMappingLinux && serverMappingLinux.length > 0 && (<>
        <ServerMapping key={'linux-server-mapping'} title='Server Mapping - Linux' servers={serverMappingLinux} />
      </>)}

      {resourcesWindows.length > 0 && (
        <>
          <ResourceDetails
            title={'Post Migration Resource Details - Windows Servers'}
            records={resourcesWindows} />
        </>
      )}

      {resourcesLinux.length > 0 && (
        <>
          <ResourceDetails
            title={'Post Migration Resource Details - Linux Servers'}
            records={resourcesLinux}
            />
        </>
      )}
    </>
  )
}

WaveInfo.propTypes = {
  data: PropTypes.shape({
    AccountFullName: PropTypes.string.isRequired,
    WaveId: PropTypes.string.isRequired,
    RunNumber: PropTypes.number.isRequired,
    CreatedBy: PropTypes.string.isRequired,
    application_info: PropTypes.arrayOf(PropTypes.object).isRequired,
  }).isRequired,
  createdAt: PropTypes.string.isRequired,
}

export default WaveInfo;
