import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

import {
  Modal, Button, Form,
} from 'reactstrap';

const AccountModal = ({
  show, handleClose, handleSubmit,
  accountData,
}) => {
  const [formData, setFormData] = useState(accountData);
  const onChange = (key, value) => {
    setFormData({
      ...formData,
      [key]: value,
    })
  }

  useEffect(() => {
    setFormData(accountData)
  }, [accountData])

  const isValid = () => {
    const {
      accountName, accountId, awsAccessKeyId, awsSecretAccessKey
    } = formData
    return (
      !!accountName && accountName.length > 0 &&
      !!accountId && accountId.length > 0 &&
      !!awsAccessKeyId && awsAccessKeyId.length > 0 &&
      !!awsSecretAccessKey && awsSecretAccessKey.length > 0
    )
  }

  const onSubmit = () => {
    const {
      accountName, accountId, awsAccessKeyId, awsSecretAccessKey
    } = formData;

    handleSubmit(accountName, accountId, awsAccessKeyId, awsSecretAccessKey).then(() => {
      handleClose()
    })
  }

  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Account Modal</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form.Group>
          <Form.Label>Account Name</Form.Label>
          <Form.Control
            type="text" placeholder="Account Name"
            onChange={(event) => {onChange('accountName', event.target.value)}}
            value={formData.accountName || ''}
            />
        </Form.Group>
        <Form.Group>
          <Form.Label>Account ID</Form.Label>
          <Form.Control
            type="text" placeholder="Account ID"
            onChange={(event) => {onChange('accountId', event.target.value)}}
            value={formData.accountId || ''}
            />
        </Form.Group>
        <Form.Group>
          <Form.Label>AWS Access Key ID</Form.Label>
          <Form.Control
            type="text" placeholder="AWS Access Key ID"
            onChange={(event) => {onChange('awsAccessKeyId', event.target.value)}}
            value={formData.awsAccessKeyId || ''}
            />
        </Form.Group>
        <Form.Group>
          <Form.Label>AWS Secret Access Key</Form.Label>
          <Form.Control
            type="text" placeholder="AWS Secret Access Key"
            onChange={(event) => {onChange('awsSecretAccessKey', event.target.value)}}
            value={formData.awsSecretAccessKey || ''}
            />
        </Form.Group>
      </Modal.Body>
      <Modal.Footer>
        <Button color="secondary" onClick={handleClose}>
          Close
        </Button>
        <Button color="primary" disabled={!isValid()} onClick={onSubmit}>
          Save Changes
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

AccountModal.propTypes = {
  show: PropTypes.bool.isRequired,
  handleClose: PropTypes.func,
  handleSubmit: PropTypes.func.isRequired,
  accountData: PropTypes.shape({
    id: PropTypes.string,
    accountName: PropTypes.string,
    accountId: PropTypes.string,
    awsAccessKeyId: PropTypes.string,
    awsSecretAccessKey: PropTypes.string,
  })
}

AccountModal.defaultProps = {
  handleClose: () => {},
  accountData: {},
}

export default AccountModal;
