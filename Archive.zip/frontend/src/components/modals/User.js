import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

import {
  Modal, Button, Form,
} from 'reactstrap';

const UserModal = ({
  show, handleClose, handleSubmit,
  userData,
}) => {
  const roles = [
    {
      name: 'User', value: 'user',
    },
    {
      name: 'Admin', value: 'admin',
    },
    {
      name: 'Super Admin', value: 'superadmin',
    },
  ]

  const [formData, setFormData] = useState({
    role: roles[0].value,
    ...userData,
  });

  const onChange = (key, value) => {
    setFormData({
      ...formData,
      [key]: value,
    })
  }

  useEffect(() => {
    setFormData({
      role: 'user',
      ...userData,
    })
  }, [userData])

  const isValid = () => {
    const {
      email, role
    } = formData
    return (
      !!email && email.length > 0 &&
      !!role && role.length > 0
    )
  }

  const onSubmit = () => {
    const {
      email, role
    } = formData;

    handleSubmit({email, role}).then(() => {
      handleClose()
    })
  }

  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>User Modal</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form.Group>
          <Form.Label>Email Address</Form.Label>
          <Form.Control
            type="email" placeholder="Email"
            onChange={(event) => {onChange('email', event.target.value)}}
            value={formData.email || ''}
            />
        </Form.Group>
        <Form.Group>
          <Form.Label>Role</Form.Label>
          <Form.Control
            as="select" onChange={(event) => onChange('role', event.target.value)}
            defaultValue={formData.role}>
            {roles.map(({name, value}, idx) => (
              <option key={idx} value={value}>{name}</option>
            ))}
          </Form.Control>
        </Form.Group>
      </Modal.Body>
      <Modal.Footer>
        <Button color="secondary" onClick={handleClose}>
          Close
        </Button>
        <Button color="primary" disabled={!isValid()} onClick={onSubmit}>
          Save Changes
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

UserModal.propTypes = {
  show: PropTypes.bool.isRequired,
  handleClose: PropTypes.func,
  handleSubmit: PropTypes.func.isRequired,
  userData: PropTypes.shape({
    id: PropTypes.string,
    email: PropTypes.string,
    role: PropTypes.string,
  })
}

UserModal.defaultProps = {
  handleClose: () => {},
  userData: {},
}

export default UserModal;
