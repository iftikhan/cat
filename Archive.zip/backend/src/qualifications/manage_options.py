from src.utils.response import build_response
from src.models.parameters import ParameterModel


def get_parameters(event, context):
    model = ParameterModel()
    qualification_types, parameters, landing_zones = model.get_all_options()
    return build_response({
        'qualification_types': [item.to_response() for item in qualification_types],
        'parameters': [item.to_response() for item in parameters],
        'landing_zones': [item.to_dict() for item in landing_zones],
    })


__all__ = ('get_parameters', )
