import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import classnames from 'classnames';
import PropTypes from 'prop-types';

import {
  Form, Button, Row, Col, InputGroup,
} from 'reactstrap';

const ValidateGxP = ({
  fetchingParameter,
  projects, studies, versions, datasets,
  onUploadGxP, isLoading,
}) => {
  const [curProject, setCurProject] = useState(null);
  const [curStudy, setCurStudy] = useState(null);
  const [curVersion, setCurVersion] = useState(null);
  const [curDataset, setCurDataset] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);

  const history = useHistory();

  useEffect(() => {
    setCurProject(projects[0])
  }, [projects])
  
  useEffect(() => {
    if (curProject) {
      setCurStudy(studies.filter(item => item.project_id === curProject.id)[0])
    }
  }, [curProject, setCurStudy, studies])

  useEffect(() => {
    if (curStudy) {
      setCurVersion(versions.filter(item => item.study_id === curStudy.id)[0])
    }
  }, [curStudy, setCurVersion, versions])

  useEffect(() => {
    if (curVersion) {
      setCurDataset(datasets.filter(item => item.version_id === curVersion.id)[0])
    }
  }, [curVersion, setCurDataset, datasets])

  const onProjectChange = (event) => {
    const [selected] = projects.filter(project => project.id === parseInt(event.target.value))
    setCurProject(selected);
  }

  const onStudyChange = (event) => {
    const [selected] = studies.filter(study => study.id === parseInt(event.target.value))
    setCurStudy(selected);
  }

  const onVersionChange = (event) => {
    const [selected] = versions.filter(version => version.id === parseInt(event.target.value))
    setCurVersion(selected);
  }

  const onDatasetChange = (event) => {
    const [selected] = datasets.filter(dataset => dataset.id === parseInt(event.target.value))
    setCurDataset(selected);
  }

  const onClickNext = async (event) => {
    onUploadGxP(curProject.id, curStudy.id, curVersion.id, curDataset.id, selectedFile).then(() => {
      history.push('/gxp-qualification/jobs');
    })
  }

  if (isLoading) {
    return <>
      <br />
      <br />
      <h3>Loading parameters...</h3>
    </>
  } else {
    return (
      <>
        <br />
        <br />
        <br />
        <Form.Text>
          <h5>Select GxP Parameters</h5>
        </Form.Text>
        <br />
        <Form.Group as={Row} className="mb-3" disabled={fetchingParameter}>
          <Form.Label column sm="2">
            Project
          </Form.Label>
          <Col sm="3">
            <Form.Control
              as="select" value={curProject ? curProject.id : ''}
              onChange={onProjectChange}>
              {projects.map((project, idx) => (
                <option key={idx} value={project.id}>{project.name}</option>
              ))}
            </Form.Control>
          </Col>
          <Col sm={2}></Col>
          <Form.Label column sm="2">
            Study
          </Form.Label>
          <Col sm="3">
            <Form.Control
              as="select" value={curStudy ? curStudy.id : ''}
              onChange={onStudyChange}
            >
              {curProject && studies.filter(item => item.project_id === curProject.id).map((study, idx) => (
                <option key={idx} value={study.id}>{study.name}</option>
              ))}
            </Form.Control>
          </Col>
        </Form.Group>
        <br />
        <Form.Group as={Row} className="mb-3">
          <Form.Label column sm="2">
            GxP Version
          </Form.Label>
          <Col sm="3">
            <Form.Control
              as="select" value={curVersion ? curVersion.id : ''}
              onChange={onVersionChange}
              >
              {curStudy && versions.filter(item => item.study_id === curStudy.id).map((version, idx) => (
                <option key={idx} value={version.id}>{version.name}</option>
              ))}
            </Form.Control>
          </Col>
          <Col sm={2}></Col>
          <Form.Label column sm="2">
            Dataset
          </Form.Label>
          <Col sm="3">
            <Form.Control
              as="select" value={curDataset ? curDataset.id : ''}
              onChange={onDatasetChange}
            >
              {curVersion && datasets.filter(item => item.version_id === curVersion.id).map((dataset, idx) => (
                <option key={idx} value={dataset.id}>{dataset.name}</option>
              ))}
            </Form.Control>
          </Col>
        </Form.Group>
        <br />
        <Form.Group as={Row} className="mb-3" controlId="formPlaintextEmail">
          <Form.Label column sm="2">
            Upload GxP
          </Form.Label>
          <Col sm="10">
            <InputGroup className="sm-10">
              <Form.File
                placeholder="Choose File"
                label={selectedFile ? selectedFile.name : "Choose File"}
                data-browse="Browse"
                onChange={event => {setSelectedFile(event.target.files[0])}}
                custom
              />
            </InputGroup>
          </Col>
        </Form.Group>
        <br />
        <Row>
          <Col>
            <Button
              color="primary" type="submit" className={classnames('float-right')}
              disabled={!selectedFile} onClick={onClickNext}
            >
              Next
            </Button>
          </Col>
        </Row>
      </>
    );
  }
}

ValidateGxP.propTypes = {
  fetchingParameter: PropTypes.bool,
  projects: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
  })).isRequired,
  studies: PropTypes.arrayOf(PropTypes.shape({
    project_id: PropTypes.number.isRequired,
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
  })).isRequired,
  versions: PropTypes.arrayOf(PropTypes.shape({
    study_id: PropTypes.number.isRequired,
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
  })).isRequired,
  datasets: PropTypes.arrayOf(PropTypes.shape({
    version_id: PropTypes.number.isRequired,
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
  })).isRequired,
  onUploadGxP: PropTypes.func.isRequired,
  isLoading: PropTypes.bool.isRequired,
}

ValidateGxP.defaultProps = {
  fetchingParameter: false,
}

export default ValidateGxP;
