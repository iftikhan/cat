import re
import json

from .common import CrossAccountClientBase


class CloudFormationUtil(CrossAccountClientBase):
    client_name: str = 'cloudformation'

    def create_stack(self, name: str, cloudformation: dict):
        response = self.client.create_stack(
            StackName=re.sub(r'[\s\t]', '-', name),
            TemplateBody=' '.join(json.dumps(cloudformation).split(' ')),
            # TemplateURL='string',
            # Parameters=[
            #     {
            #         'ParameterKey': 'string',
            #         'ParameterValue': 'string',
            #         'UsePreviousValue': True|False,
            #         'ResolvedValue': 'string'
            #     },
            # ],
            # DisableRollback=True|False,
            # RollbackConfiguration={
            #     'RollbackTriggers': [
            #         {
            #             'Arn': 'string',
            #             'Type': 'string'
            #         },
            #     ],
            #     'MonitoringTimeInMinutes': 123
            # },
            # TimeoutInMinutes=123,
            # NotificationARNs=[
            #     'string',
            # ],
            # Capabilities=[
            #     'CAPABILITY_IAM'|'CAPABILITY_NAMED_IAM'|'CAPABILITY_AUTO_EXPAND',
            # ],
            # ResourceTypes=[
            #     'string',
            # ],
            # RoleARN='string',
            # OnFailure='DO_NOTHING'|'ROLLBACK'|'DELETE',
            # StackPolicyBody='string',
            # StackPolicyURL='string',
            # Tags=[
            #     {
            #         'Key': 'string',
            #         'Value': 'string'
            #     },
            # ],
            # ClientRequestToken='string',
            # EnableTerminationProtection=True|False
        )

        return response['StackId']

    def describe_stack(self, stack_id: str):
        return self.client.describe_stacks(
            StackName=stack_id,
            # NextToken='string'
        )

    def update_stack(self, stack_id: str, cloudformation: dict):
        response = self.client.update_stack(
            StackName=stack_id,
            TemplateBody=' '.join(json.dumps(cloudformation).split(' ')),
            # TemplateURL='string',
            # UsePreviousTemplate=True,
            # StackPolicyDuringUpdateBody='string',
            # StackPolicyDuringUpdateURL='string',
            # Parameters=[
            #     {
            #         'ParameterKey': 'string',
            #         'ParameterValue': 'string',
            #         'UsePreviousValue': True|False,
            #         'ResolvedValue': 'string'
            #     },
            # ],
            Capabilities=[
                'CAPABILITY_IAM',
                'CAPABILITY_NAMED_IAM',
                'CAPABILITY_AUTO_EXPAND',
            ],
            # ResourceTypes=[
            #     'string',
            # ],
            # RoleARN='string',
            # RollbackConfiguration={
            #     'RollbackTriggers': [
            #         {
            #             'Arn': 'string',
            #             'Type': 'string'
            #         },
            #     ],
            #     'MonitoringTimeInMinutes': 123
            # },
            # StackPolicyBody='string',
            # StackPolicyURL='string',
            # NotificationARNs=[
            #     'string',
            # ],
            # Tags=[
            #     {
            #         'Key': 'string',
            #         'Value': 'string'
            #     },
            # ],
            # DisableRollback=True|False,
            # ClientRequestToken='string'
        )

        return response['StackId']

    def delete_stack(self, stack_id: str):
        response = self.client.delete_stack(
            StackName=stack_id,
            # RetainResources=[
            #     'string',
            # ],
            # RoleARN='string',
            # ClientRequestToken='string'
        )
        return response
