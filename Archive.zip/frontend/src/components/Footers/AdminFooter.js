
/*eslint-disable*/

// reactstrap components
import { NavItem, NavLink, Nav, Container, Row, Col } from "reactstrap";

function AdminFooter() {
  return (
    <div className='autogxp-footer'>
      <Container fluid>
        <footer className="footer pt-0">
          <Row className="align-items-center justify-content-lg-between">
            <Col>
              <div className="copyright text-center text-lg-left text-muted">
                © Copyright 2012 - {new Date().getFullYear()}{" "} | 
                <a
                  className="font-weight-bold ml-1"
                  href="https://customer.com?ref=auto-gxp-footer"
                  target="_blank"
                >
                  Customer Ltd.
                </a>
                <span> | All Rights Reserved</span>
              </div>
            </Col>
          </Row>
        </footer>
      </Container>
    </div>
  );
}

export default AdminFooter;
