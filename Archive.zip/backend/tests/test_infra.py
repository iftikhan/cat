import uuid

from .utils.base import ServerlessTestCase


class TestInfra(ServerlessTestCase):
    # def test_create_infra(self):
    #     ['name', 'account_id', 'cross_account_role_name']
    #     params = {
    #         'name': 'first_demo',
    #         'account_id': '728272444616',
    #         'cross_account_role_name': 'autogxp-dev-crossaccount-role',
    #     }
    #     result = self.client.http.post('/infra/lz', body=params)
    #     self.assertEqual(result.status_code, 201)
    #     response = result.json_body
    #     self.assertTrue(response['status'])

    def test_list_infra(self):
        result = self.client.http.get('/infra/lz')
        self.assertEqual(result.status_code, 200)
        response = result.json_body
        self.assertTrue('landing_zones' in response)
        self.assertIsInstance(response['landing_zones'], list)

    def test_list_landing_zone_accounts(self):
        result = self.client.http.get('/infra/lz/1/accounts')
        self.assertEqual(result.status_code, 200)

    def test_s3_resource_workflow(self):
        landing_zone_id = 2
        account_id = 3
        params = {
            'name': 'Auto UnitTest Demo',
            "resource_type": "s3",
            "properties": {
                "bucket_name": f"gxp-infra-provisioning-s3-demo-{uuid.uuid4()}",
                "object_versioning": False,
                "server_side_encryption": "AES256", "kms_master_key_id": "aws/s3",
                "access_logging": False, "access_logging_target_bucket": "",
                "access_logging_file_prefix": "", "block_public_acls": False,
                "block_public_policies": False, "ignore_public_acls": False,
                "restrict_public_bukcet_policies": False, "predefined_acl": "None"
            }
        }
        result = self.client.http.post(
            f'/infra/lz/{landing_zone_id}/accounts/{account_id}/resources', body=params)
        self.assertEqual(result.status_code, 200)

        resource_id = result.json_body['resource_id']
        self.assertIsInstance(resource_id, int)

        # NOTE: Updating resources
        params['name'] = params['name'] + '(updated)'
        result = self.client.http.put(
            f'/infra/lz/{landing_zone_id}/accounts/{account_id}/resources/{resource_id}',
            body=params
        )
        self.assertEqual(result.status_code, 200)

        # NOTE: Deleting
        result = self.client.http.delete(
            f'/infra/lz/{landing_zone_id}/accounts/{account_id}/resources/{resource_id}')
        self.assertEqual(result.status_code, 200)
