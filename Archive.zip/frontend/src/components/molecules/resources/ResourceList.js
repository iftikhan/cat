import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { useHistory } from 'react-router';

import { Row, Col, Button } from 'reactstrap';
import { FaTrashAlt, FaEdit } from 'react-icons/fa';

import SearchTable from 'components/tables/SearchTable';
import ConfirmModal from 'components/modals/ConfirmModal';

const ResourceList = ({
  landingZoneId, accountId, resources, onDeleteResource,
}) => {
  const history = useHistory();
  const [selectedResource, setSelectedResource] = useState({});
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  const onClickDelete = (resource: Object) => {
    setSelectedResource(resource);
    setShowDeleteModal(true);
  }

  const onDeleteConfirmed = () => {
    setShowDeleteModal(false)
    onDeleteResource(selectedResource).then(res => {
      console.log(res)
    }).catch(err => {
      console.error(err)
    })
  }

  const columns = [
    {
      dataField: 'resource_type',
      text: 'Resource Type',
      headerStyle: {width: '180px'},
    }, {
      dataField: 'name',
      text: 'Resource Name',
      // headerStyle: {width: '120px'},
    }, {
      dataField: 'status',
      'text': 'Status',
      headerStyle: {width: '120px'}
    }, {
      dataField: '',
      text: '',
      headerStyle: {width: '140px'},
      formatter: (value, row) => {
        const {id: resourceId} = row;
        return (
          <Row>
            <Col>
              <Button
                className={'btn-sm'} color='info'
                onClick={() => history.push(`/gxp-infra/create/${landingZoneId}/accounts/${accountId}/resources/${resourceId}`)}>
                <FaEdit />
              </Button>
            </Col>
            <Col>
              <Button
                className={'btn-sm'} color='danger'
                onClick={() => onClickDelete(row)}>
                <FaTrashAlt />
              </Button>
            </Col>
          </Row>
        )
      }
    },
  ];

  return (
    <>
      <SearchTable
        data={resources} columns={columns} keyField='id'
        entryNamePlural={'resources'}
        noDataIndication={'no resource found.'}
        />
      <ConfirmModal
        title='Double Check'
        description={`Are you sure to delete ${selectedResource.name}?`}
        onOkay={onDeleteConfirmed}
        show={showDeleteModal} onCancel={() => setShowDeleteModal(false)} />
    </>
  )
};

ResourceList.propTypes = {
  landingZoneId: PropTypes.string.isRequired,
  accountId: PropTypes.string.isRequired,
  resources: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
    resource_type: PropTypes.string.isRequired,
    status: PropTypes.string.isRequired,
  })).isRequired,
  onDeleteResource: PropTypes.func.isRequired,
}

export default ResourceList;
