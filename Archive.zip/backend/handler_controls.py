import json

from src.utils.constants import CloudProvider
from src.utils.response import build_response
from src.utils.auth import get_authenticated_user
from src.models.controls.models import ControlsModel


def manage_control_rules(event, context):
    # user_id = get_authenticated_user(event)
    http_method = event['requestContext']['httpMethod']
    query_params = event.get('queryStringParameters') or {}
    # http_path: str = event['path']
    path_params = event.get('pathParameters') or {}
    control_model = ControlsModel()

    # controls/managed_rules/{rule_id}
    if 'rule_id' in path_params:
        rule_id = path_params.get('rule_id')

        if http_method == 'GET':
            rule = control_model.retrieve_managed_rule(rule_id)

            if rule:
                return build_response({
                    'status': True,
                    'rule': rule.to_dict(),
                })
            else:
                return build_response({
                    'status': False,
                }, 404)

        elif http_method == 'PUT':
            params = json.loads(event['body'] or '{}')
            status = control_model.update_managed_rule(rule_id, **params)
            return build_response({
                'status': status
            })

    # GET: /controls/managed_rules
    if http_method == 'GET':
        landing_zone_id = query_params.get('landing_zone_id')

        if landing_zone_id:
            provider = CloudProvider(query_params.get('provider') or CloudProvider.aws.value)
            managed_rules = control_model.get_managed_rules_per_landing_zone(
                landing_zone_id, provider)
        else:
            provider = query_params.get('provider')
            managed_rules = control_model.get_managed_rules(provider)
        return build_response({
            'status': True,
            'managed_rules': [rule.to_dict() for rule in managed_rules]
        })

    if http_method == 'POST':
        params = json.loads(event['body'] or '{}')
        provider = CloudProvider(params.get('provider', CloudProvider.aws.value))
        name = params.get('name')
        description = params.get('description')
        services = params.get('services')
        standards = params.get('standards')
        tags = params.get('tags')

        if not name or not services or not standards:
            return build_response({
                'status': False,
                'msg': 'name, services and standards are all required.'
            }, 400)

        status = control_model.create_managed_rule(
            provider=provider, name=name, services=services,
            standards=standards, tags=tags, description=description
        )

        return build_response({
            'status': status,
        }, 200 if status else 400)


def apply_control_rules(event, context):
    user_id = get_authenticated_user(event)
    http_method = event['requestContext']['httpMethod']
    control_model = ControlsModel()
    params = json.loads(event['body'] or '{}')

    # POST: /controls/managed_rules
    if http_method == 'POST':
        managed_rule_ids = params.get('managed_rule_ids', [])
        account_ids = params.get('account_ids', [])

        if not managed_rule_ids or not account_ids:
            return build_response({
                'status': False,
                'msg': 'managed_rule_ids and account_ids are all required.'
            }, 400)

        status = control_model.apply_managed_rules_to_accounts(
            managed_rule_ids, account_ids, user_id
        )

        return build_response({
            'status': status,
        }, 200 if status else 400)

    return build_response({
        'status': False,
    }, 404)


def manage_account_rules(event, context):
    user_id = get_authenticated_user(event)
    http_method = event['requestContext']['httpMethod']
    # query_params = event.get('queryStringParameters') or {}
    # http_path: str = event['path']
    path_params = event.get('pathParameters') or {}
    control_model = ControlsModel()
    account_id = path_params.get('account_id')
    if http_method == 'GET':
        rules = control_model.list_managed_rules_per_account(account_id)
        return build_response({
            'status': True,
            'account_rules': [rule.to_dict() for rule in rules]
        })

    params = json.loads(event['body'] or '{}')
    if http_method == 'PUT':
        managed_rule_ids = params.get('managed_rule_ids', [])
        if not managed_rule_ids:
            pass

        status = control_model.update_rules_per_account(
            account_id, managed_rule_ids, user_id
        )

        return build_response({
            'status': status,
        }, 200 if status else 400)


def manage_rule_accounts(event, context):
    """
    path: /controls/rules/{rule_id}/accounts
    """
    user_id = get_authenticated_user(event)
    http_method = event['requestContext']['httpMethod']
    query_params = event.get('queryStringParameters') or {}
    # http_path: str = event['path']
    path_params = event.get('pathParameters') or {}
    control_model = ControlsModel()
    rule_id = path_params.get('rule_id')
    landing_zone_id = query_params.get('landing_zone_id')

    if http_method == 'GET':
        accounts = control_model.list_accounts_per_managed_rule(rule_id, landing_zone_id=landing_zone_id)
        return build_response({
            'status': True,
            'accounts': [account.to_response() for account in accounts]
        })

    params = json.loads(event['body'] or '{}')
    if http_method == 'PUT':
        account_ids = params.get('account_ids', [])
        if not account_ids:
            pass

        status = control_model.update_accounts_per_rule(
            rule_id, account_ids, user_id
        )

        return build_response({
            'status': status,
        }, 200 if status else 400)
