import os
from typing import Any, Counter, List, Optional
from datetime import datetime

from sqlalchemy.sql.expression import null

from src.utils.pgsql import PgsqlManager, PG_DB_TABLE
from src.utils.constants import DATETIME_FORMAT, JOB_STATUS


class JobEntry:
    id: str = None
    user_id: str
    project_id: int
    project_name: str
    qualification_type_id: int
    qualification_type_name: str
    run_method: str
    status: str
    started_at: datetime
    ended_at: Optional[datetime] = None
    s3_input_url: str
    details: dict

    def __init__(
        self, user_id: str, project_id: int, project_name: str,
        qualification_type_id: int, qualification_type_name: str,
        run_method: str, status: str, s3_input_url: str,
        started_at: datetime, ended_at: Optional[datetime] = None,
        details: dict = {}, id: str = None
    ) -> None:
        self.id = id
        self.user_id = str(user_id)
        self.project_id = project_id
        self.project_name = project_name
        self.run_method = run_method
        self.qualification_type_id = qualification_type_id
        self.qualification_type_name = qualification_type_name
        self.status = status
        self.started_at = started_at
        self.ended_at = ended_at
        self.s3_input_url = s3_input_url
        self.details = details or {}

    @property
    def filename(self) -> str:
        return os.path.basename(self.s3_input_url)

    @property
    def reports(self) -> List[str]:
        return self.details.get('reports', [])

    @property
    def duration(self) -> str:
        if self.ended_at:
            return str(self.ended_at - self.started_at)
        else:
            return '-'

    def __repr__(self) -> str:
        return f"<Job({self.id}): {self.filename}>"

    def __str__(self) -> str:
        return f"{self.id}: {self.filename}"

    @staticmethod
    def convert_status_text(value: str) -> str:
        if value == JOB_STATUS.success:
            return 'Run Successful'
        else:
            return value

    @property
    def long_status_text(self) -> str:
        if self.status == JOB_STATUS.success:
            return f'Successfully completed on {self.ended_at.strftime(DATETIME_FORMAT)}'
        else:
            return f'Started on {self.started_at.strftime(DATETIME_FORMAT)}'

    @property
    def status_test(self) -> str:
        return self.__class__.convert_status_text(self.status)

    @property
    def report_details(self) -> List[dict]:
        return self.details.get('report_details', [])

    def to_dashboard_response(self) -> dict:
        report_details = self.details.get('report_details', [])
        test_summary = {
            'total': 0,
            'passed': 0,
            'failed': 0
        }

        if len(report_details) > 0:
            wave_data = report_details[0]

            for _, value in wave_data.get('test_summary').items():
                test_summary['total'] += value.get('total_test_cases', value.get('total_test_cases'))
                test_summary['passed'] += value.get('total_passed_cases', value.get('total_passed_cases'))
                test_summary['failed'] += value.get('total_failed_cases', value.get('total_failed_cases'))
            wave_info = {
                'wave_id': wave_data.get('WaveId'),
                'created_by': wave_data.get('CreatedBy'),
                'account_id': wave_data.get('AccountNumber'),
                'test_summary': test_summary
            }
        else:
            wave_info = {
                'test_summary': test_summary
            }

        if len(self.reports) > 0:
            report_url = self.reports[0]
        else:
            report_url = null

        return {
            'id': self.id,
            'created_at': self.started_at,
            'url': report_url,
            'qualification_type': self.qualification_type_name,
            **wave_info,
        }

    def to_response(self, with_report_details: bool = False) -> dict:
        response = {
            'id': self.id,
            'project': self.project_name,
            'qualification_type_id': self.qualification_type_id,
            'qualification_type': self.qualification_type_name,
            'run_method': self.run_method,
            'status': self.status_test,
            'started_at': self.started_at,
            'duration': self.duration,
            'ended_at': self.ended_at,
            's3_input_url': self.s3_input_url,
            'reports': self.reports,
            'created_by': self.user_id,
        }

        if with_report_details:
            response['report_details'] = self.report_details

        return response

    def to_dict(self) -> dict:
        result = {
            'user_id': self.user_id,
            'project_id': self.project_id,
            'run_method': self.run_method,
        }

        if self.id:
            result['id'] = self.id

        return result


class JobsModel:
    def __init__(self, db_manager: PgsqlManager = None) -> None:
        if isinstance(db_manager, PgsqlManager):
            self.__db_manager = db_manager
        else:
            self.__db_manager = PgsqlManager()

    def create(self, user_id: str, project_id: str, run_method: str, key_path: str) -> int:
        conn = self.__db_manager.get_db_connection()
        _table = PG_DB_TABLE.jobs
        stmt = _table.insert().values(
            created_by=user_id,
            project_id=project_id,
            run_method=run_method,
            s3_input_url=key_path
        ).returning(
            _table.c.id,
        )

        @self.__db_manager.get_transaction_scope(conn)
        def __transaction():
            response = conn.execute(stmt).fetchone()
            return response[0]

        return __transaction()

    def list_jobs_by_user(self, user_id: str = None, page: int = 1, size: int = 30) -> List[JobEntry]:
        where_clause = f"WHERE jobs.user_id = '{user_id}'" if user_id else ""
        query = f"""
            SELECT
                j.id, j.created_by AS user_id,
                j.project_id, p."name" AS project_name,
                qt.id AS qualification_type_id,
                qt."name" as qualification_type_name,
                j.run_method, j.status, j.s3_input_url,
                j.started_at, j.ended_at, j.details
            FROM
                jobs j
                JOIN projects p ON j.project_id = p.id
                JOIN qualification_types qt ON p.qualification_type_id = qt.id
            {where_clause}
            ORDER BY j.id DESC;"""
        conn = self.__db_manager.get_db_connection()
        rows = conn.execute(query).fetchall()
        return [JobEntry(**row) for row in rows]

    def get_job(self, job_id: int) -> Optional[JobEntry]:
        query = f"""
            SELECT
                j.id, j.created_by AS user_id,
                j.project_id, p."name" AS project_name,
                qt.id AS qualification_type_id,
                qt."name" as qualification_type_name,
                j.run_method, j.status, j.s3_input_url,
                j.started_at, j.ended_at, j.details
            from
                jobs j
                JOIN projects p ON j.project_id = p.id
                JOIN qualification_types qt ON p.qualification_type_id = qt.id
            WHERE j.id = {job_id};"""
        conn = self.__db_manager.get_db_connection()
        row = conn.execute(query).fetchone()

        return JobEntry(**row) if row else None

    def get_jobs(self) -> List[JobEntry]:
        query = f"""
            SELECT
                j.id, j.created_by AS user_id,
                j.project_id, p."name" AS project_name,
                qt.id AS qualification_type_id,
                qt."name" as qualification_type_name,
                j.run_method, j.status, j.s3_input_url,
                j.started_at, j.ended_at, j.details
            FROM
                jobs j
                JOIN projects p ON j.project_id = p.id
                JOIN qualification_types qt ON p.qualification_type_id = qt.id
            WHERE j.status IN ('{JOB_STATUS.success}', '{JOB_STATUS.failure}')
            ORDER BY j.id;"""
        conn = self.__db_manager.get_db_connection()
        rows = conn.execute(query).fetchall()

        return [JobEntry(**row) for row in rows]

    def get_jobs_dashboard(self) -> dict:
        jobs = self.get_jobs()
        jobs = [job.to_dashboard_response() for job in jobs]
        run_per_account = Counter()
        for job in jobs:
            if not job.get('account_id'):
                continue

            run_per_account[job['account_id']] += 1

        return {
            'jobs': jobs,
            'run_per_account': [
                (account_id, number_of_run)
                for account_id, number_of_run in run_per_account.items()
            ]
        }

    def check_if_complete(self, job_id: int) -> bool:
        conn = self.__db_manager.get_db_connection()
        query = f"""
            SELECT status, count(*) as count
            FROM "report_summaries" rs
            WHERE rs.job_id = {job_id}
            GROUP BY rs.status;"""
        rows = conn.execute(query).fetchall()
        status_dictionary = dict([
            (row.status, row.count) for row in rows
        ])

        if JOB_STATUS.running in status_dictionary:
            return False

        if JOB_STATUS.error in status_dictionary:
            status = JOB_STATUS.error
        elif JOB_STATUS.failure in status_dictionary:
            status = JOB_STATUS.failure
        else:
            status = JOB_STATUS.success

        _table = PG_DB_TABLE.jobs
        stmt = _table.update().where(
            _table.c.id == job_id
        ).values(status=status, ended_at=datetime.now())

        @self.__db_manager.get_transaction_scope(conn)
        def __transaction():
            response = conn.execute(stmt)
            return response.rowcount > 0

        result = __transaction()

        # NOTE: Not sure why this is required???
        # Commenting out for the moment.
        # if result:
        #     self.generate_report(job_id)

        return result

    # def generate_report(self, job_id: int, invocation_type: str = 'Event'):
    #     return LambdaFunction.invoke_lambda(
    #         settings.GENERATE_REPORT_FUNCTION_NAME,
    #         {'job_id': job_id}, invocation_type
    #     )

    def get_reports(self, job_id: int, mode: str) -> List[str]:
        mode = mode.lower()
        if mode not in ['pdf', 'xlsx']:
            raise ValueError(f'Invalid mode - {mode}')

        conn = self.__db_manager.get_db_connection()
        _table = PG_DB_TABLE.jobs
        stmt = _table.select().where(
            _table.c.id == job_id).with_only_columns([_table.c.details])
        row = conn.execute(stmt).fetchone()

        if not row:
            return []
        else:
            details = row.details or {}
            return details.get('reports', [])

    def get_status(self, job_ids: List[int]) -> List[dict]:
        conn = self.__db_manager.get_db_connection()
        _table = PG_DB_TABLE.jobs
        stmt = _table.select().where(_table.c.id.in_(job_ids)).with_only_columns(
            [_table.c.id, _table.c.status]
        )
        rows = conn.execute(stmt).fetchall()
        return [dict(
            job_id=row.id,
            status=JobEntry.convert_status_text(row.status)
        ) for row in rows]

    def update(self, job_id: int, attribute: str, value: Any, **kwargs):
        conn = self.__db_manager.get_db_connection()
        _table = PG_DB_TABLE.jobs
        stmt = _table.update().where(_table.c.id == job_id).values(
            **{attribute: value, **kwargs}
        )

        @self.__db_manager.get_transaction_scope(conn)
        def __transaction():
            response = conn.execute(stmt)
            return response.rowcount > 0

        return __transaction()
