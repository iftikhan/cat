import React from 'react';
import { useHistory } from 'react-router-dom';
import PropTypes from 'prop-types';

import {
  Modal, ModalHeader, ModalBody, ModalFooter, Button, FormGroup,
} from 'reactstrap';

import ValidationRecord from 'components/jobs/ValidationRecord';

const JobCreateReport = ({
  show, success, validationResult, onHide
}) => {
  const {
    excel, assume_role: assumeRole, ec2, iam
  } = validationResult
  const history = useHistory();

  return (
    <Modal show={show} onHide={onHide}>
      <ModalHeader closeButton>
        {success ? 'Success' : 'Failure!'}
      </ModalHeader>
      <ModalBody>
        <ValidationRecord caption={'Checking Excel Structure'} success={!!excel} />
        <ValidationRecord caption={'Checking Cross Account Role'} success={!!assumeRole} />
        <ValidationRecord caption={'Checking EC2 Permissions'} success={!!ec2} />
        <ValidationRecord caption={'Checking IAM Permissions'} success={!!iam} />
        <FormGroup>
          <h3>
            {success
            ? 'SUCCESSFULLY CREATED A JOB!'
            : 'PLEASE CORRECT THE ERRORS ABOVE IN ORDER TO CREATE A JOB'}
          </h3>
        </FormGroup>
      </ModalBody>
      <ModalFooter>
        {success
        ? (
          <Button color="primary" onClick={() => {history.push('/gxp-qualification/jobs')}}>
            Check jobs
          </Button>
        )
        : (
          <Button color="secondary" onClick={onHide}>
            Upload again
          </Button>
        )}
      </ModalFooter>
    </Modal>
  )
}

JobCreateReport.propTypes = {
  show: PropTypes.bool.isRequired,
  success: PropTypes.bool,
  validationResult: PropTypes.shape({
    excel: PropTypes.bool,
    assume_role: PropTypes.bool,
    ec2: PropTypes.bool,
    iam: PropTypes.bool,
  }),

  onHide: PropTypes.func.isRequired,
}

JobCreateReport.defaultProps = {
  success: false,
  validationResult: {
    excel: false,
    assume_role: false,
    ec2: false,
    iam: false,
  }
}

export default JobCreateReport;
