import React from 'react';
import PropTypes from 'prop-types';

import { Input } from 'reactstrap';
import Select2 from "react-select2-wrapper";

import { ComplianceStandards } from 'utils/constants';

const CloudComplianceStandarSelect = ({
  onChange, value, multiple, id, className,
}) => {
  if (multiple) {
    return (
      <Select2
        className={className}
        data-minimum-results-for-search="Infinity"
        defaultValue={value}
        multiple
        id={id}
        onChange={(e) => {onChange(Array.from(e.target.selectedOptions, option => option.value))}}
        data={ComplianceStandards.map((item) => ({id: item, text: item}))}
        />
    )
  }
  return (
    <Input
      className={className}
      type='select' value={value}
      id={id}
      onChange={(event) => onChange(event.target.value)}
    >
      <option value={''}>All Standards</option>
      {ComplianceStandards.map((item, idx) => (
        <option key={idx} value={item}>{item.toUpperCase()}</option>
      ))}
    </Input>
  )
}

CloudComplianceStandarSelect.propTypes = {
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.arrayOf(PropTypes.string)]),
  onChange: PropTypes.func.isRequired,
  multiple: PropTypes.bool,
  className: PropTypes.string,
};

CloudComplianceStandarSelect.defaultProps = {
  value: '',
  multiple: false,
  className: "form-control-sm",
}

export default CloudComplianceStandarSelect;
