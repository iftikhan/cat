from src.bin.parameters.bin import action_init_meta, action_init_managed_config_rules


def test_initalize_mock():
    action_init_meta()


def test_initialize_managed_rules():
    action_init_managed_config_rules()
